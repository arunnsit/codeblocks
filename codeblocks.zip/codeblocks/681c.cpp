#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#include<stdio.h>
using namespace std;
multiset<int>s;
vector<pair<string,int> >v,sol;
int main()
{
	ios_base::sync_with_stdio(false); 
	int n,x,mi;
	string a;
	string in="insert",q="getMin",r="removeMin";
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a;
		if(a!="removeMin")
		{
			cin>>x;
		}
		else x=0;
		v.push_back(make_pair(a,x));
	}
	for(int i=0;i<v.size();i++)
	{
		if(v[i].first=="insert")
		{
			s.insert(v[i].second);
			sol.push_back(make_pair(v[i].first,v[i].second));
		}
		else if(v[i].first=="getMin")
		{
				if(!s.empty())
				{	
					mi=(*s.begin());
					//cout<<"inhere "<<mi<<endl;
					if(mi<v[i].second)
					{

						while(!s.empty()&&(*s.begin())<v[i].second)
						{
							sol.push_back(make_pair(r,0));
							s.erase(s.begin());
						}
						if(s.empty()||(*s.begin())!=v[i].second)
						{
							s.insert(v[i].second);
							sol.push_back(make_pair(in,v[i].second));
						}
					}
					else if(mi>v[i].second)
					{
						s.insert(v[i].second);
						sol.push_back(make_pair(in,v[i].second));
					}
					sol.push_back(make_pair(v[i].first,v[i].second));
				}
				else
				{
					sol.push_back(make_pair(in,v[i].second));
					s.insert(v[i].second);
					sol.push_back(make_pair(v[i].first,v[i].second));
				}
		}
		else
		{
			if(!s.empty())
			{
				s.erase(s.begin());
			}
		    else 
		    {
		    	sol.push_back(make_pair(in,1));
		    }
		    sol.push_back(make_pair(v[i].first,0));
		}
	}
	cout<<sol.size()<<endl;
	for(int i=0;i<sol.size();i++)
	{
		if(sol[i].first=="removeMin")
		{
			cout<<sol[i].first<<endl;
		}
		else
		{
			cout<<sol[i].first<<" "<<sol[i].second<<endl;
		}
	}
}