#include<iostream>
#include<stdio.h>
using namespace std;
int has[1000009]={0};
int a[1000009]={0};
int main()
{
	int n,k;
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)
		cin>>a[i];
	int curkk=0,x=1,y=1,mw=0,mx=1,my=1;
	while(y!=n+1)
	{
		if(curkk>k)
		{
			has[a[x]]--;
			if(has[a[x]]==0)
				curkk--;
			x++;
		}
		else if(curkk<=k)
		{
			if(y-x>=mw&&curkk<=k)
			{
				mw=y-x;
				mx=x;
				my=y-1;
			}
			has[a[y]]++;
			if(has[a[y]]==1)
				curkk++;
			y++;
			if(y-x>=mw&&curkk<=k)
			{
				mw=y-x;
				mx=x;
				my=y-1;
			}
		}
	}
	cout<<mx<<" "<<my<<endl;
}

