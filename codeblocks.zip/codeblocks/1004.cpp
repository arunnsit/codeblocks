#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string.h>
using namespace std;
int w[305][305]={0};
int main()
{
	int n,k;
	cin>>n;
	while(n!=-1)
	{
		cin>>k;
		vector<int>adj[305];
		memset(w,-1,sizeof(w));
		int x,y,z;
		for(int i=0;i<k;i++)
		{
			cin>>x>>y>>z;
			if(w[x][y]==-1)
			{adj[x].push_back(y);
			 adj[y].push_back(x);}
			if(w[x][y]==-1||w[x][y]>z)
			{
				w[x][y]=z;
				w[y][x]=z;
			}
		}
		int sol=-1;
		vector<int>ans;
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++)
			if(w[i][j]!=-1){
				//cout<<"s:"<<sol<<endl;
		        int par[305]={0};
		        int d[305]={0};
		        int tmp_w=w[i][j];
		        w[i][j]=-1;
		        w[j][i]=-1;
		        for(int l=0;l<=n;l++)
		        	d[l]=1000000000;
		        set<pair<int,int> >s;
		        s.insert(make_pair(0,i));
		        d[i]=0;
		        par[i]=-1;
		        while(!s.empty())
		        {
		        	z=(*s.begin()).first;
		        	x=(*s.begin()).second;
		        	s.erase(s.begin());
		        	if(d[x]==z)
		        	for(int m=0;m<adj[x].size();m++)
		        	{
		        		if(w[x][adj[x][m]]!=-1&&d[adj[x][m]]>z+w[x][adj[x][m]])
		        		{
		        			d[adj[x][m]]=z+w[x][adj[x][m]];
		        			par[adj[x][m]]=x;
		        			s.insert(make_pair(d[adj[x][m]],adj[x][m]));
		        		}
		        	}
		        }
		        if((sol==-1||sol>d[j]+tmp_w)&&d[j]!=1000000000)
		        {
		        	sol=d[j]+tmp_w;
		        	ans.clear();
		        	x=j;
		        	while(x!=-1)
		        	{
		        		ans.push_back(x);
		        		x=par[x];
		        	}
		        }
		      //  cout<<i<<" "<<j<<" we: "<<d[j]+tmp_w<<" "<<d[j]<<" "<<sol<<endl;
		        w[i][j]=tmp_w;
		        w[j][i]=tmp_w;

		    }
		    if(sol==-1||k<=2)
		    {
		    	cout<<"No solution.\n";
		    }
		    else 
		    {
		    	//bcout<<sol<<endl;
		    	for(int i=0;i<ans.size();i++)
		    		cout<<ans[i]<<" ";
		    	cout<<endl;
		    }



		cin>>n;
	}
}