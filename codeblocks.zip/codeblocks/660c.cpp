#include<iostream>
#include<algorithm>
#include<vector>
#include<math.h>
#include<set>
#include<string>
#include<string.h>
using namespace std;
vector<int>v;
int main()
{
	int n,k,x,sol=0,ctr=0,X=0,Y=-1;
	cin>>n>>k;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		v.push_back(x);
	}
	int a=0,b=0;
	ctr=v[0]^1;

	while(b!=v.size())
	{
		
		if(ctr>k)
		{
			ctr-=(v[a]^1);
			a++;
		}
		else
		{
			//cout<<a<<".."<<b<<endl;
			if(sol<b-a+1)
			{
				sol=b-a+1;
				X=a;
				Y=b;
			}
			b++;
			if(b!=v.size())
			ctr+=(v[b]^1);
		}
	}
	for(int i=X;i<=Y;i++)
	{
		v[i]=1;
	}
	cout<<sol<<endl;
	for(int i=0;i<n;i++)
	{
		cout<<v[i]<<" ";
	}
}