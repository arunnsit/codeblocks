#include<iostream>
#include<vector>
using namespace std;
vector<int>adj[200];
int mark[200],visit[200],c=0;
void dfs(int u)
{
	visit[u]=1;
	c=0;
	for(int i=0;i<adj[u].size();i++)
	if(visit[adj[u][i]]==0){
		dfs(adj[u][i]);
	}
	cout<<u<<" ";
}
int main()
{
	int n,x;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		while(x!=0)
		{
			adj[x].push_back(i);
			mark[i]++;
			cin>>x;
		}
	}
	for(int i=1;i<=n;i++)
	if(mark[i]==0&&visit[i]==0){
		dfs(i);
	}
}