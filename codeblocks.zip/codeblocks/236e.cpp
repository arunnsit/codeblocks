#include<iostream>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<string>
#define N 500009
using namespace std;
vector<int>adj[N];
map<int,int>m[26][N];
string a;
int main()
{
	int t,n,m,x,y;
	cin>>n;
	for(int i=2;i<=n;i++)
	{
		cin>>x;
		adj[x].push_back(i);
		adj[i].push_back(x);
	}
	cin>>a;
	
}