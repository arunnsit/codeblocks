#include<iostream>
#include<string>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
using namespace std;
int main()
{
	int ch=0,prev=0;
	int n,x;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		if(prev>x)
			break;
		if((x-prev)%2==0)
		{
			prev=0;
		}
		else prev=1;
		//cout<<x<<".."<<prev<<endl;
	}
	if(!prev)
		cout<<"YES\n";
	else cout<<"NO\n";
}