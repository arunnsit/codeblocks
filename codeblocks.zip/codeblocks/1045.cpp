#include<iostream>
#include<vector>
#define N 1009
using namespace std;
vector<int>adj[N];
pair<int,int> res;
pair<int,int> dfs(int u,int p,int len,int level)
{
	int decison=len;
	int can=0;
	int point=N,r,mos=0;
	pair<int,int> res,x;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		mos=1;
		x=dfs(adj[u][i],u,len^1,level+1);
		r=x.first;
		if(len==r)
		{
			can=1;
		}
		if(r==0&&level==1)
		{
			point=min(point,adj[u][i]);
		}
	}
	if(!mos)
	{
		point=u;
	}
	//cout<<"at: "<<u<<" "<<decison<<" "<<can<<" "<<point<<endl;
	if(decison==1&&can)
	{
		return make_pair(decison,N);
	}
	else if(decison==0&&can)
	{
		return make_pair(decison,point);
	}
	else if(decison==1&&!can)
	{
		return make_pair(decison^1,point);
	}
	else
	{
		return make_pair(decison^1,N);
	}
}
void input_tree_undir(int n)
{
	int x,y;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
}
int main()
{
	int n,k,u,x=0;
	cin>>n>>k;
	input_tree_undir(n);
	res=dfs(k,0,0,1);
	if(res.first==0)
	{
		cout<<"First player wins flying to airport "<<res.second<<endl;
	}
	else cout<<"First player loses\n";
}