#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<int>v[300000];
int x=0;
int mark[300000]={0};
void dfs(int u)
{
	for(int i=0)
}
int main()
{
	int n,c;
	cin>>n;
	char a[5];
	for(int i=0;i<n;i++)
	{
		cin>>a;
		c=a[0];
		v[a[0]].push_back(a[1]);
		v[a[1]].push_back(a[2]);
		mark[a[0]]++;
		mark[a[2]]--;
	}
	x=n+2;
	int y=0;
	for(int i=0;i<=256;i++)
		if(mark[i])
			y=i;
    if(!y)
    {
    	y=c;
    }	

}
