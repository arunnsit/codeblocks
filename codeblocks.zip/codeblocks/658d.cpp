#include<iostream>
#include<vector>
#include<algorithm>
#define N 1000000
using namespace std;
long long int mod1=1000000007,mod2=1000000009;
long long int pow_bhaji(long long int x,long long int y,long long int mod)
{
	long long int w;
	if(y==0)
		return 1;
	if(y&1)
		{
			w=pow_bhaji(x,(y-1)/2,mod)%mod;
			return (((x*w)%mod)*w)%mod;
		}
	else 
		{
			w=pow_bhaji(x,(y)/2,mod)%mod;
			return (w*w)%mod;
		}
}
long long int v[N],terms1[N],terms2[N];
int main()
{
	long long int n,k,sum2=0,sum1=0,p1=1,p2=1,X,Y,sol=0;
	cin>>n>>k;
	for(int i=0;i<=n;i++)
	{
		cin>>v[i];
		terms1[i]=(mod1+v[i])%mod1;
		terms2[i]=(mod2+v[i])%mod2;
		terms1[i]=(terms1[i]*pow_bhaji(2,i,mod1))%mod1;
		terms2[i]=(terms2[i]*pow_bhaji(2,i,mod2))%mod2;
		sum1=(sum1+terms1[i])%mod1;
		sum2=(sum2+terms2[i])%mod2;
	}
	for(int i=0;i<=n;i++)
	{
		X=(((sum1-terms1[i]+mod1)%mod1)*pow_bhaji(pow_bhaji(2,i,mod1),mod1-2,mod1))%mod1;
		Y=(((sum2-terms2[i]+mod2)%mod2)*pow_bhaji(pow_bhaji(2,i,mod2),mod2-2,mod2))%mod2;
		//cout<<X<<" "<<Y<<" "<<v[i]+X-mod1<<endl;
		if(X==Y)
		{
			if(X<=k&&X>=-k)
			{
				if(i==n)
				{
					if(X!=0)
						sol++;
				}
				else sol++;
			}
		}
		else if(X+2==Y)
		{
			if((mod1-X)<=k&&mod1-X>=-k)
			{
				if(i==n)
				{
					if(mod1-X!=mod1)
						sol++;
				}
				else sol++;
			}
		}

	}
	cout<<sol<<endl;
}