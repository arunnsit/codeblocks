#include<iostream>
#include<math.h>
using namespace std;
int main()
{
	int n,x;
	long long int sum=0;
	cin>>n;
	x=sqrt(n);
	sum=n;
	for(int i=2;i<=x+2;i++)
	{
		if(n%i==0)
		{
			while(n%i==0)
			{ 
			   n/=i;
			   sum+=n;
			}
		}
	}
	if(n!=1)
		sum++;
	cout<<sum<<endl;
}