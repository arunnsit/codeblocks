#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
int arr[2000000]={0};
int main()
{
	int n,q,tot=0,odder=0,ever=0,typ,x,isod=1,acpos=0;
	scanf("%d %d",&n,&q);
	while(q--)
	{
		scanf("%d",&typ);
		if(typ==1)
		{
			scanf("%d",&x);
			tot+=x;

			if(isod==1)
			{
				if((abs(x)&1)==1)
				{
					isod=0;
				}
			}
			else
			{
				if((abs(x)&1)==1)
				{
					isod=1;
				}
			}
		}
		else
		{
			if(isod==1)
			{
				odder+=1;
				ever-=1;

			}
			else
			{
				odder-=1;
				ever+=1;
			}
			isod^=1;
		}
	}
	//cout<<tot<<" "<<odder<<" "<<ever<<endl;
	for(int i=1;i<=n;i++)
	{
		if((i&1)!=0)
		{
			acpos=(i+(tot+odder)%n+n-1)%n+1;
		}
		else acpos=(i+(tot+ever)%n+n-1)%n+1;
		//cout<<acpos<<endl;
		arr[acpos]=i;
	}
	for(int i=1;i<=n;i++)
	  printf("%d ",arr[i]);

}