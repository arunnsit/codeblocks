#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<stdio.h>
using namespace std;
int main()
{
	char c[10];
	long long int n,x,tmp,coun=0;
	scanf("%lld %lld",&n,&x);
	while(n--)
	{
		scanf("%s %lld",c,&tmp);
		if(c[0]=='+')
		{
			x+=tmp;
		}
		else
		{
			if(x-tmp>=0)
			x-=tmp;
			else
			{
				coun++;
			}
		}
	}
	printf("%lld %lld\n",x,coun);

}