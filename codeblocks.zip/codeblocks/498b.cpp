#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<iomanip>
using namespace std;
vector<pair<double,double> >v;
int N ;
double dp[5005][5005];
int main()
{
	int n,t;
	cin>>n>>t;
	for(int i=0;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		v.push_back(make_pair(x,y));
	}
	for(int i=0;i<=n;i++)
		dp[i][0]=n-i;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=t;j++)
		{
			double x=0,y=v[i-1].first/100.0,yn=1,del;
			for(int k=1;k<=v[i-1].second-1;k++)
			{
				if(j-k<0)
				del=y*yn*(n-i);
				else	
				del=y*yn*dp[i-1][j-k];
				x+=del;
				yn*=(1-v[i-1].first/100.0);
				//if(del<(1e-15))break;
			}
			if(j-(int)v[i-1].second<0)
			dp[i][j]=x+yn*(n-i);
			else	
			dp[i][j]=x+yn*dp[i-1][j-(int)v[i-1].second];
		}
	}
	cout<<fixed;
	cout<<setprecision(10)<<dp[n][t]<<endl;

}