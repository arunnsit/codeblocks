#include<iostream>
#include<vector>
using namespace std;
int main()
{
	long long int t,x,s;
	cin>>t>>s>>x;
	if(((x-t)%s==0&&x-t>=0)||((x-t-1)%s==0&&x-t-1>=0&&t+1!=x))
	{
		cout<<"YES\n";
	}
	else cout<<"NO\n";
}