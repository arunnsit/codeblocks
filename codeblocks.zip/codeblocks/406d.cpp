#include<iostream>
#include<set>
#include<algorithm>
#include<stack>
#define LOGN 19
using namespace std;
struct point{
	long long x , y;
	point(long long _x = 0 , long long _y = 0){
		x = _x;
		y = _y;
	}
	point operator - (const point &o) const {
		return point(x - o.x , y - o.y);
	}
};
long long cross(point a , point b){
	return a.x * b.y - a.y * b.x;
}
bool convex(point a , point b , point c){
	return cross(b - a , c - a) <= 0;
}
point in[100009];
long long int s[100009],level[100009],dp[32][100009],sz=0,n;
void preprocess()
{
	for(int i=1;i<LOGN;i++)
		for(int j=0;j<n;j++)
			dp[i][j] = dp[i-1][dp[i-1][j]];
}
int lca(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	//cout<<"le"<<level[b]<<" "<<level[a]<<endl;
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			b=dp[i][b];
	if(a==b)return a;
	for(int i=LOGN-1;i>=0;i--)
		if(dp[i][a]!=dp[i][b])
			a=dp[i][a],b=dp[i][b];
	return dp[0][a];
}
int main()
{
	 std::ios::sync_with_stdio(false);
	int m,x,y;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>in[i].x>>in[i].y;
	}
	dp[0][n-1]=n-1;
	s[++sz]=n-1;
	level[n-1]=0;
	for(int i=n-2;i>=0;i--)
	{
		while(sz>=2&&!convex(in[i],in[s[sz]],in[s[sz-1]]))
		{
			sz--;
		}
		dp[0][i]=s[sz];
		level[i]=level[s[sz]]+1;
		s[++sz]=i;
	//	cout<<"i:"<<i<<" "<<dp[0][i]<<" "<<level[i]<<endl;
	}
	preprocess();
	cin>>m;
	while(m--)
	{
		cin>>x>>y;
		cout<<lca(x-1,y-1)+1<<endl;
	}
}