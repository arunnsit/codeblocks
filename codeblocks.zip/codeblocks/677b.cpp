#include<iostream>
#include<algorithm>
#include<string.h>
#include<string>
#include<set>
#include<vector>
using namespace std;
int a[100000]={0};
int main ()
{
	int n,t,x,y,z,h,k;
	cin>>n>>h>>k;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	int i=0,c=0;
	long long int contain=0,second=0,nsmash=0,space,need;
	while(i<n)
	{
		while(contain+a[i]<=h&&i<n)
		{
			contain+=a[i];
			i++;
		}
		if(i==n)
		{
			second+=(contain+k-1)/k;
		}
		else
		{
		    space=h-contain;
		    need=a[i]-space;
		    nsmash=((need+k-1)/k);
		    second+=nsmash;
		    contain-=k*nsmash;
		    contain=max(contain,0LL);
	    }
	    //cout<<"cont:"<<contain<<" "<<second<<endl;
	}

	cout<<second<<endl;
}