#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
#define N 100009
struct bit
{
	vector<long long int> bit;
	void update(int pos,int add,int n)
	{
		
		int ind=pos+1;
		while(ind<=n)
		{
			
			bit[ind]+=add;
			ind=ind+(ind&(-ind));
		}
	}
	long long int query(int pos)
	{
		int ind=pos+1;
		long long int sum=0;
		while(ind!=0)
		{
			//cout<<"pos:"<<ind<<" "<<bit.size()<<endl;
			sum+=bit[ind];
			ind=ind-(ind&(-ind));
		}
		return sum;
	}
};
bit trees[N],bapu_tree;
vector<int>adj[N],pols[N];
int level[N];
pair<int,int>in[N];
void dfs(int u,int p,int master)
{
	pols[master].push_back(u);
	in[u]=make_pair(level[u],master);
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		level[adj[u][i]]=level[u]+1;
		dfs(adj[u][i],u,master);
	}
}
int main()
{
	int n,q;
	cin>>n>>q;
	for(int i=0;i<n-1;i++)
	{
		int x,y;
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	level[1]=0;
	bapu_tree.bit.resize(n+10,0);
	for(int i=0;i<adj[1].size();i++)
	{
		level[adj[1][i]]=1;
		dfs(adj[1][i],1,i+1);
		trees[i+1].bit.resize(pols[i+1].size()+10,0);
	}
	while(q--)
	{
		int type,v,x,d;
		cin>>type;
		if(type==0)
		{
			cin>>v>>x>>d;
			int w=in[v].second,l=level[v];
			if(v==1)
			{
				bapu_tree.update(0,x,n+3);
				bapu_tree.update(d+1,-x,n+3);
				continue;
			}
			if(level[v]>d)
			{
				//cout<<"up1\n";
				trees[w].update(l-d,x,pols[w].size()+3);
				trees[w].update(l+1,-x,pols[w].size()+3);
			}
			else
			{
				//cout<<"up2\n";
				int up=d-level[v];
				//cout<<"hoo:"<<w<<endl;
				trees[w].update(1,x,pols[w].size()+3);
				trees[w].update(l+1,-x,pols[w].size()+3);
				bapu_tree.update(0,x,n+3);
				bapu_tree.update(up+1,-x,n+3);
				trees[w].update(1,-x,pols[w].size()+3);
				trees[w].update(up+1,x,pols[w].size()+3);
			}
			if(pols[w].size()-level[v]<=d)
			{
				//cout<<"down1\n";
				trees[w].update(l+1,x,pols[w].size()+3);
				trees[w].update(pols[w].size()+1,-x,pols[w].size()+3);
			}
			else
			{
				//cout<<"down2\n";
				int up=d-level[v];
				trees[w].update(l+1,x,pols[w].size()+3);
				trees[w].update(l+d+1,-x,pols[w].size()+3);
			}
		}
		else
		{
			
			cin>>v;
			int w=in[v].second,l=level[v];
			if(v==1)
			{
				cout<<bapu_tree.query(0)<<endl;
			}
			else cout<<bapu_tree.query(l)+trees[w].query(l)<<endl;
		}
	}
}