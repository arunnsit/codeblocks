#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
using namespace std;
vector<int>v[30];
int x[100009][27]={0},y[100009][27]={0};
int palins[100009][40],pref[100009][40];
long long int inbet[100009][40]={0},u,l1,r1,todel,del;
int main()
{
	string a;
	int k;
	cin>>a>>k;
	for(int i=0;i<a.length();i++)
	{
		for(int j=0;j<26;j++)
		{
			if(a[i]-'a'==j)
			{
				x[i+1][j]=i+1;
			}
			else x[i+1][j]=x[i][j];
		}	
	}
	for(int i=0;i<a.length();i++)
	{
		for(int j=0;j<26;j++)
		{
			if(x[i][j]!=0)
			u=x[i+1][j]-x[i][j]-1;
		    else u=0;
			inbet[i+1][j]+=((u)*(u-1))/2+inbet[i][j];
			if(j==2)
			cout<<"u:"<<u<<endl;
		}	
	}
	cout<<" xx: "<<inbet[a.length()][0]<<endl;
	for(int i=a.length()-1;i>=0;i--)
	{
		for(int j=0;j<26;j++)
		{
			if(a[i]-'a'==j)
			{
				y[i+1][j]=i+1;
			}
			else y[i+1][j]=y[i+2][j];
		}	
	}
	vector<int>v;
	for(int i=0;i<a.length();i++)
	{
		//oddlength
		for(int j=0;j<=k/2;j++)
		if(i+j<a.length()&&i-j>=0&&a[i+j]==a[i-j]&&2*j+1<=k)
		{
			palins[i+1][2*j+1]++;
		}
		for(int j=0;j<=k/2;j++)
		if(i+1+j<a.length()&&i-j>=0&&a[i+1+j]==a[i-j]&&2*j+2<=k)
		{
			palins[i+1][2*j+2]++;
		}
	}
	for(int i=1;i<=a.length();i++)
	{
		for(int j=0;j<=k;j++)
		{
			pref[i][j]+=palins[i][j]+pref[i-1][j];
			cout<<pref[i][j]<<" ";
		}
		cout<<endl;
	}
	int type,l,r,m;
	char c;
	cin>>m;
	while(m--)
	{
		cin>>type>>l>>r;
		if(type==2)
		{

		}
		else
		{
			cin>>c;
			l1=y[l][c-'a']-l;
			r1=r-x[r][c-'a'];
			del=r-l+1;
			todel=inbet[y[l][c-'a']][c-'a']-inbet[x[r][c-'a']-1][c-'a'];
			cout<<y[l][c-'a']<<" "<<x[r][c-'a']<<" "<<todel<<" "<<del<<endl;
			cout<<(del*(del-1))/2-((l1*(l1-1))/2+(r1*(r1-1))/2+todel)<<endl;
		}
	}
}