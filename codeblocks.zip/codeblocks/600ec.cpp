#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<string>
#define N 100009
using namespace std;
vector<int>adj[N];
vector<pair<int,int > >q[N];
string a;
long long int sub[N],maxx,can;
long long int sol[N];
void sub_solve(int u,int p)
{
	sub[u]=1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		sub_solve(adj[u][i],u);
		sub[u]+=sub[adj[u][i]];
	}
}
int big[N],cnt[N],col[N];
void add(int u,int p,int x)
{
	cout<<"add:"<<u<<" "<<x<<endl;
	cnt[col[u]]+=x;
	if(x==1)
	{if(maxx==cnt[col[u]])
		can+=col[u];
	else if(maxx<cnt[col[u]])
	{
		can=col[u];
		maxx=cnt[col[u]];
	}}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&big[adj[u][i]]==0)
	{
		add(adj[u][i],u,x);
	}
}
void dfs(int u,int p,int keep)
{
	int bigsiz=-1,bigboy=-1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigsiz<sub[adj[u][i]])
	{
		bigsiz=sub[adj[u][i]];
		bigboy=adj[u][i];
	}
	cout<<"dfs:"<<u<<" "<<bigboy<<" "<<keep<<endl;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigboy!=adj[u][i])
	{
		dfs(adj[u][i],u,0);
	}
	if(bigboy!=-1)
	{
		dfs(bigboy,u,1);
		big[bigboy]=1;
	}
	add(u,p,1);
	sol[u]=can;
	if(bigboy!=-1)
	{
		big[bigboy]=0;
		cout<<"removed:"<<bigboy<<endl;
	}
	for(int i=0;i<=15;i++)
		cout<<big[i];
	cout<<endl;
	if(keep==0)
	{
		add(u,p,-1);
		maxx=0;
		can=0;
	}
}
int main()
{
	int n,m,x,y;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>col[i];
	}
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	sub_solve(1,1);
	dfs(1,1,0);
	for(int i=1;i<=n;i++)
		cout<<sol[i]<<" ";
}