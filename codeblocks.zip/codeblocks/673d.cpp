#include<iostream>
using namespace std;
int mark[2000]={0};
int n,m,a,b,c,d;
int par[2000]={0};
int nex()
{
	for(int i=1;i<=n;i++)
	{
		if(!mark[i])
			return i;
	}
	return -1;
}
int main()
{
	cin>>n>>m;
	cin>>a>>b>>c>>d;
	if(m<=n||n<=4)
		cout<<-1<<endl;
	else
	{
		mark[a]++;
		mark[b]++;
		mark[c]++;
		mark[d]++;
		int mid=nex();
		mark[mid]++;
		cout<<a<<" "<<c<<" "<<mid<<" "<<d<<" ";
		for(int i=1;i<=n;i++)
			if(!mark[i])
				cout<<i<<" ";
		cout<<b<<endl;
		cout<<c<<" "<<a<<" "<<mid<<" "<<b<<" ";
		for(int i=n;i>=1;i--)
			if(!mark[i])
				cout<<i<<" ";
		cout<<d<<endl;	
	}
}