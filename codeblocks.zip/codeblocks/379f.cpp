#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
#include<set>
#define N 2000000
#define LOGN 20
using  namespace std;
int dp[LOGN][N],lr,rr,dlen,level[N];
int lca(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			b=dp[i][b];
	if(a==b)return a;
	for(int i=LOGN-1;i>=0;i--)
		if(dp[i][a]!=dp[i][b])
			a=dp[i][a],b=dp[i][b];
	return dp[0][a];
}
int kth_ancestor(int b,int k)
{
	for(int i=0;i<LOGN;i++)
		if(k&(1<<i))
			b=dp[i][b];
	return b;	
}
int dist(int x,int y)
{
	return level[x]+level[y]-2*level[lca(x,y)];
}
int main()
{
	ios_base::sync_with_stdio(false);   cin.tie(NULL);
	dp[0][1]=0;
	dp[0][2]=1;
	dp[0][3]=1;
	dp[0][4]=1;
	lr=2;
	rr=3;
	dlen=2;
	level[2]=1;
	level[3]=1;
	level[4]=1;
	int q;
	cin>>q;
	int n=4;
	while(q--)
	{
		int x,y;
		cin>>x;
		y=n+1;
		dp[0][y]=x;
		for(int i=1;i<LOGN;i++)
		{
			dp[i][y]=kth_ancestor(x,(1<<i)-1);
		}
		level[y]=level[x]+1;
		y=n+2;
		dp[0][y]=x;
		for(int i=1;i<LOGN;i++)
		{
			dp[i][y]=kth_ancestor(x,(1<<i)-1);
		}
		level[y]=level[x]+1;
		int d1=dist(lr,y),d2=dist(rr,y);
		if(d2>=d1&&d2>=dlen)
		{
			lr=y;
			dlen=d2;
		}
		else if(d1>=d2&&d1>=dlen)
		{
			rr=y;
			dlen=d1;
		}
		n+=2;
		cout<<dlen<<endl;
		//cout<<dlen<<" "<<lr<<" "<<rr<<" "<<d1<<" "<<d2<<endl;
	}
}