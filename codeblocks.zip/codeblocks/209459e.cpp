#include<iostream>
#include<algorithm>
#include<vector>
#define N 100009
using namespace std;
int tree[20*N];
void make_tree(int cur,int l,int r)
{
	if(l==r)
	{
		tree[cur]=1;
		return ;
	}
	int mid=l+(r-l)/2;
	make_tree(2*cur+1,l,mid);
	make_tree(2*cur+2,mid+1,r);
	tree[cur]=tree[2*cur+1]+tree[2*cur+2];
	return ;
}
int pointq(int cur,int l,int r,int x)
{
	if(l==r)
	{
		return tree[cur];
	}
	int mid=l+(r-l)/2;
	if(mid>=x)
		return pointq(2*cur+1,l,mid,x);
	else
		return pointq(2*cur+2,mid+1,r,x);
}
void point_up(int cur,int l,int r,int x,int v)
{
	if(l==r)
	{
		tree[cur]+=v;
		return;
	}
	int mid=l+(r-l)/2;
	if(mid>=x)
	point_up(2*cur+1,l,mid,x,v);
	else point_up(2*cur+2,mid+1,r,x,v);
	tree[cur]=tree[2*cur+1]+tree[2*cur+2];
}
int query(int cur,int l,int r,int x,int y)
{
	if(y<l||x>r)
		return 0;
	if(x<=l&&r<=y)
		return tree[cur];
	int mid=l+(r-l)/2;
	return query(2*cur+1,l,mid,x,y)+query(2*cur+2,mid+1,r,x,y);
}
int main()
{
	int n,q,type,x,y,cs=1,ce=n,a,b,cops,cope;
	cin>>n>>q;
	make_tree(0,1,n);
	cs=1,ce=n;
	while(q--)
	{
		cin>>type;
		if(type==1)
		{
			cin>>x;
			if(ce<cs)
			{
				if((cs-ce+1)/2>=x)
				{
					cops=cs-2*x+1;
					cope=cs;
					while(cops<cope)
					{
						a=pointq(0,1,n,cope);
						point_up(0,1,n,cops,a);
						cops++;
						cope--;
					}
					cs-=x;
				}
				else
				{
					x=(cs-ce+1)-x;
					cops=ce;
					cope=ce+2*x-1;
					while(cops<cope)
					{
						a=pointq(0,1,n,cops);
						point_up(0,1,n,cope,a);
						cops++;
						cope--;
					}
					ce+=x;
					swap(ce,cs);
				}
			}
			else
			{
				if((ce-cs+1)/2>=x)
				{
					cops=cs;
					cope=cs+2*x-1;
					while(cops<cope)
					{
						a=pointq(0,1,n,cops);
						//cout<<a<<"..";
						point_up(0,1,n,cope,a);
						cops++;
						cope--;
					}
					cout<<endl;
					cs+=x;
				}
				else
				{
					x=(ce-cs+1)-x;
					cops=ce-2*x+1;
					cope=ce;
					while(cops<cope)
					{
						//cout<<"check"<<endl;
						a=pointq(0,1,n,cope);
						point_up(0,1,n,cops,a);
						cops++;
						cope--;
					}
					ce-=x;
					swap(ce,cs);
				}
			}
		}
		else
		{
			cin>>x>>y;
			if(ce>cs)
			{
				cout<<query(0,1,n,cs+x,cs+y-1)<<endl;
			}
			else
			{
				cout<<query(0,1,n,cs-y+1,cs-x)<<endl;
				//cout<<"querying:"<<cs-y+1<<" "<<cs-x<<" "<<query(0,1,n,6,6)<<endl;
			}
		}
		//cout<<cs<<".."<<ce<<endl;
		//for(int i=min(cs,ce);i<=max(cs,ce);i++)
		//	cout<<query(0,1,n,i,i)<<"..";
		//cout<<endl;
		//cout<<query(0,1,n,1,n)<<" "<<endl;
	}
}