#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
	int n;
	cin>>n;
	string s,sol;
	cin>>s;
	//reverse(s.begin(),s.end());
	{
		int c=(s.size()&1)^1;
		for(int i=0;i<n;i++)
		{
			if(c==1)
			{
				sol.insert(sol.begin(),s[i]);
			}
			else sol.push_back(s[i]);
			c^=1;
		}
	}
	cout<<sol<<endl;
}