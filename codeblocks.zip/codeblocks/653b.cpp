#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<algorithm>
#include<string.h>
using namespace std;
vector<string>s;
char a[7]="abcdef";
vector<pair<string,string> >ops; 
void fill(string tmp,int n)
{
	if(n==0)
	{
		s.push_back(tmp);
		return ;
	}
	string o=tmp;
	for(int i=0;i<6;i++)
	{
		o=tmp;
		o.push_back(a[i]);
		fill(o,n-1);
	}
}
int ch=0;
void operate(string curr)
{
	//cout<<curr<<".."<<endl;
	if(curr.size()==1)
	{
		if(curr[0]=='a')
		{
			ch=1;
		}
		return ;
	}
	string temp=curr;
	for(int i=0;i<ops.size();i++)
	{
		temp=curr;
		if(temp[0]==ops[i].first[0]&&temp[1]==ops[i].first[1])
		{
			string ola;
			ola.push_back(ops[i].second[0]);
			for(int k=2;k<temp.size();k++)
			{
				ola.push_back(temp[k]);
			}
			operate(ola);
		}
	}
}
int main()
{
	int n,q;
	cin>>n>>q;
	string a="",b,c;
	fill(a,n);
	//cout<<s.size()<<endl;
	//s.push_back("cab");
	for(int i=0;i<q;i++)
	{
		cin>>b>>c;
		ops.push_back(make_pair(b,c));
	}
	int coun=0;
	for(int i=0;i<s.size();i++)
	{
		ch=0;
		operate(s[i]);
		if(ch)
		{
			//cout<<s[i]<<endl;
			coun++;
		}
	}
	cout<<coun<<endl;
}