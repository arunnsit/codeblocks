#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<string>
#include<unordered_map>
#include<string.h>
using namespace std;
#define N 208
int visit[N],p[N];
vector<int>adj[N];
vector<pair<int,int> >ps[N];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
		p[i]=x;
		adj[x].push_back(i);
		adj[i].push_back(x);
	}
	for(int i=2;i<=n+2;i++)
	{
		if(!ps[i].size())
		for(int j=i;j<=n+2;j+=i)
		{
			int x=j,c=0;
			while(x%i==0)
			{
				x/=i;
				c++;
			}
			ps[j].push_back(make_pair(i,c));
		}
	}
	int ch=0;
	long long int 
	for(int i=1;i<=n;i++)
	if(!visit[i])
	{
		int mast=i;
		int l=1;
		while(p[mast]!=i) 
		{
			if(visit[p])
			{
				ch=1;
				break;
			}
			visit[p]=1;
			p=p[mast];
			l++;
		}
		int 
	}
}