#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
struct node
{
	long long int have,need,rem,coun,nos;
	
};
bool cmp(node a,node b)
{
	return a.coun<b.coun;
}
node a[100009];

int main()
{
	long long int n,k;
	cin>>n>>k;
	for(int i=0;i<n;i++)
		cin>>a[i].need;
	for(int i=0;i<n;i++)
		cin>>a[i].have;
	for(int i=0;i<n;i++)
		{
			a[i].coun=a[i].have/a[i].need;
			a[i].rem=a[i].have%a[i].need;
		}
	sort(a,a+n,cmp);
	long long int need;
	long long int sum=0,prev=a[0].coun,overcome,i;
	for( i=0;i<n;i++)
	{
		//cout<<"k:"<<k<<endl;
		overcome=(a[i].coun+1-prev)*sum;
		if(overcome>=0&&overcome<=k)
		{
			k-=overcome;
			prev=a[i].coun+1;
		}
		else
		{
		 prev+=k/sum;
		 break;
		}
		need=a[i].need-a[i].rem;
		if(need>=0&&need<=k)
		{
			k-=need;
			sum+=a[i].need;
			prev=a[i].coun+1;
		}
		else 
			break;
	}
	//printf("%lld\n",k);
	if(i==n)
	{
		cout<<prev+(k/sum)<<endl;
	}
	else
	{
		for(;i<n;i++)
		{
			prev=min(prev,a[i].coun);
		}
		cout<<prev<<endl;
	}
}