#include<iostream>
#include<algorithm>
#include<vector>
#include<unordered_map>
using namespace std;
vector<int>sol;
unordered_map<int,int>mark;
int main()
{
	int n,m,tmp;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		cin>>tmp;
		mark[tmp]++;
	}
	int curr=1;
	while(m-curr>=0)
	{
		if(!mark[curr])
		{
			sol.push_back(curr);
			m-=curr;
		}
		curr++;
	}
	cout<<sol.size()<<endl;

	for(int i=0;i<sol.size();i++)
{
	cout<<sol[i]<<" ";
}

	
	

}