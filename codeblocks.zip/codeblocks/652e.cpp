#include<iostream>
#include<vector>
#include<set>
#define N 400000
using namespace std;
vector<int>adj[N];
vector<pair<int,int> >white;
int D1[N],D2[N];
int main()
{
	int n,m,x,y,z,a,b,x1,x2,y1,y2;
	cin>>n>>m;

	for(int i=0;i<m;i++)
	{
		cin>>x>>y>>z;
		adj[x].push_back(y);
		adj[y].push_back(x);
		if(z)
			white.push_back(make_pair(x,y));
	}
	cin>>a>>b;
	set<pair<int,int> >q;
	for(int i=0;i<=n;i++)
		D1[i]=99999999,D2[i]=99999999;
	D1[a]=0;
	q.insert(make_pair(0,a));
	while(!q.empty())
	{
		x=(*q.begin()).first;
		y=(*q.begin()).second;
		q.erase(q.begin());
		if(D1[y]==x)
		{
			for(int i=0;i<adj[y].size();i++)
			{
				if(D1[adj[y][i]]>x+1)
				{
					D1[adj[y][i]]=x+1;
					q.insert(make_pair(D1[adj[y][i]],adj[y][i]));
				}
			}
		}
	}
	D2[b]=0;
	q.insert(make_pair(0,b));
	while(!q.empty())
	{
		x=(*q.begin()).first;
		y=(*q.begin()).second;
		q.erase(q.begin());
		if(D2[y]==x)
		{
			for(int i=0;i<adj[y].size();i++)
			{
				if(D2[adj[y][i]]>x+1)
				{
					D2[adj[y][i]]=x+1;
					q.insert(make_pair(D2[adj[y][i]],adj[y][i]));
				}
			}
		}
	}
	int c=0;
	for(int i=0;i<white.size();i++)
	{
		x1=D1[white[i].first];
		x2=D2[white[i].first];

		y1=D1[white[i].second];
		y2=D2[white[i].second];

		if((x1+1==y1&&x2==y2+1)||(y1+1==x1&&y2==x2+1))
			c=1;
	}
	if(c)
		cout<<"YES\n";
	else cout<<"NO\n";
}