#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<vector>
#include<set>
#define N 200009
using namespace std;
vector<int> adj[N],w[N];
int dp[N]={0};
int l[N]={0};
int col[N]={0},tc=0;
void dfs(int start,int parent,int len,int color)
{
	l[start]=len;
	col[start]=color;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=parent){
		dfs(adj[start][i],start,len+1,color+w[start][i]);
		tc+=w[start][i];
	}
}
int main()
{
	int n,i,j,x,y;
	cin>>n;
	for(i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		w[y].push_back(1);
		w[x].push_back(0);
	}
	dfs(1,-1,0,0);
	int ms=n;
	for(int i=1;i<=n;i++)
	{
		ms=min(ms,l[i]-col[i]+tc-col[i]);
	}
	set<int> s;
	cout<<ms<<endl;
	for(int i=1;i<=n;i++)
		if(l[i]-col[i]+tc-col[i]==ms)
			s.insert(i);
	for(set<int>::iterator it=s.begin();it!=s.end();it++)
	cout<<*it<<" ";	


}
