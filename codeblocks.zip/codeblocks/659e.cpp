#include<iostream>
#include<vector>
#include<algorithm>
#define N 100008
using namespace std;
vector<int>adj[N],num[N];
int edge[N],vis[N],m,n,x,y,degree[N],in[N],ed=0,vv=0;
vector<pair<int,int> >v;
void dfs(int u,int p)
{
	vis[u]=1;
	for(int i=0;i<adj[u].size();i++)
	{   
		if(!vis[adj[u][i]])
		{
			dfs(adj[u][i],u);
			in[adj[u][i]]=1;
		}	
		else if(adj[u][i]!=p)
		{
			in[adj[u][i]]=1;
			ed=1;
			//cout<<"mark:"<<adj[u][i]<<endl;
		}
	}
}
int main()
{
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		degree[x]++;
		degree[y]++;
		num[x].push_back(i+1);
		num[y].push_back(i+1);
	}
	for(int i=1;i<=n;i++)
	{
		v.push_back(make_pair(i,degree[i]));
	}
	sort(v.begin(),v.end());
		int sol1=0;

	for(int i=0;i<v.size();i++)
	{
		if(!vis[v[i].first])
		{
			dfs(v[i].first,-1);
			if(!ed)
				sol1++;
		}
		ed=0;
	}
	cout<<sol1<<endl;
}