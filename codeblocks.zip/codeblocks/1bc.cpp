#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
	int t;
	cin>>t;
	for(int j=1;j<=t;j++)
	{
		string a,b;
		int maa=0,x=a.length(),y,ic=0;
		int p1[100]={0},p2[100]={0};
		cin>>a>>b;
		for(int i=a.length()-1;i>=0;i--)
		{
			p1[i]=x;
			p2[i]=x;
			if(a[i]!='?'&&b[i]!='?')
				x=i;
		}
		for(int i=0;i<a.length();i++)
		{
			if(a[i]=='?'&&b[i]=='?')
			{
				if(maa==0)
				{
					if(i+1<a.length()&&a[i+1]!='?'&&b[i+1]!='?')
					{
						if(a[i+1]>b[i+1])
						{
							if(abs(10+b[i+1]-'0'-(a[i+1]-'0'))<abs(a[i+1]-b[i+1]))
							{
								a[i]='0';
								b[i]='1';
								maa=-1;
							}
							else 
							{
								a[i]='0';
								b[i]='0';
							}
						}
						else
						{
							if(abs(10-b[i+1]+'0'+(a[i+1]-'0'))<abs(b[i+1]-a[i+1]))
							{
								a[i]='1';
								b[i]='0';
								maa=1;
							}
							else 
							{
								a[i]='0';
								b[i]='0';
							}
						}
					}
					else
					{
						a[i]='0';
						b[i]='0';
					}

				}
				else if(maa==1)
				{
					a[i]='0';
					b[i]='9';
				}
				else
				{
					a[i]='9';
					b[i]='0';
				}
			}
			else if(a[i]=='?')
			{
				if(maa==0)
				{
					ic=i;
					if(p1[ic]<a.length()&&a[p1[ic]]!='?'&&b[p1[ic]]!='?')
					{
						if(a[p1[ic]]>b[p1[ic]])
						{
							if(b[i]!='0'&&abs((b[i]-'0'-1)*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0'))<abs((b[i]-'0')*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0')))
							{
								a[i]=b[i]-1;
								maa=-1;
							}
							else
							{
								a[i]=b[i];
							}
						}
						else if(b[i]!='0'&&abs((b[i]-'0'-1)*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0'))==abs((b[i]-'0')*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0')))
						{
							if(p1[ic]+1<a.length())
						}
						else
						{
							if(b[i]!='9'&&abs((b[i]-'0'+1)*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0'))<abs((b[i]-'0')*10+(a[p1[ic]]-'0')-(b[i]-'0')*10-(b[p1[ic]]-'0')))
							{
								a[i]=b[i]+1;
								maa=1;
							}
							else
							{
								a[i]=b[i];
							}
						}
					}
					else
					{
						a[i]=b[i];
					}
				}
				else if(maa==1)
				{
					a[i]='0';
				}
				else 
				{
					a[i]='9';
				}
			}
			else if(b[i]=='?')
			{
				if(maa==0)
				{
					if(i+1<a.length()&&a[p1[ic]]!='?'&&b[p1[ic]]!='?')
					{
						if(b[p1[ic]]>a[p1[ic]])
						{
							if(a[i]!='0'&&abs((a[i]-'0'-1)*10+(b[p1[ic]]-'0')-(a[i]-'0')*10-(a[p1[ic]]-'0'))<=abs((a[i]-'0')*10+(b[p1[ic]]-'0')-(a[i]-'0')*10-(a[p1[ic]]-'0')))
							{
								b[i]=a[i]-1;
								maa=1;
							}
							else
							{
								b[i]=a[i];
							}
						}
						else
						{
							if(a[i]!='9'&&abs((a[i]-'0'+1)*10+(b[p1[ic]]-'0')-(a[i]-'0')*10-(a[p1[ic]]-'0'))<abs((a[i]-'0')*10+(b[p1[ic]]-'0')-(a[i]-'0')*10-(a[p1[ic]]-'0')))
							{
								b[i]=a[i]+1;
								maa=-1;
							}
							else
							{
								b[i]=a[i];
							}
						}
					}
					else
					{
						b[i]=a[i];
					}
				}
				else if(maa==1)
				{
					b[i]='9';
				}
				else 
				{
					b[i]='0';
				}
			}
			else if(maa==0)
			{
				if(a[i]>b[i])
				{
					maa=1;
				}
				else if(a[i]<b[i])
				{
					maa=-1;
				}
			}
		}
		cout<<"Case #"<<j<<":"<<" "<<a<<" "<<b<<endl;
	}
}