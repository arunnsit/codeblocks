#include<iostream>
#include<algorithm>
#include<stdio.h>
using namespace std;
int mark[2000000]={0};
int main()
{
	int x,y,m;
	long long int n;
	scanf("%I64d %d",&n,&m);
	for(int i=0;i<m;i++)
	{
		scanf("%d %d",&x,&y);
		mark[x]++;
		mark[y]++;
	}
	long long int p=0;
	for(int i=1;i<=n;i++)
	{
		p+=mark[i]*(n-1-mark[i])*1LL;
	}
	printf("%I64d\n",(n*(n-1)*(n-2)*1LL)/(6*1LL)-p/2);
}