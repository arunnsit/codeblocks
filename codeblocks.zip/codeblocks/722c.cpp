#include<iostream>
#include<algorithm>
#include<set>
#include<math.h>
#include<vector>
#include<string>
#include<string.h>
#define N 100006
using namespace std;
struct node
{
	long long int msum,psum,ssum;
	int pre,suf;
};
node tree[N*5];
void mergenode(int cur,int sz1,int sz2)
{
	node a=tree[2*cur+1],b=tree[2*cur+2];
	node c;
	//cout<<"a:"<<a.pre<<endl;
	//cout<<"b:"<<a.suf<<endl;
	c.msum=0,c.psum=0,c.ssum=0;
	if(a.pre==sz1)
	{
		c.psum=a.psum+b.psum;
		c.pre=a.pre+b.pre;
	}
	else
	{
		c.psum=a.psum;
		c.pre=a.pre;
	}
	if(b.suf==sz2)
	{
		c.ssum=b.ssum+a.ssum;
		c.suf=a.suf+b.suf;
	}
	else
	{
		c.ssum=b.ssum;
		c.suf=b.suf;
	}
	c.msum=max(max(a.msum,b.msum),max(max(c.ssum,c.psum),a.ssum+b.psum));
	//cout<<c.msum<<".."<<" "<<c.suf<<" "<<c.pre<<" "<<c.ssum<<" "<<c.psum<<" "<<cur<<" "<<sz1<<" "<<sz2<<endl;
	tree[cur]=c;
}

int a[N];
void make_tree(int cur,int l,int r)
{
	if(l==r)
	{
		tree[cur].msum=a[l];
		tree[cur].psum=a[l];
		tree[cur].ssum=a[l];
		tree[cur].pre=1;
		tree[cur].suf=1;
		return ;
	}
	int mid=l+(r-l)/2;
	make_tree(2*cur+1,l,mid);
	make_tree(2*cur+2,mid+1,r);
	mergenode(cur,mid-l+1,r-mid);
}
void update(int cur,int l,int r,int v)
{
	if(l==r)
	{
		tree[cur].msum=0;
		tree[cur].psum=0;
		tree[cur].ssum=0;
		tree[cur].pre=0;
		tree[cur].suf=0;
		return ;
	}
	int mid=l+(r-l)/2;
	if(v<=mid)
		update(2*cur+1,l,mid,v);
	else update(2*cur+2,mid+1,r,v);
	mergenode(cur,mid-l+1,r-mid);å
}
int main()
{
	int n,x;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	make_tree(0,0,n-1);
	//printf("%lld\n",tree[0].msum);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&x);
		update(0,0,n-1,x-1);
		printf("%I64d\n",tree[0].msum);
	}
}