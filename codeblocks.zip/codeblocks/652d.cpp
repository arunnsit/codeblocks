#include<iostream>
#include<vector>
#include<unordered_map>
#include<algorithm>
#include<stdio.h>
using namespace std;
#define N 400009
struct node
{
	int x,y,y_dash;
	int num;
};
bool cmp(node a,node b)
{
	return a.x > b.x;
}
int bit[N]={0};

void update(int pos,int add,int n)
{
	int ind=pos+1;
	while(ind<=n)
	{
		bit[ind]+=add;
			ind=ind+(ind&(-ind));
	}
}
int query(int pos)
{
	int ind=pos+1;
	int sum=0;
	while(ind!=0)
	{
		sum+=bit[ind];
		ind=ind-(ind&(-ind));
	}
	return sum;
}
struct node2
{
	int x,nos,l;
};
bool cmp2(node2 a ,node2 b)
{
	return a.x<b.x;
}
vector<node> v;
vector<node2>v_dash;
int quer[200006];
int main()
{
	int n;
	scanf("%d",&n);
	node b;
	node2 c;
	for(int i=0;i<n;i++)
	{
		scanf("%d %d",&b.x,&b.y);
		b.num=i;
		v.push_back(b);
	}
	sort(v.begin(),v.end(),cmp);
	for(int i=0;i<n;i++)
	{
		c.x=v[i].x;
		c.nos=i;
		c.l=1;
		v_dash.push_back(c);
		c.x=v[i].y;
		c.nos=i;
		c.l=0;
		v_dash.push_back(c);
	}
	sort(v_dash.begin(),v_dash.end(),cmp2);
	for(int i=0;i<v_dash.size();i++)
	{
		if(v_dash[i].l==1)
		{
			v[v_dash[i].nos].x=i;
		}
		else
		{
			v[v_dash[i].nos].y=i;
		}
	}
	for(int i=0;i<v.size();i++)
	{
		quer[v[i].num]=query(v[i].y);
		//cout<<query(v[i].y)<<endl;
		update(v[i].y,1,2*n);
	}
	for(int i=0;i<n;i++)
	{
		printf("%d\n",quer[i]);
	}
}