#include<iostream>
#include<math.h>
#include<vector>
#include<algorithm>
#define N 2000009
using namespace std;
//***************************
vector<int>prime;
int in_prime[N+4]={0};
void fill_prime()
{
	in_prime[1]=1;
	in_prime[0]=1;
	int x=sqrt(N)+2;
	for(int i=2;i<=x;i++)
		if(!in_prime[i])
		{
			for(int j=i*i;j<=N;j+=i)
		{
			in_prime[j]=1;
		}
	    }
}
//***************************
int main()
{
	fill_prime();
	int a,b,k,x,y;
	cin>>a>>b>>k;
	int curr=in_prime[a]^1;
	x=a-1,y=a;
	int sol=-1,l=0;
	//cout<<(in_prime[2]^1)<<" "<<(in_prime[3]^1)<<" "<<(in_prime[4]^1)<<endl;
	while(y!=b+1)
	{n
		if(curr>=k)
		{
			x++;
			curr-=in_prime[x]^1;
		}
		else
		{
			y++;
			curr+=in_prime[y]^1;
		}
					sol=max(sol,y-x);

		//cout<<x<<" "<<y<<" "<<curr<<endl;
	}
	if(y==b+1&&x==a-1)
		cout<<-1<<endl;
	else cout<<sol<<endl;
	



}