#include<iostream>
#include<vector>
#include<algorithm>
#define N 4000
using namespace std;
vector<int>adj[N],w[N];
int total=0,ulti=0;
void dfs(int u,int p,int l)
{
	ulti=max(l,ulti);
	for(int i=0;i<adj[u].size();i++)
	if(p!=adj[u][i])
	{
		dfs(adj[u][i],u,max(0,l+2*w[u][i]-1));
		total+=w[u][i];
	}
}

int main()
{
	int n;
	cin>>n;
	int x,y;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		w[x].push_back(0);
		w[y].push_back(1);
	}
	int sol=4000;
	for(int i=1;i<=n;i++)
	{
		total=0;
		ulti=0;
		dfs(i,-1,0);
		sol=min(sol,total-ulti);
	}
	cout<<sol<<endl;

}