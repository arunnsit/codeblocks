#include<iostream>
#include<algorithm>
#include<set>
#include<stdio.h>
#include<vector>
#include<math.h>
using namespace std;
int in[1000000],sol[1000000];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>in[i];
	for(int i=1;i<=n;i++)
		sol[i]=1000000;

	sol[1]=0;
	for(int j=0;j<10;j++)
	{
	sol[in[1]]=min(1,sol[in[1]]);
	for(int i=2;i<=n;i++)
	{
		sol[i]=min(sol[i],sol[i-1]+1);
		sol[in[i]]=min(sol[i]+1,sol[in[i]]);
	}
	for(int i=n-1;i>=1;i--)
	{
		sol[i]=min(sol[i],sol[i+1]+1);
	}}
	for(int i=1;i<=n;i++)
		cout<<sol[i]<<" ";
}