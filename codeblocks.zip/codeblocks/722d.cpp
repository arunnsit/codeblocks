#include<iostream>
#include<algorithm>
#include<set>
#include<math.h>
#include<vector>
#include<string>
#include<string.h>
#include<map>
using namespace std;
map<long long int,long long int >m;
set<pair<long long int ,pair<long long int ,long long int> > >s;
long long int arr[500002],in[500002],x,points[500002];
vector<int>v[500002];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>in[i];
		x=in[i];
		while(x!=1)
		{
			if(x&1)
			{
				v[i].push_back(1);
				x/=2;
			}
			else
			{
				v[i].push_back(0);
				x/=2;
			}
		}
		reverse(v[i].begin(),v[i].end());
		arr[i]=1;
		points[i]=0;
		m[1]++;
	}
	s.insert(make_pair(n,1,))
}