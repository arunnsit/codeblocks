#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include<string>
#define N 100008
#include<string.h>
using namespace std;
string a,b;
int main()
{
	cin>>a;
	b=a;
	while(!b.empty())
	{
		a.push_back(b.back());
		b.pop_back();
	}
	cout<<a<<endl;
}