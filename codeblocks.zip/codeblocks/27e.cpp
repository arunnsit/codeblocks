#include<iostream>
#include<algorithm>
#include<math.h>
#define MAX 1000000000000000009
using namespace std;
int primes[]={2,3,5,7,11,13,17,19,23,29,31,37,41};
long long int dp[5000][20]={0};
double pow(int a,int b)
{
	double c=1; 
	for(int i=1;i<=b;i++)
		c*=a;
	return c;
}
long long int solve(long long int div,int pri)
{
	//cout<<div<<" "<<pri<<endl;
	if(div==1)
		return 1;
	if(pri==13)
		return MAX;
	if(dp[div][pri])
		return dp[div][pri];
	
	long long int sol=MAX,ch=0,cur;
	
	for(int j=0;j<=62;j++)
		if(div%(j+1)==0&&(double)j<=log(MAX)/log(primes[pri])){
			cur=solve(div/(j+1),pri+1);
            if(pow(primes[pri],j)<=MAX/(double)cur&&cur<=MAX)
            {
            	sol=min(sol,cur*(long long int)pow(primes[pri],j));
            }
		}
	return  dp[div][pri]=sol;
}
int main()
{
	int n;
	cin>>n; 
	cout<<solve(n,0)<<endl;
}