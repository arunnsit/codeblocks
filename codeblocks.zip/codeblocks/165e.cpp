#include<iostream>
#include<algorithm>
#include<string.h>
#include<stdio.h>
#define N 1<<22
using namespace std;
int dp[N]={0},a[N];
int main()
{
	int n,x,y,mem=(1<<22)-1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		dp[a[i]]=a[i];
	}
	for(int i=0;i<22;i++)
	{
		for(int mask=0;mask<(1<<22);mask++)
		{
			if(!dp[mask]&&(mask & (1<<i)))
			{
				dp[mask]=dp[mask^(1<<i)];
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		y=dp[a[i]^mem];
		if(!y)
		printf("-1 ");
		else printf("%d ",y);
	}
	printf("\n");
}