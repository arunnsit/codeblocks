#include<iostream>
#include<algorithm>
using namespace std;
long long int arr[100009]={0},marks1[3500000],marks2[3500000];
int main()
{
	long long int dist=0,n,a,mr=0,x;
	cin>>n>>a;
	for(int i=1;i<=n;i++)
	{
		cin>>arr[i];
	}
	if(n==1)
		{
			cout<<0<<endl;
			return 0;
		}
	sort(arr+1,arr+n+1);
	long long int total=arr[n]-arr[1];
	if(arr[1]>=a)
	{
		cout<<arr[n-1]-a<<endl;
	}
	else if(arr[n]<=a)
	{
		cout<<a-arr[2]<<endl;
	}
	else
	{
		long long int d1=0,d2=0,d3=0,d4=0;
		int x=0;
		for(int i=1;i<=n;i++)
		{
			if(arr[i]<=a&&arr[i+1]>a)
			{
				x=i;
				break;
			}
		}
		d1=arr[x+1]-a;
		for(int i=x+2;i<=n;i++)
		{
			d1+=arr[i]-arr[i-1];
		}
		if(x!=1)
		{
			d1*=2;
			d1+=a-arr[x];
			for(int i=x-1;i>=2;i--)
			{
				d1+=arr[i+1]-arr[i];
			}
		}
		d2=arr[x+1]-a;
		for(int i=x+2;i<=n-1;i++)
		{
			d2+=arr[i]-arr[i-1];
		}
		
		{
			d2*=2;
			d2+=a-arr[x];
			for(int i=x-1;i>=1;i--)
			{
				d2+=arr[i+1]-arr[i];
			}
		}
		d3=a-arr[x];
		for(int i=x-1;i>=1;i--)
		{
			d3+=arr[i+1]-arr[i];
		}
		if(x!=n-1)
		{
			d3*=2;
			d3+=arr[x+1]-a;
			for(int i=x+2;i<=n-1;i++)
			{
				d3+=arr[i]-arr[i-1];
			}
		}
		d4=a-arr[x];
		for(int i=x-1;i>=2;i--)
		{
			d4+=arr[i+1]-arr[i];
		}
		{
			d4*=2;
			d4+=arr[x+1]-a;
			for(int i=x+2;i<=n;i++)
			{
				d3+=arr[i]-arr[i-1];
			}
		}
		cout<<min(min(d1,d2),min(d3,d4))<<endl;
	}
}