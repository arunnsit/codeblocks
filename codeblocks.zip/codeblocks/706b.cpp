#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<string.h>
using namespace std;
vector<int>v;
int main()
{
	int n;
	cin>>n;
	int x;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		v.push_back(x);
	}
	sort(v.begin(),v.end());
	int q;
	cin>>q;
	while(q--)
	{
		cin>>x;
		cout<<upper_bound(v.begin(),v.end(),x)-v.begin()<<endl;
	}
}