#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
char a[300000];
int main()
{
	cin.getline(a,300000);
	int ad=0,mi=0,op=0,n=0,i=0,mfill=0;
	for( i=0;a[i]!='\0';i++)
	{
		if(a[i]=='?')
		{
			op++;
		}
		if(a[i]=='+')
		{
			ad++;
		}
		if(a[i]=='-')
		{
			mi++;
		}
		if(a[i-1]=='=')
		{
			break;
		}
	}
	i++;
   // cout<<"i:"<<i<<" "<<a[i-2]<<endl;
	for(;a[i]!='\0';i++)
	{
		if(a[i]>='0'&&a[i]<='9')
		n=n*10+a[i]-'0';
	}
	mfill=n+mi;
	cout<<mfill<<" "<<n<<" "<<ad<<" "<<mi<<endl;
	if(mfill<=0||(mfill+ad)/(ad+1)>n||ad+1-mi>n)
		cout<<"Impossible\n";
	else
	{
		int fills=(mfill+ad)/(ad+1);
		cout<<"Possible\n";
		cout<<fills;
		int koko=mfill,prev=0,topr=ad;
		koko-=fills;
		for(i=1;a[i]!='\0';i++)
		{
			if(a[i]=='-')
			{
				prev=-1;
			}
			 if(a[i]=='+')
			{
				prev=1;
			}

			if(prev==1&&a[i]=='?')
			{
				if(topr*(fills-1)!=koko)
				{
					cout<<fills;
					koko-=fills;
				}
				else {
					cout<<fills-1;
					koko-=fills-1;
				}
				topr--;
			}
			else if(prev==-1&&a[i]=='?')
			{
				cout<<1;
			}
			else cout<<a[i];
		}
	}

}