#include<iostream>
#include<algorithm>
#include<vector>
#include<stdio.h>
#include<string.h>
#define N 200009
using namespace std;
long long int dp[N][2],presum[N];
int n;
long long int solve(int x,int y)
{
	if(x==n)
	{
		if(y==0)
			return presum[x];
		else return -presum[x];
	}
	if(dp[x][y]!=-1)
		return dp[x][y];
	if(y==0)
	{
		return dp[x][y]=max(solve(x+1,y^1)+presum[x],solve(x+1,y));
	}
	else return dp[x][y]=min(solve(x+1,y^1)-presum[x],solve(x+1,y));
}
int main()
{
	cin>>n;
	memset(dp,-1,sizeof(dp));
	for(int i=1;i<=n;i++)
	{
		cin>>presum[i];
		presum[i]+=presum[i-1];
	}
	cout<<solve(2,0)<<endl;
}