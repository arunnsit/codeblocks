#include<iostream>
#include<algorithm>
#include<vector>
#define N 1000009
using namespace std;
int Paren[N],siz[N];
void createset(int x)
{
	if(Paren[x])
		return ;
	Paren[x]=x;
	siz[x]=1;
}
int find_parent(int x)
{
	if(x==Paren[x])
		return x;
	Paren[x]=find_parent(Paren[x]);
	return Paren[x];
}
void merge(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(v==u)
		return ;
	if(u>v)
	{
		Paren[u]=v;
		siz[v]+=siz[u];
		siz[u]=1;
	}
	else
	{
		Paren[v]=u;
		siz[u]+=siz[v];
		siz[v]=1;
	}
}
int a[200009],hs[200009];
int main()
{
	int n,root=-1;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		createset(i);
		cin>>a[i];
		hs[i]=a[i];
		if(i==a[i])root=i;
	}
	int cs=0;
	for(int i=1;i<=n;i++)
	{
		if(find_parent(i)!=find_parent(a[i]))
		{
			merge(i,a[i]);
		}
		else
		{
			if(root!=-1)
			{
				merge(i,root);
				a[i]=root;
			}
			else
			{
				a[i]=i;
				root=i; 
			}
		}
		if(hs[i]!=a[i])cs++;
	}
	cout<<cs<<endl;
	for(int i=1;i<=n;i++)
		cout<<a[i]<<" ";
}