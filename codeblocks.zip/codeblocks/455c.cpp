#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<vector>
#define N 400000
using namespace std;
vector<int>adj[N],mark[N];
int vis[N]={0};
int n,m,q,x,y;
int longest[N][2]={0};
int diameter[N]={0},P[N],ranka[N];
int nextInt() {
    int x = 0, p = 1;
    char c;
    do {
        c = getchar();
    } while (c <= 32);
    if (c == '-') {
        p = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * p;
}

int find_parent(int x)
{   
	if (x != P[x]) P[x] = find_parent(P[x]);
    return P[x];
}
void create_set(int x)
{
	P[x] = x;
    ranka[x] = 1;
}
int merge(int x,int y)
{
	 x = find_parent(x);
     y = find_parent(y);
      if(x==y)return -1;
 if(x==y)return -1;
 
 if (ranka[x] > ranka[y]) P[y] = x;
 else P[x] = y;
 if (ranka[x] == ranka[y]) ranka[y] = ranka[x] + 1;
 
 return 1;    
}
int maxd=0,maxv=0;
int dfs(int start,int depth,int parent)
{
	if(maxd<=depth)
	{
		maxd=depth;
		maxv=start;
	}
	int m=0,ssm=0,x;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=parent){
		x=dfs(adj[start][i],depth+1,start);
	}
	return m+1;
}
int main()
{
	n=nextInt();
	m=nextInt();
	q=nextInt();
	for(int i=0;i<=n;i++)
		vis[i]=0;
	for(int i=0;i<m;i++)
	{
		x=nextInt();
		y=nextInt();
		if(x==y)
				continue;
		adj[x].push_back(y);
		adj[y].push_back(x);
		    if(P[x]==0)
				create_set(x);
			if(P[y]==0)
				create_set(y);
			if(find_parent(y)!=find_parent(x))
			merge(x,y);
	}
	for(int i=1;i<=n;i++)
	{
		x=find_parent(i);
		if(!vis[x])
		{
			vis[x]=1;
			maxd=0;
			dfs(i,0,-1);
			maxd=0;
			dfs(maxv,0,-1);
		    diameter[x]=maxd;
		    //cout<<"io:"<<x<<" "<<diameter[x]<<endl;
		    //cout<<i<<" "<<longest[i][0]<<" "<<longest[i][1]<<endl;
		}
	}
	int type;
	while(q--)
	{
		type=nextInt();
		x=nextInt();
		if(type==2)
		{
			y=nextInt();
			if(x==y)
				continue;
			if(P[x]==0)
				create_set(x);
			if(P[y]==0)
				create_set(y);
			if(find_parent(x)!=find_parent(y))
			{   
				int a,b;
				a=diameter[find_parent(x)];
				b=diameter[find_parent(y)];
				if(find_parent(y)!=find_parent(x))
			    merge(x,y);
				diameter[find_parent(x)]=max(max((a+1)/2+(b+1)/2+1,a),b);
			    //cout<<longest[x][0]<<" "<<longest[x][1]<<endl;
			    //cout<<longest[y][0]<<" "<<longest[y][1]<<endl;
			}
		}
		else cout<<diameter[find_parent(x)]<<endl;
	}

}