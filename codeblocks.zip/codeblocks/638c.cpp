#include<iostream>
#include<vector>
#include<algorithm>
#define N 200009
using namespace std;
vector<int>adj[N],num[N],solution[N];
int degree[N];
void dfs(int u,int p,int upcolor)
{
	vector<int>v;
	int timer=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		timer++;
		if(timer==upcolor)
		{
			timer++;
		}
		v.push_back(timer);
	}
	else{
		v.push_back(0);
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		//cout<<".."<<v[i]<<endl;
		solution[v[i]].push_back(num[u][i]);
		dfs(adj[u][i],u,v[i]);
	}
}
int main()
{
	int n,x,y,madeg=0;
	cin>>n;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		num[x].push_back(i+1);
		num[y].push_back(i+1);
		degree[x]++;
		degree[y]++;
		madeg=max(max(degree[x],degree[y]),madeg);
	}
	cout<<madeg<<endl;
	dfs(1,1,0);
	for(int i=1;i<=madeg;i++)
	{
		cout<<solution[i].size()<<" ";
		for(int j=0;j<solution[i].size();j++)
		{
			cout<<solution[i][j]<<" ";
		}
		cout<<endl;
	}
}