#include<iostream>
using namespace std;
int main()
{
	long long int coun=0,x=0,dump=0,b=0,n,d;
	cin>>n>>b>>d;
	while(n--)
	{
		cin>>x;
		if(x<=b)
		{
			dump+=x;
			if(dump>d)
			{
				coun++;
				dump=0;
			}
		}
	}
	cout<<coun<<endl;
}