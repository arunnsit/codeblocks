#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<set>
#define blocks 320
using namespace std;
set<int>pow2;
set<int>current_set;
int arr[50009];
#define N 320;
struct query
{
	int l,r,nos,block;
};
int f[1000009]={0};
query q[100009];
int trie[1<<21];
void addintrie(int curr,int h,int v)
{
	trie[curr]++;
	cout<<curr<<":"<<trie[curr]<<endl;
	if(!h)
		return ;
	addintrie(2*curr+1+((v>>(h-1))&1),h-1,v);
}
void delintrie(int curr,int h,int v)
{
	trie[curr]--;
	cout<<curr<<":"<<trie[curr]<<endl;
	if(!h)
		return ;
	delintrie(2*curr+1+((v>>(h-1))&1),h-1,v);
}
int maxquerytrie(int curr,int h,int v)
{

	if(!trie[curr])
	{
		return -1;
	}
	if(!h)
		return 0;
	int curbit=(v>>(h-1))&1,maxv;
	cout<<h<<" "<<curbit<<endl;
	maxv=maxquerytrie(2*curr+1+(curbit^1),h-1,v);
	cout<<maxv<<endl;
	if(maxv==-1)
	{
		return maxquerytrie(2*curr+1+curbit,h-1,v);
	}
	else
	{
		return maxv+(1<<(h-1));
	}
}

bool cmp(query a,query b)
{
	if(a.block==b.block)
		return a.r<b.r;
	else return a.block<b.block;
}
void add(int x)
{

}
void del(int x)
{

}
int solution[100009];
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=1000000;i++)
	{
		f[i]^=f[i-1];
	}
	for(int i=0;i<n;i++)
		cin>>arr[i];
	for(int i=0;i<m;i++)
		{
			cin>>q[i].l>>q[i].r;
			q[i].nos=i+1;
			q[i].block=q[i].l/blocks;
		}
	sort(q,q+m,cmp);
	int curr_l=0,curr_r=0;
	for(int i=0;i<m;i++)
	{
		while(q[i].l<curr_l)
		{   
			curr_l--;
			add(curr_l);
		}
		while(q[i].l>curr_l)
		{
			del(curr_l);
			curr_l++;
		}
		while(q[i].r<curr_r)
		{
			del(curr_r);
			curr_r--;

		}
		while(q[i].r>curr_r)
		{   
			curr_r++;
			add(curr_r);
		}
	}	
}