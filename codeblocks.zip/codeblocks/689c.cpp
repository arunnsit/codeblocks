#include<iostream>
#include<algorithm>
#include<set>
#include<stdio.h>
#include<vector>
#include<math.h>
using namespace std;
int main()
{
	long long int m,l,r,mid,ways,solution=-1;
	scanf("%lld",&m);
	l=1;
	r=10000000000000000LL;
	while(1)
	{
		mid=l+(r-l)/2;
		
		ways=0;
		for(long long int i=2;(mid/(1LL*i*i*i))>0;i++)
		{
			ways+=(mid/(i*i*i));
		}
		if(ways>m)
		{
			r=mid-1;
		}
		if(ways<m)
		{
			l=mid+1;
		}
		if(ways==m)
		{
			solution=mid;
			r=mid-1;
		}
		if(l>r||mid==0)
		{
			break;
		}
	}
	printf("%lld\n",solution);
}