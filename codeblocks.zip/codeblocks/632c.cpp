#include<iostream>
#include<string>
#include<string.h>
#include<set>
#include<algorithm>
#include<vector>
using namespace std;
vector<string>v;
bool cmp(string a,string b)
{
	string c,d;
	c+=a;
	d+=b;
	c+=b;
	d+=a;
	return c<d;
}
int main()
{
	int n;
	cin>>n;
	string a;
	string b="";
	while(n--)
	{
		cin>>a;
		v.push_back(a);
	}
	sort(v.begin(),v.end(),cmp);
	for(int i=0;i<v.size();i++)
	{
		b+=v[i];
	}
	cout<<b<<endl;
}