#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<string>
#include<math.h>
#include<string.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	string a="I hate that ",b="I love that ",c="I hate ",d="I love ",e="it",sol="";
	if(n==1)
	{
		sol+=c;
		sol+=e;
	}
	else
	{
		for(int i=0;i<n-1;i++)
		{
			if(i%2==0)
			{
				sol+=a;
			}
			else sol+=b;
		}
		if((n-1)%2==0)
		{
			sol+=c;
		}
		else sol+=d;
		sol+=e;
	}
	cout<<sol<<endl;
}