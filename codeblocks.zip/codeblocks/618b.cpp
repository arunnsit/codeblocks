#include<iostream>
#include<algorithm>
using namespace std;
int arr[100][100],mains[100]={0},fsol[100]={0};
int main()
{
	int n,i,j,k,l;
	cin>>n;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			cin>>arr[i][j];
	for(i=0;i<n;i++)
		{
			int marks[100]={0};
			for(j=0;j<n;j++)
				marks[arr[i][j]]++;
			for(j=1;j<=n;j++)
			if(marks[j]==n-j&&!mains[j]){
				mains[j]++;
				fsol[i]=j;
				break;
			}
			else if(marks[j]==n-j)
			{
				mains[j+1]++;
				fsol[i]=j+1;
				break;
			}
	    }
	 for(i=0;i<n;i++)
	 cout<<fsol[i]<<" ";   

	
}