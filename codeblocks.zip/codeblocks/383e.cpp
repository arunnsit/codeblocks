#include<iostream>
#include<algorithm>
#include<vector>
#include<stdio.h>
#define N 1<<24
using namespace std;
int dp[N];
int main()
{
	int n;
	scanf("%d",&n);
	char a[8];
	long long int sol=0,cur,meta=(1<<24)-1;
	while(n--)
	{
		scanf("%s",a);
		int mask=0;
		for(int i=0;a[i]!='\0';i++)
		{
			mask|=1<<((a[i]-'a'));
		}
		dp[mask]++;
	}
	for(int i=0;i<24;i++)
	{
		for(int mask=0;mask<(1<<24);mask++)
		{
			if((mask & (1<<i)))
			{
				dp[mask]+=dp[mask^(1<<i)];
			}
		}
	}
	int newmask=0;
	//cout<<dp[meta]<<".."<<endl;
	for(int mask=0;mask<(1<<24);mask++)
	{
		newmask=mask^meta;
		cur=dp[meta]-dp[newmask];
		//cout<<cur<<" "<<endl;
		sol^=cur*cur;
	}
	printf("%I64d\n",sol);
}