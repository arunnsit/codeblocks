#include<iostream>
using namespace std;
int main()
{
	int n,k;
	cin>>n>>k;
	long long int s=0;
	while(k--&&n>1)
	{
		s+=2*(n-1)-1;
		n-=2;
	}
	cout<<s<<endl;
}