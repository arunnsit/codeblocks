#include<iostream>
#include<queue>
#include<stdio.h>
#include<vector>
using namespace std;
char a[1006][1006];
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int vis[1006][1006]={0},vis2[1006][1006]={0};
void bfs(int x,int y,int n,int m,int mos)
{
	//cout<<x<<" "<<y<<endl;
	queue<pair<int,int> >q;
	q.push(make_pair(x,y));
	int dx,dy,coun=0;
	vis[x][y]=1;
	vis2[x][y]=mos;
	vector<pair<int,int> >v;
	while(!q.empty())
	{
		v.push_back(q.front());
		coun++;
		x=q.front().first;
		y=q.front().second;
		q.pop();
		for(int i=0;i<4;i++)
		{
			dx=x+dir[i][0];
			dy=y+dir[i][1];
			if(dx>=0&&dx<n&&dy>=0&&dy<m&&a[dx][dy]=='.')
			{   if(vis[dx][dy]==0)
				{
					vis[dx][dy]=1;
					vis2[dx][dy]=mos;
					q.push(make_pair(dx,dy));
				}
			}
		}
	}

	for(int i=0;i<v.size();i++)
		vis[v[i].first][v[i].second]=coun;
}
int main()
{
	int n,m,dx,dy,mos=0;
	scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++)
		scanf("%s",a[i]);
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			if(vis[i][j]==0&&a[i][j]=='.')
				bfs(i,j,n,m,++mos);			
	int ch=0;
	vector<pair<int,int> >v;
	for(int k=0;k<n;k++)
		{
			for(int j=0;j<m;j++)
		{
			ch=0;
			if(a[k][j]=='*')
			{
				v.clear();
				for(int i=0;i<4;i++)
		{
			dx=k+dir[i][0];
			dy=j+dir[i][1];
			if(dx>=0&&dx<n&&dy>=0&&dy<m&&a[dx][dy]=='.')
			{   
				v.push_back(make_pair(dx,dy));
			}
		}
		for(int t=0;t<v.size();t++)
			{int uyu=0;
				for(int u=t+1;u<v.size();u++)
			{
				if(vis2[v[u].first][v[u].second]==vis2[v[t].first][v[t].second])
				{
					uyu=1;
				}
			}
			if(!uyu)ch+=vis[v[t].first][v[t].second];
		}

		printf("%d",(ch+1)%10);}
		else printf(".");}
		printf("\n");
	}		
}