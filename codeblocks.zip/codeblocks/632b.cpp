#include<iostream>
#include<string>
#include<string.h>
#include<set>
#include<vector>
using namespace std;
string a;
long long int pre[600000][2],suf[600000][2],in[6000000];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>in[i];
	}
	cin>>a;
	
	for(int i=0;i<a.length();i++)
	{
		if(a[i]=='A')
		{
			pre[i+1][0]=pre[i][0]+in[i+1];
			pre[i+1][1]=pre[i][1];
		}
		else
		{
			pre[i+1][1]=pre[i][1]+in[i+1];
			pre[i+1][0]=pre[i][0];
		}
	}
	for(int i=a.length()-1;i>=0;i--)
	{
		if(a[i]=='A')
		{
			suf[i+1][0]=suf[i+2][0]+in[i+1];
			suf[i+1][1]=suf[i+2][1];
		}
		else
		{
			suf[i+1][1]=suf[i+2][1]+in[i+1];
			suf[i+1][0]=suf[i+2][0];
		}
	}
	long long int sol=0;
	for(int i=1;i<=n;i++)
	{
		sol=max(sol,max(max(pre[i][0],pre[i][1])+suf[i+1][1],max(suf[i][0],suf[i][1])+pre[i-1][1]));
	}
	//cout<<sol<<endl;
	sol=max(sol,max(pre[n][1],suf[1][1]));
	cout<<sol<<endl;
}