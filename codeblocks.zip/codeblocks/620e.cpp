#include<iostream>
#include<algorithm>
#include<vector>
#include<stdio.h>
#define N 400009
using namespace std;
vector<long long int>adj[N];
long long int in[N],timer=-1,out[N],color[N],col[N];
void dfs(int u,int p)
{
	in[u]=++timer;
	color[in[u]]=col[u];
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		dfs(adj[u][i],u);
	}
	out[u]=timer;
    //cout<<u<<" "<<in[u]<<" "<<out[u]<<endl;	
}
long long int tree[8*N],lazy[8*N];
long long int merge_node(long long x,long long y)
{
	return x|y;
}
void flushdown(int x)
{
	if(lazy[x])
	{
		tree[x]=lazy[x];
		lazy[x]=0;
		lazy[2*x+1]=tree[x];
		lazy[2*x+2]=tree[x];
	}
}
void make_tree(long long int curr,long long int l,long long int r)
{
	if(l==r)
	{
		tree[curr]=(1LL<<color[l]);
		return ;
	}
	long long int mid=l+((r-l)>>1);
	make_tree(2*curr+1,l,mid);
	make_tree(2*curr+2,mid+1,r);
	tree[curr]=merge_node(tree[2*curr+1],tree[2*curr+2]);
	//cout<<".."<<tree[curr].coun[1]<<endl;
}

long long int nulli()
{
	long long int c=0;
	return c;
}
void update(long long int curr,long long int l,long long int r,long long int x,long long int y,long long int c)
{
	flushdown(curr);
	if(x<=l&&r<=y)
	{
		tree[curr]=c;
		lazy[2*curr+1]=c;
		lazy[2*curr+2]=c;
		return ;
	}
	if(r<x||y<l)
	{
		return ;
	}
	long long int mid=l+((r-l)>>1);
	update(2*curr+1,l,mid,x,y,c);
	update(2*curr+2,mid+1,r,x,y,c);
	tree[curr]=merge_node(tree[2*curr+1],tree[2*curr+2]);
}
long long int query(long long int curr,long long int l,long long int r,long long int x,long long int y)
{
	flushdown(curr);
	if(x<=l&&r<=y)
	{
		return tree[curr];
	}
	if(r<x||y<l)
	{
		return nulli();
	}
	long long int mid=l+((r-l)>>1);
	return merge_node(query(2*curr+1,l,mid,x,y),query(2*curr+2,mid+1,r,x,y));
}
int main()
{
	long long int n,x,y,q,type;
	long long int c;
	scanf("%lld %lld",&n,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&col[i]);
	}
	for(int i=0;i<n-1;i++)
	{
		scanf("%lld %lld",&x,&y);
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	dfs(1,0);
	make_tree(0,0,timer);
	while(q--)
	{
		scanf("%lld",&type);
		if(type==1)
		{
			scanf("%lld %lld",&x,&y);
			c=(1LL<<y);
			update(0,0,timer,in[x],out[x],c);
		}
		else
		{
			long long int temp;
			scanf("%lld",&x);
			temp=query(0,0,timer,in[x],out[x]);
			long long int coun=0;

			for(int i=1;i<=60;i++)
			{
				if((temp>>i)&1)
				{
					coun++;
				}
			}
			printf("%lld\n",coun);
		} 
	}
}