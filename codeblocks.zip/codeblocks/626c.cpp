#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<unordered_map>
using namespace std;
int arr[10000000]={0};
int main()
{
	int n,m;
	cin>>n>>m;
	long long int s3=0,s2=0,sol=0,x=0,collides;
	collides=min(n/3,m/2);
	s2=n*2;
	s3=3*m;
	while(collides--)
	{
		if(s2<=s3)
		{
			s2+=2;
		}
		else
		{
			s3+=3;
		}
	}
	cout<<max(s2,s3)<<endl;
	
}