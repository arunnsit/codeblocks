#include<iostream>
#include<queue>
#include<algorithm>

using namespace std;
char a[40][40]={0};
int vis[40][40]={0};
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	queue<pair<int,int> >q;
	q.push(make_pair(0,0));
	int dx,dy,x,y,sol=0,c=0;
	vis[0][0]=1;
	while(!q.empty())
	{
		x=q.front().first;
		y=q.front().second;
		c=0;
		q.pop();
		for(int i=0;i<4;i++)
		{
			dx=x+dir[i][0];
			dy=y+dir[i][1];
			if(dx>=0&&dx<n&&dy>=0&&dy<n&&a[dx][dy]=='.')
			{   if(vis[dx][dy]==0)
				{
					vis[dx][dy]=1;
					q.push(make_pair(dx,dy));
				}
			}
			else c++;
		}
		//cout<<x<<" "<<y<<" "<<c<<endl;
		sol+=c;
	}
	if(vis[n-1][n-1]==0)
	{
		vis[n-1][n-1]=1;
		c=0;
	    q.push(make_pair(n-1,n-1));
		while(!q.empty())
	{
		x=q.front().first;
		y=q.front().second;
		c=0;
		q.pop();
		for(int i=0;i<4;i++)
		{
			dx=x+dir[i][0];
			dy=y+dir[i][1];
			if(dx>=0&&dx<n&&dy>=0&&dy<n&&a[dx][dy]=='.')
			{   if(vis[dx][dy]==0)
				{
					vis[dx][dy]=1;
					q.push(make_pair(dx,dy));
				}
			}
			else c++;
		}
		//cout<<x<<" "<<y<<" "<<c<<endl;
		sol+=c;
	}
    }
	//cout<<sol<<endl;
	cout<<(sol-4)*9<<endl;
}