#include<iostream>
#include<set>
#include<map>
#include<vector>
#define N 500009
using namespace std;
vector<int>adj[N];
int P[N],level[N];
map<int,int>ma;
multiset<int>leaf;
void dfs(int u,int p)
{
	int c=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		level[adj[u][i]]=level[u]+1;
		P[adj[u][i]]=u;
		dfs(adj[u][i],u);
		c=1;
	}
	if(!c)
	{
		//cout<<"l:"<<u<<endl;
		leaf.insert(level[u]);
	}
}
int main()
{
	int n,x,y;
	P[1]=-1;
	scanf("%d",&n);
	for(int i=0;i<n-1;i++)
	{
		scanf("%d %d",&x,&y);
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	int mol=0;
	for(int i=0;i<adj[1].size();i++)
	{
		dfs(adj[1][i],1);
		int ma=0,prev=0;
		for(set<int>::iterator it=leaf.begin();it!=leaf.end();it++)
		{
			ma=*it;
			if(it!=leaf.begin())
			ma=max(prev+1,ma);
			//cout<<"eject:"<<ma<<endl;
			prev=ma;
		}
		mol=max(mol,ma);
		leaf.clear();
	}
	cout<<mol+1<<endl;
}