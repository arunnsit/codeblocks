#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<algorithm>
#include<string.h>
using namespace std;
vector<int>v;
int freq[1005]={0};
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		freq[x]++;
		if(freq[x]==1)
		v.push_back(x);
	}
	sort(v.begin(),v.end());
	if(v.size()<3)
	{
		cout<<"NO\n";
		return 0;
	}
	int x=v[0],y=v[1];
	int ch=0;
	for(int i=2;i<v.size();i++)
	{
		if(v[i]==y+1&&y==x+1)
		{
			ch=1;
		}
		x=y;
		y=v[i];
	}
	if(ch)
		cout<<"YES\n";
	else cout<<"NO\n";
}