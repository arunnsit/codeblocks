#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int main()
{
	int n,b,c,x,y;
	string a;
	cin>>n;
	cin>>a;
	long long int sol=0;
	for(int i=0;i<n;i++)
	{
		x=0;
		y=0;
		for(int j=i;j<n;j++)
		{
			if(a[j]=='L')
				x--;
            if(a[j]=='R')
				x++;
            if(a[j]=='D')
				y--;
            if(a[j]=='U')
				y++;
			if(x==0&&y==0)
				sol++;
		}
	}
	cout<<sol<<endl;


}