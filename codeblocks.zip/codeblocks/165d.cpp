#include<stdio.h>
#include<algorithm>
#include<vector>
#include<map>
#define N 100006
using namespace std;
int n,mark[N],t=0,ec=0,flated[N],edge_end[N],chainheads[N],chain_number[N],tree[6*N],numo=0;
vector<int> adj[N];
map<pair<int,int>,int>treed;
void dfs(int u,int p,int head,int num)
{
	for(int i=0;i<adj[u].size();i++)
	{
		if(adj[u][i]!=p)
		{
			edge_end[treed[make_pair(u,adj[u][i])]]=adj[u][i];
			flated[adj[u][i]]=t++;
			if(head==-1)
			{
				chainheads[adj[u][i]]=t-1;
				chain_number[adj[u][i]]=++numo;
				dfs(adj[u][i],u,t-1,numo);
			}
			else
			{
				chainheads[adj[u][i]]=head;
				chain_number[adj[u][i]]=num;
				dfs(adj[u][i],u,head,num);
			}
		}
	}
}

void update(int curr,int x,int y,int pos)
{
	if(x==y)
	{
		tree[curr]^=1;
		return ;
	}
	int mid=x+((y-x)>>1);
	if(pos<=mid)
		update(2*curr+1,x,mid,pos);
	else update(2*curr+2,mid+1,y,pos);
	tree[curr]=tree[2*curr+1]+tree[2*curr+2];
}
int query(int curr,int x,int y,int l,int r)
{
	if(r<x||y<l)
		return 0;
	if(l<=x&&y<=r)
		return tree[curr];
	int mid=x+((y-x)>>1);
	return query(2*curr+1,x,mid,l,r)+query(2*curr+2,mid+1,y,l,r);
}
int main()
{
	scanf("%d",&n);
	int x,y,type,b1,w1,b2,w2,l,p,o,x1,y1;	
	for(int i=0;i<n-1;i++)
	{
		scanf("%d %d",&x,&y);
		treed[make_pair(x,y)]=i+1;
		treed[make_pair(y,x)]=i+1;
		mark[x]++;
		mark[y]++;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	int m=0,center=1;
	for(int i=1;i<=n;i++)
	{
		if(mark[i]>m)
		{
			m=mark[i];
			center=i;
		}
	}
	//cout<<"center:"<<center;
	flated[center]=-1;
	dfs(center,-1,-1,-1);
	/*for(int i=1;i<=n;i++)
	{
		cout<<i<<" : "<<chainheads[i]<<" "<<flated[i]<<endl;
	}*/
	scanf("%d",&m);
	while(m--)
	{
		scanf("%d",&type);
		if(type!=3)
		{
			scanf("%d",&x);
			update(0,0,t-1,flated[edge_end[x]]);
		}
		else
		{
			scanf("%d %d",&x,&y);
			x1=x;
			y1=y;
			p=flated[x];
			o=flated[y];
			if(p==-1)
			{
				x=-1;
			}
			else if(o==-1)
			{
				swap(x,y);
				swap(x1,y1);
			}
			else if(o<p)
			{
				swap(x,y);
				swap(x1,y1);
			}
			x=flated[x1];
			y=flated[y1];
			if(x==-1)
			{
				if(flated[y1]==-1)
				{
					y1=x1;
				}
				l=y-chainheads[y1]+1;
				//cout<<"cas1";
				w1=query(0,0,t-1,chainheads[y1],y);
				if(w1==0)
					printf("%d\n",l);
				else printf("-1\n");
			}
			else if(chain_number[x1]==chain_number[y1])
			{
				l=y-x;
				//cout<<"cas2";
				w1=query(0,0,t-1,x,y)-query(0,0,t-1,x,x);
				if(w1==0)
					printf("%d\n",l);
				else printf("-1\n");
			}
		    else
		    {
		    	l=y-chainheads[y1]+x-chainheads[x1]+2;
		    	//cout<<"cas3 "<<x1<<" "<<y1<<endl;
		    	w1=query(0,0,t-1,chainheads[y1],y)+query(0,0,t-1,chainheads[x1],x);
		    	if(w1==0)
					printf("%d\n",l);
				else printf("-1\n");
		    }
		}
	}
}