#include<iostream>
#include<algorithm>
#include<vector>
#include<stdio.h>
#define N 200009
using namespace std;
long long int sol[N],vos[N];
long long int prefi[3*N];
vector<int>v;
int main()
{
	int n,x;
	long long int fsol=0;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&x);
		vos[x]++;
		prefi[x]++;
		v.push_back(x);
	}
	for(int i=1;i<=500000;i++)
	{
		prefi[i]+=prefi[i-1];
	}
	for(int i=1;i<=200000;i++)
	{
		for(int j=i;j<=200000;j+=i)
		{
			sol[i]+=(prefi[j+i-1]-prefi[j-1])*1LL*j;
		}
		if(vos[i])
			{
				fsol=max(fsol,sol[i]);
				//cout<<"i:"<<i<<" "<<sol[i]<<endl;
			}
	}
	printf("%I64d\n",fsol);
}