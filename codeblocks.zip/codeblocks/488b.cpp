#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,arr[4];
	cin>>n;
	if(n==0)
	{
		cout<<"YES\n1\n2\n2\n3\n";
	}
	if(n==1)
	{
		cin>>arr[0];
		arr[3]=3*arr[0];
		arr[1]=arr[0];
		arr[2]=arr[3];
		cout<<"YES\n"<<arr[1]<<endl<<arr[2]<<endl<<arr[3]<<endl;
	}
	if(n==2)
	{
			int x=0,y,z,w,arr[10];
		cin>>y>>z;
		for(int j=1;j<=5000;j++)
		{
			for(int i=1;i<=5000;i++)
		{
			arr[0]=j;
		    arr[1]=y;
		    arr[2]=z;
			arr[3]=i;
			sort(arr,arr+4);
			//if(i==3)
			//cout<<arr[0]+arr[1]+arr[2]+arr[3]<<" "<<2*(arr[1]+arr[2])<<" "<<arr[1]+arr[2]<<endl;
			if(arr[0]+arr[1]+arr[2]+arr[3]==2*(arr[1]+arr[2])&&2*(arr[3]-arr[0])==arr[1]+arr[2])
			{
				cout<<"YES\n"<<i<<endl<<j<<endl;
				x=1;
				break;
			}
		}if(x)break;}
		if(!x)cout<<"NO\n";
	}
	if(n==3)
	{
		int x=0,y,z,w,arr[10];
		cin>>w>>y>>z;
		
		for(int i=1;i<=1000000;i++)
		{
			arr[0]=w;
		    arr[1]=y;
		    arr[2]=z;
			arr[3]=i;
			sort(arr,arr+4);
			//if(i==3)
			//cout<<arr[0]+arr[1]+arr[2]+arr[3]<<" "<<2*(arr[1]+arr[2])<<" "<<arr[1]+arr[2]<<endl;
			if(arr[0]+arr[1]+arr[2]+arr[3]==2*(arr[1]+arr[2])&&2*(arr[3]-arr[0])==arr[1]+arr[2])
			{
				cout<<"YES\n"<<i<<endl;
				x=1;
				break;
			}
		}
		if(!x)cout<<"NO\n";	

	}
	if(n==4)
	{
		cin>>arr[0]>>arr[1]>>arr[2]>>arr[3];
	    sort(arr,arr+4);
		if(arr[0]+arr[1]+arr[2]+arr[3]==2*(arr[1]+arr[2])&&2*(arr[3]-arr[0])==arr[1]+arr[2])
			cout<<"YES\n";
		else cout<<"NO\n";
	}
}