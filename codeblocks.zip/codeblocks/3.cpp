#include<iostream>
#include<algorithm>
#include<math.h>
#include<map>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#include<unordered_map>
#include<stdio.h>
#define N 500002
using namespace std;
vector<int>a,b,c;
int arr[N];
int main()
{
	int n,m,x;
	scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&x);
		a.push_back(x);
	}
	for(int i=0;i<m;i++)
	{
		scanf("%d",&x);
		arr[x]++;
	}
	for(int i=0;i<n;i++)
		b.push_back(arr[i]);
	c=a;
	for(int i=0;i<n;i++)
	{
		c.push_back(a[i]);
	}
	for(int i=0;i<c.size();i++)
	{
		cout<<c[i]<<" ";
	}
	cout<<endl;
	for(int i=0;i<b.size();i++)
	{
		cout<<b[i]<<" ";
	}
	cout<<endl;
}
