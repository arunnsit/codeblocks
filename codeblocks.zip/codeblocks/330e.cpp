#include<iostream>
#include<algorithm>
#include<math.h>
#include<vector>
#define N 100009
using namespace std;
vector<int>adj[N],edge;
//**************
int mark[N]={0};
#include<queue>
queue<int>q;
void bfs(int u)
{
	mark[u]=1;
	edge.push_back(u);
	for(int i=0;i<adj[u].size();i++)
	if(!mark[adj[u][i]]){
		q.push(adj[u][i]);
	}
	while(!q.empty())
	{
		int x=q.front();
		q.pop();
		if(!mark[x])
		bfs(x);
	}
}
//*************
int main()
{
	int n,m,x,y;
	cin>>n>>m;

	if(n>=7)
	{
		for(int i=0;i<m;i++)
		{
			cin>>x>>y;
			adj[x].push_back(y);
			adj[y].push_back(x);
		}
		for(int i=1;i<=n;i++)
		if(!mark[i])	
		bfs(i);
	    if(m>n)
	    	cout<<-1<<endl;
	    else
		for(int i=0;i<m;i++)
		{
			cout<<edge[i]<<" "<<edge[(i+3)%n]<<endl;
		}
	}
	else
	{
		std::vector<pair<int,int> > fd,fsol;
		int eds[10][10]={0},edcoun=0,solexist=0;
		for(int i=0;i<m;i++)
		{
			cin>>x>>y;
			eds[x][y]=1;
			eds[y][x]=1;
		}
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++)
				if(!eds[i][j])
				fd.push_back(make_pair(i,j));
		for(int i=0;i<(1<<fd.size());i++)
		{
			int degree[10]={0};
			edcoun=0;
			fsol.clear();
			for(int j=0;j<fd.size();j++)
			{
				if((i>>j)&1)
				{
					edcoun++;
					fsol.push_back(fd[j]);
					degree[fd[j].first]++;
					degree[fd[j].second]++;
				
				if(!(degree[fd[j].second]<=2&&degree[fd[j].first]<=2))
				{
					edcoun=-1;
					break;
				}
			    }
			}
			if(edcoun==m)
			{
				solexist=1;
				break;
			}
		}
		if(!solexist)
			cout<<-1<<endl;
		else
		{
			for(int i=0;i<m;i++)
				cout<<fsol[i].first<<" "<<fsol[i].second<<endl;
		}

	}
}