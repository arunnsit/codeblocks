#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
using namespace std;
int main()
{
	int n;
	string a;
	int r=0,b=0,g=0;
	cin>>n;
	cin>>a;
	for(int i=0;i<n;i++)
	{
		if(a[i]=='R')
			r++;
		if(a[i]=='B')
			b++;
		if(a[i]=='G')
			g++;
	}
	if(r&&g&&b)
		cout<<"BGR\n";
	else if(r>=2&&g>=2)
		cout<<"BGR\n";
	else if(b>=2&&g>=2)
		cout<<"BGR\n";
    else if(b>=2&&r>=2)
		cout<<"BGR\n";
	else if(r>=2&&(g||b))
		cout<<"BG\n";
	else if(b>=2&&(r||g))
		cout<<"GR\n";
    else if(g>=2&&(r||b))
		cout<<"BR\n";
	else if(r==1&&b==1)
		cout<<"G\n";
	else if(g==1&&b==1)
		cout<<"R\n";
	else if(r==1&&g==1)
		cout<<"B\n";
	else if(r)
		cout<<"R\n";
	else if(b)
		cout<<"B\n";
	else if(g)
		cout<<"G\n";


}
