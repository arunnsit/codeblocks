#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<algorithm>
#include<string.h>
#include<iomanip>
using namespace std;
int main()
{
	
}