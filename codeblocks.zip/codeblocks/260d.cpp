#include<iostream>
#include<algorithm>
#include<vector>
#include<set>
#include<stdio.h>
using namespace std;
set<pair<int,int> >s[2];
int main()
{
	int n,x,y;
	pair<int,int>sm,sm2;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&x,&y);
		s[x].insert(make_pair(y,i));
	}
	for(int i=1;i<=n-1;i++)
	{
		sm=*s[0].begin();
		sm2=*s[1].begin();
		s[0].erase(s[0].begin());
		s[1].erase(s[1].begin());
		//cout<<sm.first<<" "<<sm.second<<endl;
		if(sm.first>sm2.first||(sm.first==sm2.first&&s[0].size()<s[1].size()))
		{
			s[0].insert(make_pair(sm.first-sm2.first,sm.second));
			printf("%d %d %d\n",sm.second,sm2.second,sm2.first);
		}
		else 
		{
			s[1].insert(make_pair(sm2.first-sm.first,sm2.second));
			printf("%d %d %d\n",sm.second,sm2.second,sm.first);
		}
	}
}