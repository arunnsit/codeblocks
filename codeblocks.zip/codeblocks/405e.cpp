#include<iostream>
#include<stack>
#include<vector>
#include<algorithm>
#include<set>
using namespace std;
vector<int>adj[100008],num[100008];
int indegree[100009],visit[100009],ed[100009];
vector<pair<int,pair<int,int> > >v;
int solve(int u,int p)
{
	visit[u]=1;
	int c=0;
	vector<int>temp;
	for(int i=0;i<adj[u].size();i++)
	{
		if(!visit[adj[u][i]]){
		c=solve(adj[u][i],u);
		if(c)
			temp.push_back(adj[u][i]);
		}
		else if(adj[u][i]!=p&&ed[num[u][i]]==0)
		{
			ed[num[u][i]]=1;
			temp.push_back(adj[u][i]);
		}
	}
	if(temp.size()&1)
	{
		temp.push_back(p);
		for(int i=0;i<temp.size();i+=2)
		{
			v.push_back(make_pair(temp[i],make_pair(u,temp[i+1])));
		}
		return 0;
	}
	else
	{
		for(int i=0;i<temp.size();i+=2)
		{
			v.push_back(make_pair(temp[i],make_pair(u,temp[i+1])));
		}
		return 1;
	}
}
int main()
{
	int n,x,y,m,z;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		num[x].push_back(i+1);
		num[y].push_back(i+1);
	}
	if(m%2)
		cout<<"No solution\n";
	else 
	{
		solve(1,0);
		for(int i=0;i<v.size();i++)
			cout<<v[i].first<<" "<<v[i].second.first<<" "<<v[i].second.second<<endl;
	}
}