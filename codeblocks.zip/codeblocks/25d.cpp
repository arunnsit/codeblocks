#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
int ed[1005][1005]={0},P[1006],ranka[1006];
int find_parent(int x)
{   
	if (x != P[x]) P[x] = find_parent(P[x]);
    return P[x];
}
void create_set(int x)
{
	if(P[x]!=0)
		return;
	P[x] = x;
    ranka[x] = 1;
}
void merge(int x,int y)
{
	 x = find_parent(x);
     y = find_parent(y);
 
 if (ranka[x] > ranka[y]) P[y] = x;
 else P[x] = y;
 if (ranka[x] == ranka[y]) ranka[y] = ranka[x] + 1;
 
}
vector<pair<int,int> >destroy,add;
int main()
{
	int n,x,y,c=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		P[i]=i;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		if(find_parent(x)!=find_parent(y))
		{
			merge(x,y);
			c++;
			//cout<<"merger"<<endl;
		}
		else destroy.push_back(make_pair(x,y));
		ed[x][y]=1;
		ed[y][x]=1;
	}
	
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		{
			x=i;
			y=j;
			if(ed[x][y]==0&&c!=n-1&&find_parent(x)!=find_parent(y)){
			merge(x,y);
			c++;
			add.push_back(make_pair(x,y));
		}
	}
	cout<<add.size()<<endl;
	for(int i=0;i<add.size();i++)
		cout<<destroy[i].first<<" "<<destroy[i].second<<" "<<add[i].first<<" "<<add[i].second<<endl;
}