#include<iostream>
#include<algorithm>
using namespace std;
int arr[1000][1000],dp[1000][1000];
int main()
{
	int n,x,a,b,c;
	cin>>n;

	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			cin>>arr[i][j];
	cin>>x;	
	long long int sol=0;
	for(int k=0;k<x;k++)
	{	sol=0;
		cin>>a>>b>>c;
		a--;
		b--;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
		dp[i][j]=arr[i][j];
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			{arr[i][j]=min(arr[i][j],min(dp[i][a]+c+dp[b][j],dp[i][b]+c+dp[a][j]));sol+=arr[i][j];}
		cout<<sol/2<<" ";
}
}