#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include<string>
#include<unordered_map>
#define N 2000008
#include<string.h>
using namespace std;
string a,b;
vector<int>vec[N];
unordered_map<string,int>ma;
int mark[N],x=0;
int main()
{
	for(int i=2;i<=1000000;i++)
		if(vec[i].size()==0)
		for(int j=i;j<=1000000;j+=i)
		{
			vec[j].push_back(i);
		}
	int n,k,tmp,cp;
	scanf("%d %d",&n,&k);	
	for(int i=0;i<n;i++)
	{
		scanf("%d",&tmp);
		cp=tmp;
		for(int j=0;j<vec[cp].size();j++)
		{
			x=0;
			while(tmp%vec[cp][j]==0)
			{
				x++;
				tmp/=vec[cp][j];
			}
			mark[vec[cp][j]]=max(mark[vec[cp][j]],x);
		}

	}
	int ch=0;
	cp=k;
	for(int i=0;i<vec[cp].size();i++)
	{
			x=0;
			while(k%vec[cp][i]==0)
			{
				x++;
				k/=vec[cp][i];
			}
		if(mark[vec[cp][i]]<x)ch=1;
	}	
	if(ch)
		printf("No\n");
	else printf("Yes\n");
}