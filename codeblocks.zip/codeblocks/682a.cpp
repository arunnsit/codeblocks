#include<iostream>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<vector>
using namespace std;

int main()
{
	int n,m;
	cin>>n>>m;
	long long int sol=0;
	for(int i=1;i<=min(n,m);i++)
	{
		sol+=(max(n,m)+i)/5-i/5;
	}
	cout<<sol<<endl;
}