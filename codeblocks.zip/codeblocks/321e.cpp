#include<iostream>
#include<algorithm>
#include<vector>
#include<map>
#include<string>
#include<string.h>
#include<iostream>
#include<bits/stdc++.h>

using namespace std;
int a[4005][4005];
int dp[4005][4005];
int coun=0;
int opk=0;
inline int getint(){
    char c;
    while((c=getchar())<'0'||c>'9'); return c-'0';
}

int brute(int x,int y,int mid,int k)
{
	for(int i=x;i<=y&&i<=mid;i++)
	{
		coun++;
		if(dp[k][mid]>dp[k-1][i]+a[mid][mid]+a[i][i]-a[mid][i]-a[i][mid])
		{
			dp[k][mid]=dp[k-1][i]+a[mid][mid]+a[i][i]-a[mid][i]-a[i][mid];
			opk=i;
		}
	}
	return opk;
}
void solve(int l,int r,int x,int y,int k)
{
	if(l>r)
		return ;
	int div;
	if(l==r)
	{
		div=brute(x,y,l,k);
	}
	int mid=(l+r)/2;
	div=brute(x,y,mid,k);
	solve(l,mid-1,x,div,k);
	solve(mid+1,r,div,y,k);
}
int main()
{
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			a[i][j]=getint();
			a[i][j]+=a[i][j-1];
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			dp[i][j]=n*n*10;
			a[j][i]+=a[j-1][i];
		}

	for(int i=1;i<=n;i++)
	dp[1][i]=a[i][i];

	for(int i=2;i<=k;i++)
	{
		solve(1,n,1,n,i);
	}
	printf("%d\n",dp[k][n]/2);
}