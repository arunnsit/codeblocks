#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#include<stdio.h>
#include <cstdio>
#include <cassert>
#define N 300009
#define M 300009
using namespace std;
struct query
{
	char type;
	int x,y;
};
query qs[M];
map<pair<int,int>,vector<int> >ma;
int is_q[M],n;

struct edges
{
	int x,y;
	int l,r;
}temp;
vector<edges>eds;

struct node
{
	vector<edges>active_eds;
	int roll_position;
};
node tree[10*M];
edges ed;
void update(int cur,int l,int r)
{
	if(ed.l>r||ed.r<l)
	{
		return ;
	}
	if(ed.l<=l&&r<=ed.r)
	{
		tree[cur].active_eds.push_back(ed);
		return ;
	}
	int mid=l+(r-l)/2;
	update(2*cur+1,l,mid);
	update(2*cur+2,mid+1,r);
}
int Paren[N],sizh=0;
pair<int,int> hist[10*M];

void createset(int x)
{
	if(Paren[x])
		return ;
	Paren[x]=x;
}
int find_parent(int x)
{
	if(x==Paren[x])
		return x;
	return find_parent(Paren[x]);
}
int merge(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(v==u)
		return 0;
	if(u>v)
	{
		hist[sizh++]=make_pair(u,Paren[u]);
		Paren[u]=v;
	}
	else
	{
		hist[sizh++]=make_pair(v,Paren[v]);
		Paren[v]=u;
	}
	return 1;
}
int solution[M],cons;
void query(int cur,int l,int r)
{
	tree[cur].roll_position=sizh;
	//cout<<"cur:"<<cur<<endl;
	int p=0;
	for(int i=0;i<tree[cur].active_eds.size();i++)
	{
		//cout<<tree[cur].active_eds[i].x<<".."<<tree[cur].active_eds[i].y<<endl;

		p+=merge(tree[cur].active_eds[i].x,tree[cur].active_eds[i].y);
	}
	cons-=p;
	if(l==r)
	{
		if(is_q[l])
		{
			//cout<<"pos:"<<l<<endl;
			//for(int i=1;i<=n;i++)
			//	cout<<find_parent(i)<<" ";
			//cout<<endl;
			solution[l]=cons;
		}
		while(sizh>tree[cur].roll_position)
		{	
			Paren[hist[sizh-1].first]=hist[sizh-1].second;
			sizh--;
		}
		cons+=p;
		return;
	}
	int mid=l+(r-l)/2;
	query(2*cur+1,l,mid);
	query(2*cur+2,mid+1,r);
	while(sizh>tree[cur].roll_position)
	{
		Paren[hist[sizh-1].first]=hist[sizh-1].second;
		sizh--;
	}
	cons+=p;
}
int main()
{
	int m;
	 #define NAME "connect"
  	assert(freopen(NAME ".in", "r", stdin));
  	assert(freopen(NAME ".out", "w", stdout));
	scanf("%d%d", &n, &m);
	for(int i=1;i<=m;i++)
	{
		scanf(" %c", &qs[i].type);
		if(qs[i].type!='?')
		scanf("%d%d",&qs[i].x,&qs[i].y);
		if(qs[i].x>qs[i].y)
		{
			swap(qs[i].x,qs[i].y);
		}
		if(qs[i].type=='+'||qs[i].type=='-')
		{
			if(qs[i].type=='+')
			{
				ma[make_pair(qs[i].x,qs[i].y)].push_back(i);
			}
			else
			{
				temp.x=qs[i].x;
				temp.y=qs[i].y;
				if(ma[make_pair(qs[i].x,qs[i].y)].size())
				{
					temp.l=ma[make_pair(qs[i].x,qs[i].y)].back();
					temp.r=i;
					ma[make_pair(qs[i].x,qs[i].y)].pop_back();
					eds.push_back(temp);
				}
			}
		}
		else
		{
			is_q[i]=i;
		}
	}
	for(map<pair<int,int>, vector<int> >::iterator it=ma.begin();it!=ma.end();it++)
	{
		if(it->second.size())
		{
			temp.x=it->first.first;
			temp.y=it->first.second;
			temp.l=it->second[0];
			temp.r=m;
			it->second.clear();
			eds.push_back(temp);
		}	
	}
	for(int i=0;i<eds.size();i++)
	{
		//cout<<eds[i].l<<" "<<eds[i].r<<" "<<eds[i].x<<" "<<eds[i].y<<endl;
		ed=eds[i];
		update(0,1,m);

	}
	for(int i=1;i<=n;i++)
		createset(i);
	cons=n;
	query(0,1,m);
	for(int i=1;i<=m;i++)
	if(is_q[i])
	{
		printf("%d\n",solution[i]);
	}
	return 0;
}