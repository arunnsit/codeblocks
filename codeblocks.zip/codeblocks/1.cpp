#include<iostream>
#include<algorithm>
#include<math.h>
#include<map>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#include<unordered_map>
#include<stdio.h>
using namespace std;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int d;
		scanf("%d",&d);
		int r=d%9;
		if(r==0)
			cout<<1<<endl;
		else cout<<r+1<<endl;
	}
}
