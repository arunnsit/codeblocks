#include<iostream>
#include<algorithm>
#include<string.h>
#include<string>
#include<set>
#include<vector>
using namespace std;
string a;
long long int mod=1000000007;
int rep(char a)
{
	if(a>='0'&&a<='9')
	{
		return a-'0';
	}
	if(a>='a'&&a<='z')
	{
		return a-'a'+36;
	}
	if(a>='A'&&a<='Z')
	{
		return a-'A'+10;
	}
	if(a=='-')return 62;
	if(a=='_')return 63;
}
long long int counbits(int a)
{
	int c=0;
	long long int s=0,tmp=1;
	for(int i=0;i<6;i++)
	{
		if(((a>>i)&1)==0)
		{
			c++;
		}
	}
	for(int i=0;i<(1<<c);i++)
	{tmp=1;
		for(int j=0;j<c;j++)
		if(((i>>j)&1)==0){
			tmp*=2;
	}
		s+=tmp;
	}
	return s;
}
int main()
{
	cin>>a;
	long long int sol=1;
	for(int i=0;i<a.length();i++)
	{
		sol=(sol*counbits(rep(a[i])))%mod;
	}
	cout<<sol<<endl;
}