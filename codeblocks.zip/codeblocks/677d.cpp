#include<iostream>
#include<algorithm>
#include<string.h>
#include<string>
#include<set>
#include<vector>
using namespace std;
int a[305][305]={0};
struct node
{
	int x,y;
    int d;
};
vector<node>adj[301*301];
vector<int>row[301],col[301];
int dp[301][301]={0};
int main()
{
	//std::ios::sync_with_stdio(false);
	int n,m,p,X,Y;
	node tmp;
	cin>>n>>m>>p;
	
	for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
		{

			dp[i][j]=1000000000;
			cin>>a[i][j];
			tmp.x=i;
			tmp.y=j;
			if(a[i][j]==p)
			{
				X=i;
				Y=j;
			}
			adj[a[i][j]].push_back(tmp);
		}
	}
	//cout<<".....clearance level 1\n";
	//for(int i=1;i<=p;i++)
	//sort(row[i].begin(),row[i].end()),sort(col[i].begin(),col[i].end());
    //cout<<".....clearance level 2\n";
    for(int i=0;i<adj[1].size();i++)
    {
        dp[adj[1][i].x][adj[1][i].y]=adj[1][i].x+adj[1][i].y;
    }

    int cxup=0,cxlow=0,cylef=0,cyri=0,x,y,mid,an;
    for(int i=2;i<=p;i++)
    {
      // cout<<"......at level "<<i<<endl;
        for(int j=0;j<n;j++)
        row[j].clear();
        for(int j=0;j<m;j++)
        col[j].clear();
        for(int j=0;j<adj[i-1].size();j++)
        {
            row[adj[i-1][j].x].push_back(adj[i-1][j].y);
        }
        for(int j=0;j<adj[i-1].size();j++)
        {
            col[adj[i-1][j].y].push_back(adj[i-1][j].x);
        }
        for(int j=0;j<n;j++)
        {
            sort(row[j].begin(),row[j].end());
        }
        for(int j=0;j<m;j++)
        {
            sort(col[j].begin(),col[j].end());
        }
    	for(int j=0;j<adj[i].size();j++)
    	{
            x=adj[i][j].x;
            y=adj[i][j].y;
           // cout<<"was at "<<x<<" "<<y<<endl;
            for(int k=0;k<m;k++)
            if(col[k].size()){
                mid=lower_bound(col[k].begin(),col[k].end(),x)-col[k].begin();
                if(mid==col[k].size())
                {
                    an=col[k][mid-1];
                    dp[x][y]=min(dp[x][y],dp[an][k]+abs(x-an)+abs(y-k));
                }
                else if(mid==0)
                {
                    an=col[k][mid];
                    dp[x][y]=min(dp[x][y],dp[an][k]+abs(x-an)+abs(y-k));
                }
                else
                {
                    an=col[k][mid-1];
                    dp[x][y]=min(dp[x][y],dp[an][k]+abs(x-an)+abs(y-k));
                    an=col[k][mid];
                    dp[x][y]=min(dp[x][y],dp[an][k]+abs(x-an)+abs(y-k));
                }
                //cout<<"row at "<<
            }
            for(int k=0;k<n;k++)
            if(row[k].size()) {
                mid=lower_bound(row[k].begin(),row[k].end(),y)-row[k].begin();
                if(mid==row[k].size())
                {
                    an=row[k][mid-1];
                    dp[x][y]=min(dp[x][y],dp[k][an]+abs(x-k)+abs(y-an));

                }
                else if(mid==0)
                {
                    an=row[k][mid];
                    dp[x][y]=min(dp[x][y],dp[k][an]+abs(x-k)+abs(y-an));
                }
                else 
                {
                    an=row[k][mid-1];
                    dp[x][y]=min(dp[x][y],dp[k][an]+abs(x-k)+abs(y-an));
                    an=row[k][mid];
                    dp[x][y]=min(dp[x][y],dp[k][an]+abs(x-k)+abs(y-an));
                }
            }
    	}
    }
    cout<<dp[X][Y]<<endl;			
}