#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
string a;
int main()
{
	cin>>a;
	int x=a.length()-1;
	for(int i=0;i<a.length();i++)
	{
		if(a[i]!='a')
		{
			x=i;
			break;
		}
	}
	int y=a.length();
	for(int i=x+1;i<a.length();i++)
	{
		if(a[i]=='a')
		{
			y=i;
			break;
		}
	}
	for(int i=x;i<y;i++)
	{
		a[i]='a'+(a[i]-'a'-1+26)%26;
	}
	cout<<a<<endl;
}