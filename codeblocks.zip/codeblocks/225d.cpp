#include<iostream>
#include<string>
#include<queue>
#include<algorithm>
#include<map>
using namespace std;
char a[20][20],b[20][20];
int startx,starty,vis[20][20],dir[4][2]={{-1,0},{0,1},{1,0},{0,-1}},foodx,foody;
int n,m;
string inmask;
map<pair<pair<int,int>,string>,int> m1;
void dfs(int x,int y)
{
	vis[x][y]=1;
	int u,v;
	for(int i=0;i<4;i++)
	{
		u=x+dir[i][0];
		v=y+dir[i][1];
		if(u>=0&&u<n&&v>=0&&v<m&&a[u][v]-1==a[x][y]&&vis[u][v]==0)
		{
			inmask.push_back(i+'0');
			dfs(u,v);
		}
	}
}
int check(int x,int y,string a)
{
	int cx=x,cy=y,u=1;
	if(b[cx][cy]=='.'||b[cx][cy]=='@')
	b[cx][cy]='1';
    else {
        		u=0;
         }
    //cout<<"u:"<<u<<endl;    	
    if(u)    	
	for(int i=0;i<a.length();i++)
	{
		cx+=dir[a[i]-'0'][0];
		cy+=dir[a[i]-'0'][1];
		if(b[cx][cy]=='.')
	    b[cx][cy]='1'+i+1;
        else 
        	{
        		u=0;
        		//cout<<b[cx][cy]<<" "<<cx<<" "<<cy<<endl;
        		break;
        	}
	}
	//cout<<"u:"<<u<<endl;    
	cx=x,cy=y;
	if(b[cx][cy]>='1'&&b[cx][cy]<='9')
	b[cx][cy]='.';
	for(int i=0;i<a.length();i++)
	{
		cx+=dir[a[i]-'0'][0];
		cy+=dir[a[i]-'0'][1];
		if(b[cx][cy]>='1'&&b[cx][cy]<='9')
	    b[cx][cy]='.';

	}
	//cout<<"u:"<<u<<endl;    
	return u;
}
string fill(string a,string b)
{
	for(int i=0;i<b.length()-1;i++)
		a.push_back(b[i]);
	return a;
}
int main()
{
	cin>>n>>m;
	for(int i=0;i<n;i++)
		cin>>a[i];

	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
		{
			if(a[i][j]=='@')
			{
				foodx=i;
				foody=j;
			}
			if(a[i][j]=='1')
			{
				startx=i;
				starty=j;
			}
			if(a[i][j]>='1'&&a[i][j]<='9')
			{
				b[i][j]='.';
			}
			else b[i][j]=a[i][j];
		}
	dfs(startx,starty);
	//cout<<inmask<<endl;
	queue<pair<pair<int,int>,pair<int,string> > > q;
	q.push(make_pair(make_pair(startx,starty),make_pair(0,inmask)));

	int curx,cury,curd,nx,ny,d=-1;
	string curmask,remask;
	while(!q.empty()){
		curx=q.front().first.first;
		cury=q.front().first.second;
		curd=q.front().second.first;
	    //cout<<curx<<" "<<cury<<" "<<curd<<endl;
		if(curx==foodx&&cury==foody)
		{
			d=curd;
			break;
		}
		curmask=q.front().second.second;
		q.pop();
		for(int i=0;i<4;i++)
		if(i+'0'!=curmask[0]){
			remask.clear();
			nx=curx+dir[i][0];
			ny=cury+dir[i][1];
			remask.push_back('0'+(i+2)%4);
			remask=fill(remask,curmask);
			//cout<<nx<<" "<<ny<<" "<<remask<<" "<<check(nx,ny,remask)<<endl;
			if(nx>=0&&nx<n&&ny>=0&ny<m&&m1[make_pair(make_pair(nx,ny),remask)]==0&&check(nx,ny,remask))
			{
				m1[make_pair(make_pair(nx,ny),remask)]=1;
				q.push(make_pair(make_pair(nx,ny),make_pair(curd+1,remask)));
			}
		}
	}
	cout<<d<<endl;
}