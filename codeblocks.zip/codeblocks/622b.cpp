#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
int main()
{
	long long int n,x,y,h,m,a;
	scanf("%lld:%lld",&h,&m);
	cin>>a;
	x=0;
	x+=(m+a)/60;
	//cout<<"x:"<<x<<endl;
	m=(m+a)%60;
	h=(h+x)%24;
	if(h/10==0)
	{
		cout<<"0"<<h;
	}
	else cout<<h;
	cout<<":";
	if(m/10==0)
	{
		cout<<"0"<<m;
	}
	else cout<<m;
}