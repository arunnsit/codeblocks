#include<iostream>
#include<vector>
#include<set>
#define N 300009
#include<stdio.h>
#include<algorithm>
using namespace std;
vector<int>adj[N];
long long int value[N],mod=1000000007;
vector<pair<long long int ,long long int> >vos[N];
int in[N],out[N],level[N],timer=0;
void dfs(int u,int p)
{
	in[u]=++timer;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		level[adj[u][i]]=level[u]+1;
		dfs(adj[u][i],u);
	}
	out[u]=timer;
}
pair<pair<int,int>,int>quer[N];
int sz=0;
void update(int u,int p,long long int vals,long long int prev,long long int d)
{
	long long int cpy=0;
	for(int i=0;i<vos[u].size();i++)
	{
		vals=(vals+vos[u][i].first)%mod;
		cpy=(cpy+vos[u][i].second)%mod;
	}
	vos[u].clear();
	value[u]=(value[u]+vals-prev+mod)%mod;
	cpy=(cpy+d)%mod;
	prev=(prev+cpy)%mod;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		update(adj[u][i],u,vals,prev,cpy);
	}
}
int main()
{
	int n,x,q,type,t,v,k,block=2000;
	long long int sol=0;
	scanf("%d",&n);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d",&x);
		adj[x].push_back(i+1);
		adj[i+1].push_back(x);
	}
	dfs(1,0);
	scanf("%d",&q);
	while(q--)
	{
		if(sz==block)
		{
			update(1,0,0,0,0);
			sz=0;
		}
		scanf("%d",&type);
		if(type==1)
		{
			scanf("%d %d %d",&v,&x,&k);
			quer[sz++]=make_pair(make_pair(v,x),k);
			vos[v].push_back(make_pair(x,k));
		}
		else
		{
			scanf("%d",&k);
			sol=value[k];
			for(int i=0;i<sz;i++)
			{
				if(in[quer[i].first.first]<=in[k]&&out[quer[i].first.first]>=out[k])
				{
					sol=(10*mod+sol+quer[i].first.second-1LL*(level[k]-level[quer[i].first.first])*quer[i].second)%mod;
				}
			} 
			printf("%lld\n",(mod+sol)%mod);     
		}
	}
}
