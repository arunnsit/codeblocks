#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>
#include <vector>
#include <math.h>
using namespace std;

struct flow_graph{
    int MAX_V,E,s,t,head,tail;
    int *cap,*to,*next,*last,*dist,*q,*now;
    
    flow_graph(){}
    
    flow_graph(int V, int MAX_E){
        MAX_V = V; E = 0;
        cap = new int[2*MAX_E], to = new int[2*MAX_E], next = new int[2*MAX_E];
        last = new int[MAX_V], q = new int[MAX_V], dist = new int[MAX_V], now = new int[MAX_V];
        fill(last,last+MAX_V,-1);
    }
    
    void clear(){
        fill(last,last+MAX_V,-1);
        E = 0;
    }
    
    void add_edge(int u, int v, int uv, int vu = 0){
        to[E] = v, cap[E] = uv, next[E] = last[u]; last[u] = E++;
        to[E] = u, cap[E] = vu, next[E] = last[v]; last[v] = E++;
    }
	
	bool bfs(){
		fill(dist,dist+MAX_V,-1);
		head = tail = 0;
		
		q[tail] = t; ++tail;
		dist[t] = 0;
		
		while(head<tail){
			int v = q[head]; ++head;
			
			for(int e = last[v];e!=-1;e = next[e]){
				if(cap[e^1]>0 && dist[to[e]]==-1){
					q[tail] = to[e]; ++tail;
					dist[to[e]] = dist[v]+1;
				}
			}
		}
		
		return dist[s]!=-1;
	}
	
	int dfs(int v, int f){
		if(v==t) return f;
		
		for(int &e = now[v];e!=-1;e = next[e]){
			if(cap[e]>0 && dist[to[e]]==dist[v]-1){
				int ret = dfs(to[e],min(f,cap[e]));
				
				if(ret>0){
					cap[e] -= ret;
					cap[e^1] += ret;
					return ret;
				}
			}
		}
		
		return 0;
	}
	
	long long max_flow(int source, int sink){
		s = source; t = sink;
		long long f = 0;
		int x;
		
		while(bfs()){
			for(int i = 0;i<MAX_V;++i) now[i] = last[i];
			
			while(true){
				x = dfs(s,INT_MAX);
				if(x==0) break;
				f += x;
			}
		}
		
		return f;
	}
}G;
vector<int>primes;
vector<int>facs[100000];
vector<pair<int,int> >gps;
vector<int>fi[103];
vector<pair<pair<int,int>,int> >eds;
int coun[102]={0};
int main()
{
	for(int i=2;i<100000;i++)
	{
		if(facs[i].size()==0)
		{
			primes.push_back(i);
			for(int j=i;j<100000;j+=i)
			{
				facs[j].push_back(i);
			}
		}
	}
	int n,m,x,y,c=0,s=0;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x);
		int cpy=x;
		for(int j=0;j<primes.size();j++)
		{
			while(cpy%primes[j]==0)
			{
				fi[i].push_back(primes[j]);
				cpy/=primes[j];
			}
		}
		if(cpy!=1)
		{
			fi[i].push_back(cpy);
		}
		c+=fi[i].size();
		coun[i]=fi[i].size()+coun[i-1];
	}
	for(int i=0;i<m;i++)
	{
		scanf("%d %d",&x,&y);
		if(x&1)
			swap(x,y);
		gps.push_back(make_pair(x,y));
		for(int j=0;j<fi[x].size();j++)
		{
			for(int k=0;k<fi[y].size();k++)
			if(fi[y][k]==fi[x][j])
			{
				eds.push_back(make_pair(make_pair(coun[x-1]+j+1,coun[y-1]+k+1),1));
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		//cout<<"i:"<<coun[i]<<endl;
		if(i&1)
		{
			for(int j=0;j<fi[i].size();j++)
			eds.push_back(make_pair(make_pair(coun[i-1]+j+1,coun[n]+1),1));
		}
		else
		{
			for(int j=0;j<fi[i].size();j++)
			eds.push_back(make_pair(make_pair(0,coun[i-1]+j+1),1));
		}
	}
	flow_graph G(coun[n]+5,eds.size()+5);
	for(int i=0;i<eds.size();i++)
	{
		//cout<<eds[i].first.first<<".."<<eds[i].first.second<<"..."<<eds[i].second<<endl;
		G.add_edge(eds[i].first.first,eds[i].first.second,eds[i].second);
	}
	cout<<G.max_flow(0,coun[n]+1)<<endl;
}