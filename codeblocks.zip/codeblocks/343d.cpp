#include<iostream>
#include<stdio.h>
#include<set>
#define N 500008
#include<vector>
using namespace std;
vector<int>adj[N];
int low[N],out[N],timer=-1;
int value[N]={0},last_update[N],isup[N],isup2[N],P[N];
void dfs(int u,int p)
{
	low[u]=++timer;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		P[adj[u][i]]=u;
		dfs(adj[u][i],u);
	}
	out[u]=timer;
	//cout<<u<<" "<<low[u]<<" "<<out[u]<<endl;
}
int sz=0;
int tree[5*N],laz[5*N];
void flush(int x)
{
	if(laz[x])
	{
		laz[x]=0;
		tree[x]=1;
		laz[2*x+1]=1;
		laz[2*x+2]=1;
	}
}

void update(int curr,int l,int r,int x,int y)
{
	flush(curr);
	if(l>y||x>r)
		return ;
	if(x<=l&&r<=y)
	{
		tree[curr]=1;
		laz[2*curr+1]=1;
		laz[2*curr+2]=1;
		return ;
	}
	int mid=l+(r-l)/2;
	update(2*curr+1,l,mid,x,y);
	update(2*curr+2,mid+1,r,x,y);
	tree[curr]=tree[2*curr+1]&tree[2*curr+2];
}
void point(int curr,int l,int r,int x)
{
	//cout<<"updates:"<<curr<<" "<<l<<" "<<r<<" "<<x<<endl; 
	flush(curr);
	if(l==r)
	{
		tree[curr]=0;
		return ;
	}
	int mid=l+(r-l)/2;
	if(mid>=x)
	point(2*curr+1,l,mid,x);
    else
	point(2*curr+2,mid+1,r,x);
	tree[curr]=tree[2*curr+1]&tree[2*curr+2];
}
int query(int curr,int l,int r,int x,int y)
{
	flush(curr);
	if(l>y||x>r)
		return 1;
	if(x<=l&&r<=y)
	{
		return tree[curr];
	}
	int mid=l+(r-l)/2,u;
	u= query(2*curr+1,l,mid,x,y)&query(2*curr+2,mid+1,r,x,y);

	return u;
}
void printtree(int curr,int l,int r)
{
	flush(curr);
	//cout<<"curr: "<<curr<<" "<<l<<" "<<r<<" "<<tree[curr]<<endl;
	if(l==r)
	{
		return ;
	}
	int mid=l+(r-l)/2;
	printtree(2*curr+1,l,mid);
	printtree(2*curr+2,mid+1,r);
}
int main()
{
	int n,x,y,q,type,cur;
	scanf("%d",&n);
	for(int i=0;i<n-1;i++)
	{
		scanf("%d %d",&x,&y);
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	dfs(1,0);
	cin>>q;
	while(q--)
	{
		cin>>type>>x;
		if(type==1)
		{
			if(!query(0,0,timer,low[x],out[x]))
			{
				point(0,0,timer,low[P[x]]);
			}
			update(0,0,timer,low[x],out[x]);
		}
		else if(type==2)
		{
			point(0,0,timer,low[x]);
		}
		else cout<<query(0,0,timer,low[x],out[x])<<endl;
		//printtree(0,0,timer);
	}
}