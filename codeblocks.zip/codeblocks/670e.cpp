#include<iostream>
#include<set>
#include<string>
using namespace std;
set<pair<int,int > > s;
#include<stack>
stack<int>st;
int nex[500009],pre[500009];
int main()
{
	string a,b,c;
	int n,m,p,x,y;
	cin>>n>>m>>p;
	cin>>a>>b;
	for(int i=0;i<n;i++)
	{
		if(a[i]=='(')
		{
			st.push(i);
		}
		else
		{
			x=st.top();
			st.pop();
			s.insert(make_pair(i,x));
			s.insert(make_pair(x,i));
			pre[i]=x;
			nex[x]=i;
		}
	}
	int cur=p-1,w,z;
	set<pair<int,int> >::iterator it,cp,ne,pon,nor;
	if(a[cur]=='(')
		it=s.find(make_pair(cur,nex[cur]));
	else it=s.find(make_pair(cur,pre[cur]));
 	for(int i=0;i<m;i++)
	{
		if(b[i]=='L')
		{
			it--;
		}
		else if(b[i]=='R')
		{
			it++;
		}
		else
		{
			cp=it;
			pon=it;
			nor=it;
			nor++;
			pon--;
			x=(*it).first;
			y=(*it).second;
			if(x<y)
			{
				int tick=0;
				while(1)
				{
				    w=(*cp).first;
				    z=(*cp).second;
				    cp++;
				    if(cp!=s.end())
				    {
				    	it=cp;
				    }
				    else
				    {
				    	it=pon;
				    	tick=1;
				    }
				   // cout<<w<<" "<<z<<endl;
				    s.erase(s.find(make_pair(w,z)));
				    if(w==y||tick)
				    	break;
				}
			}
			else
			{
				int tick=0;
				while(1)
				{
				    w=(*cp).first;
				    z=(*cp).second;
				    if(s.find(make_pair(w,z))==s.begin())
				    {
				    	it=nor;
				    	tick=1;
				    }
				    else
				    {
				    	cp--;
				    	it=cp;
				    }
				   // cout<<w<<" "<<z<<endl;
				    s.erase(s.find(make_pair(w,z)));
				    if(w==y||tick)
				    	break;
				}
				if(nor!=s.end())
				{
					it=nor;
				}
			}
		}
	}
	for(set<pair<int,int> >::iterator it=s.begin();it!=s.end();it++)
	{
		x=(*it).first;
		y=(*it).second;
		if(x<y)
			c.push_back('(');
		else c.push_back(')');
	}
	cout<<c<<endl;


}