#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
using namespace std;
std::vector<int> v;
int main()
{
	int n,k;
	cin>>n>>k;
	int tmp;
	for(int i=0;i<n;i++)
	{
		cin>>tmp;
		v.push_back(tmp);
	}
	sort(v.begin(),v.end());
	int x=0,fac=1,zap=0,las;
	long long int tot=0,breaker=0;
	for(int i=n-2;i>=0;i--)
	{
		tot=fac*(v[i+1]-v[i]);
		if(tot>k)
		{
			breaker=i;
			zap=1;
			las=v[i+1];
			break;
		}
		else k-=tot;
		x+=tot;
		fac++;
	}
	if(x==0)
		cout<<0<<endl;

	else if(!zap)
		cout<<1<<endl;
	else
	{
		int gap=n-1-breaker;
		int rmin=las-k/gap-(k%gap==0?0:1),rmax=las-k/gap;
		cout<<rmax<<" "<<rmin<<endl;
		int fillers=k,mul=1,toadd;
		int old=breaker;
		for(int i=0;i<breaker;i++)
		{
			toadd=mul*(v[i+1]-v[i]);
			if(toadd>fillers)
			{
				breaker=i;
			    zap=1;
			    las=v[i];
				break;
			}
			else fillers-=tot;
			mul++;
		}
		gap=breaker+1;
		int lmin=las+fillers/(gap),lmax=las+fillers/(gap)+(fillers%gap==0?0:1);
		int sp=0;
		for(int i=breaker+1;i<=old;i++)
			sp=max(sp,v[i]);
		cout<<max(max(lmax-rmin,rmax-rmin),max(sp-rmin,sp-lmin))<<endl;

	}

}