#include<iostream>
using namespace std;

int P[1006],ranka[1006];
int find_parent(int x)
{   
	if (x != P[x]) P[x] = find_parent(P[x]);
    return P[x];
}
void create_set(int x)
{
	if(P[x]!=0)
		return;
	P[x] = x;
    ranka[x] = 1;
}
void merge(int x,int y)
{
	 x = find_parent(x);
     y = find_parent(y);
 
 if (ranka[x] > ranka[y]) P[y] = x;
 else P[x] = y;
 if (ranka[x] == ranka[y]) ranka[y] = ranka[x] + 1;
}
int arr[1000];
int main()
{
	int n,tmp;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>arr[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>tmp;
		create_set(i);
		if(i-tmp>=1&&i-tmp<=n)
		{
			create_set(i-tmp);
			merge(i,i-tmp);
		}
		if(i+tmp>=1&&i+tmp<=n)
		{
			create_set(i+tmp);
			merge(i,i+tmp);
		}
	}
	int ch=0;
	for(int i=1;i<=n;i++)
	{
		if(find_parent(arr[i])!=find_parent(i))
			ch=1;
		//cout<<find_parent(arr[i])<<" "<<find_parent(i)<<endl;
	}
	if(!ch)
		cout<<"YES\n";
	else cout<<"NO\n";
}