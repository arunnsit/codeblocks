#include<iostream>
#include<algorithm>
#include<vector>
#include<math.h>
#include<set>
#include<string>
#include<string.h>
using namespace std;
int m,dmagic,lmax=0;
string a,b;
long long int dp[2003][2003][2]={0};
long long int solve(int l,int mod,int eq)
{
	if(l==lmax)
	{
		if(!mod)
		return 1;
	    return 0;
	}
	if(dp[l][mod][eq]!=-1)
		return dp[l][mod][eq];
	long long int sol=0;
	if(l&1)
	{
		if(eq)
		{
			if(dmagic<=a[l]-'0')
			{
				if(dmagic==a[l]-'0')
				sol+=solve(l+1,(mod*10+dmagic)%m,1);
				else sol+=solve(l+1,(mod*10+dmagic)%m,0);
				sol%=1000000007;
			}
		}
		else
		{
			sol+=solve(l+1,(mod*10+dmagic)%m,0);
			sol%=1000000007;
		}
	}
	else
	{
		if(eq)
		{
			for(int i=0;i<a[l]-'0';i++)
			if(i!=dmagic){
				sol=(sol+solve(l+1,(mod*10+i)%m,0))%1000000007;
				sol%=1000000007;
			}
			if(a[l]-'0'!=dmagic)
			sol+=solve(l+1,(mod*10+a[l]-'0')%m,1);
			sol%=1000000007;
		}
		else
		{
			for(int i=0;i<=9;i++)
			if(i!=dmagic){
				sol+=solve(l+1,(mod*10+i)%m,0);
				sol%=1000000007;
			}
		}
	}
	return dp[l][mod][eq]=sol%1000000007;
}
long long int retro(string a)
{
	int c=0,ch=0;
	for(int i=0;i<a.size();i++)
	{
		c=(c*10+a[i]-'0')%m;
	}
	for(int i=0;i<a.size();i++)
	{
		if(i&1&&a[i]-'0'!=dmagic)
			ch=1;
		else if(i%2==0&&a[i]-'0'==dmagic)
		{
			ch=1;
		}
	}
	if(!ch&&!c)
		return 1;
	return 0;
}
int main()
{
	cin>>m>>dmagic;
	cin>>b>>a;
	memset(dp,-1,sizeof(dp));
	long long int X1=0,X2=0;
	lmax=a.size();
	X1=solve(0,0,1);
	memset(dp,-1,sizeof(dp));
	lmax=b.size();
	a=b;
	X2=solve(0,0,1);
	cout<<(X1-X2+retro(b)+1LL*50*1000000007)%1000000007<<endl;
}