#include<iostream>
#include<vector>
#include<bitset>
#define N 100009
using namespace std;
struct node
 {
 	int type,a,b;
 }; 
 vector<int>adj[N];
 vector<node>quers;
int mark[2000]={0};
int answer[N]={0};
bitset<1005>bit[1005],one;
int qsuccess[N]={0},n,m,q;
int sol=0;
void dfs(int cur,int p)
{
	//cout<<"cur:"<<cur<<" "<<quers[cur].type<<endl;
	if(quers[cur].type==1)
	{
		if(bit[quers[cur].a][quers[cur].b]==0)
		{
			sol++;
			qsuccess[cur]=1;
		}
		bit[quers[cur].a][quers[cur].b]=1;
	}
	else if(quers[cur].type==2)
	{
		if(bit[quers[cur].a][quers[cur].b]==1)
		{
			sol--;
			qsuccess[cur]=1;
		}
		bit[quers[cur].a][quers[cur].b]=0;
	}
	else if(quers[cur].type==3)
	{
		qsuccess[cur]=1;
		sol-=bit[quers[cur].a].count();
		bit[quers[cur].a]^=one;

		sol+=bit[quers[cur].a].count();
	}
	//cout<<bit[1]<<".."<<endl;
	//cout<<bit[2]<<".."<<endl;
	answer[cur]=sol;
	for(int i=0;i<adj[cur].size();i++)
	{
		dfs(adj[cur][i],cur);
	}
	if(quers[cur].type==1)
	{
		if(qsuccess[cur])
		{
			bit[quers[cur].a][quers[cur].b]=0;
			sol--;
		}
	}
	else if(quers[cur].type==2)
	{
		if(qsuccess[cur])
		{
			bit[quers[cur].a][quers[cur].b]=1;
			sol++;
		}
	}
	else if(quers[cur].type==3)
	{
		sol-=bit[quers[cur].a].count();
		bit[quers[cur].a]^=one;
		sol+=bit[quers[cur].a].count();
	}
}
int main()
{
	int t,a,b;
	node temp;
	cin>>n>>m>>q;
	temp.type=0;
	temp.a=0;
	temp.b=0;
	quers.push_back(temp);
	one[0]=0;
	for(int i=1;i<=m;i++)
	{
		one[i]=1;
	}
	for(int i=0;i<=n;i++)
		for(int j=0;j<=m;j++)
			bit[i][j]=0;
	for(int i=1;i<=q;i++)
	{
		cin>>temp.type>>temp.a;
		
		if(temp.type==1||temp.type==2)
		{
			cin>>temp.b;
		}

		quers.push_back(temp);
		if(temp.type==4)
		{
			adj[temp.a].push_back(i);
		}
		else
		{
			adj[i-1].push_back(i);
		}
	}
	dfs(0,0);
	for(int i=1;i<=q;i++)
		cout<<answer[i]<<endl;
}