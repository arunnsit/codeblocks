
#include<iostream>
#include<vector>
#include<map>
#include<math.h>
#include<set>
#include<algorithm>
#include<string>
#define N 200009
#define LOGN 35
using namespace std;
vector<int>adj[N];
vector<pair<int,int > >q[N];
map<string,int>ms[N];
string a[N];
long long int sub[N],maxx,can;
long long int sol[N];
int L[LOGN][N],vis[N];
void sub_solve(int u,int p)
{
	vis[u]=1;
	sub[u]=1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		sub_solve(adj[u][i],u);
		sub[u]+=sub[adj[u][i]];
	}
}
int big[N],cnt[N];
void add(int u,int p,int x,int h)
{
	if(x==1)
	{	ms[h][a[u]]++;
		if(ms[h][a[u]]==1)
		cnt[h]++;
	}
	else 
	{
		if(ms[h][a[u]]==1)
		cnt[h]--;
		ms[h][a[u]]--;
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&big[adj[u][i]]==0)
	{
		add(adj[u][i],u,x,h+1);
	}
}
void dfs(int u,int p,int keep,int h)
{
	int bigsiz=-1,bigboy=-1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigsiz<sub[adj[u][i]])
	{
		bigsiz=sub[adj[u][i]];
		bigboy=adj[u][i];
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigboy!=adj[u][i])
	{
		dfs(adj[u][i],u,0,h+1);
	}
	if(bigboy!=-1)
	{
		dfs(bigboy,u,1,h+1);
		big[bigboy]=1;
	}
	add(u,p,1,h);
	for(int i=0;i<q[u].size();i++)
	if(h+q[u][i].second<N)
	sol[q[u][i].first]=cnt[h+q[u][i].second];
	if(bigboy!=-1)
	{
		big[bigboy]=0;
	}
	if(keep==0)
	{
		add(u,p,-1,h);
		maxx=0;
		can=0;
	}
}
void lca(int n)
{
		for(int j=2;j<30;j++)
		{
			for(int i=1;i<=n;i++)
			{
			    L[j][i]=L[j-1][L[j-1][i]];
			}
		}
}
int ancestor(int node,int k){
    while(k){
        if(node==0){
            return 0;
        }
        node = L[(int)log2(k&-k)+1][node];
        k&=k-1;
    }
    return node;
}
int main()
{
	int n,m,x,y;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		ms[i].clear();
		cin>>a[i];
		scanf("%d",&x);
		{adj[x].push_back(i);
		adj[i].push_back(x);}
		L[1][i]=x;
	}
	lca(n);
	scanf("%d",&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d",&x,&y);
		q[x].push_back(make_pair(i,y));
	}
	sub_solve(0,0);
	dfs(0,0,0,1);
	for(int i=1;i<=m;i++) 
		printf("%lld\n",sol[i]);
}