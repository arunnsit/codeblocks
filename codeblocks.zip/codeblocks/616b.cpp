#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,m,ma=0,mi,x;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		mi=1000000009;
		for(int j=0;j<m;j++)
		{
			cin>>x;
			mi=min(mi,x);
		}
		ma=max(mi,ma);
	}
	cout<<ma<<endl;

}