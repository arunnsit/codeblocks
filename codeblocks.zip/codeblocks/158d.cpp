#include<iostream>
using namespace std;
int arr[1000000];
int main()
{
	int n,sol=0;
	cin>>n;
	for(int i=0;i<n;i++)
		{
			cin>>arr[i];
			sol+=arr[i];
		}
	
	{
		int sm=0;
		for(int j=1;j<n;j++)
		{
			if((n%j==0)&&(n/j)>2)
			{
			for(int k=0;k<j;k++)
			{
				sm=0;
				for(int i=k;i<n;i+=j)
				{
					sm+=arr[i];
				}
				sol=max(sol,sm);
			}}
		}
			cout<<sol<<endl;

	}
		

}