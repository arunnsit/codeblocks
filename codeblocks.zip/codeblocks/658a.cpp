#include<iostream>
#include<algorithm>
using namespace std;
int p[100],t[100];
int main()
{
	int n,c;
	cin>>n>>c;
	for(int i=0;i<n;i++)
	{
		cin>>p[i];
	}
	for(int i=0;i<n;i++)
	{
		cin>>t[i];
	}
	int sol1=0,t1=0,sol2=0,t2=0;
	for(int i=0;i<n;i++)
	{
		t1+=t[i];
		sol1+=max(0,p[i]-t1*c);
	}
	for(int i=n-1;i>=0;i--)
	{
		t2+=t[i];
		sol2+=max(0,p[i]-t2*c);
	}
	if(sol1>sol2)
		cout<<"Limak\n";
	else if(sol1<sol2)
		cout<<"Radewoosh\n";
	else cout<<"Tie\n";

}
