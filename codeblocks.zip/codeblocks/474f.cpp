#include<iostream>
#include<algorithm>
#include<vector>
#include<stdio.h>
#include<unordered_map>
using namespace std;
#define blocks 500
int gcd(int a,int b)
{
	if(a==0)swap(a,b);
	if(b==0)return a;
	return gcd(b,a%b);
}
unordered_map<int,int>ma;
int tree[600009];
int arr[100009];
void maketree(int curr,int l,int r)
{
	if(l==r)
	{
		tree[curr]=arr[l];
		return ;
	}
	int mid=l+(r-l)/2;
	maketree(2*curr+1,l,mid);
	maketree(2*curr+2,mid+1,r);
	tree[curr]=gcd(tree[2*curr+1],tree[2*curr+2]);
}
int query_gcd(int curr,int l,int r,int x,int y)
{	
	if(r<x||l>y)
	return 0;
	if(x<=l&&r<=y)
	return tree[curr];
	int mid=l+(r-l)/2;
	return gcd(query_gcd(2*curr+1,l,mid,x,y),query_gcd(2*curr+2,mid+1,r,x,y));
}

struct query
{
	int l,r,nos,block;
};
query q[100009];
bool cmp(query a,query b)
{
	if(a.block==b.block)
		return a.r<b.r;
	else return a.block<b.block;
}
int freq[100009]={0};
void add(int x)
{
	if(x>=1)
	freq[ma[arr[x-1]]]++;
}
void del(int x)
{	
	if(x>=1)
	freq[ma[arr[x-1]]]--;
}
int solution[100009];
int main()
{
	int n,timer=1,m;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		if(!ma[arr[i]])
		{
			ma[arr[i]]=timer++;
		}
	}
	scanf("%d",&m);
	maketree(0,0,n-1);
	for(int i=0;i<m;i++)
		{
			scanf("%d %d",&q[i].l,&q[i].r);
			q[i].nos=i;
			q[i].block=q[i].l/blocks;
		}
	sort(q,q+m,cmp);
	int curr_l=0,curr_r=0,gc;
	for(int i=0;i<m;i++)
	{
		while(q[i].l<curr_l)
		{   
			curr_l--;
			add(curr_l);
		}
		while(q[i].l>curr_l)
		{
			del(curr_l);
			curr_l++;
		}
		while(q[i].r<curr_r)
		{
			del(curr_r);
			curr_r--;

		}
		while(q[i].r>curr_r)
		{   
			curr_r++;
			add(curr_r);
		}
		gc=query_gcd(0,0,n-1,q[i].l-1,q[i].r-1);
		//cout<<q[i].l<<" "<<q[i].r<<" "<<gc<<endl;
		if(ma[gc])
		{
		//cout<<"hey"<<endl;
			solution[q[i].nos]=q[i].r-q[i].l+1-freq[ma[gc]];
		}
		else solution[q[i].nos]=q[i].r-q[i].l+1;
	}
	for(int i=0;i<m;i++)
	printf("%d\n",solution[i]);
}