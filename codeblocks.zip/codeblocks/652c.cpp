#include<iostream>
#include<stdio.h>
#include<vector>
#define N 500009
using namespace std;
int a[N],posin[N];
vector<int>pairs[N];
int main()
{
	int n,m,x,y,c=0;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			posin[a[i]]=i;
		}
	for(int i=0;i<m;i++)
	{
		scanf("%d %d",&x,&y);
		pairs[x].push_back(posin[y]);
		pairs[y].push_back(posin[x]);
	}
	x=-1,y=0;
	long long int sol=0;
	while(y<n&&x<y)
	{
		//cout<<x<<" "<<y<<" "<<c<<" "<<sol<<endl;
		if(c)
		{
			x++;
			for(int i=0;i<pairs[a[x]].size();i++)
			if(pairs[a[x]][i]>x&&pairs[a[x]][i]<=y)
			{
				c--;
			}
		}
		else
		{
			sol+=(y-x);
			y++;
			for(int i=0;i<pairs[a[y]].size();i++)
			if(pairs[a[y]][i]>x&&pairs[a[y]][i]<=y)
			{
				c++;
			}
		}
	}
	printf("%I64d\n",sol);
}