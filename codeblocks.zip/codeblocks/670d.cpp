#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;
int arr1[2000],arr2[2000],arr3[2000];
int main()
{
	int n,k;
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&arr1[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&arr2[i]);
	for(int i=1;i<=n;i++)
		{
			arr3[i]=arr2[i]/arr1[i];
			arr2[i]=arr2[i]%arr1[i];
		}
	while(1)
	{
		int min_in=0,min_inval=200000;
		for(int i=1;i<=n;i++)
		{
			if(min_inval>arr3[i])
			{
				min_inval=arr3[i];
				min_in=i;
			}
		}
		int more_need=((arr3[min_in]+1)*arr1[min_in])-arr3[min_in]*arr1[min_in]-arr2[min_in];
		if(more_need>k)
			break;
		else 
		{
			k-=more_need;
			arr3[min_in]++;
			arr2[min_in]=0;
		}
	}
	sort(arr3+1,arr3+1+n);
	printf("%d\n",arr3[1]);

}