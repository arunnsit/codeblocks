#include<iostream>
using namespace std;
int main()
{
	int x=0,n,is=0,cus;
	cin>>n;
	if(n%400==0||((n%100!=0)&&(n%4==0)))
	{
		x=(366+x)%7;
		is=1;
	}
	else x=(365+x)%7; 
	n++;
	while(1)
	{
		cus=0;
		if(n%400==0||((n%100!=0)&&(n%4==0)))
		{
			cus=1;
		}
		//cout<<"cus:"<<cus<<" "<<x<<endl;
		if(!x&&cus==is)break;
		if(cus)x=(x+366)%7;
		else x=(x+365)%7;
		n++;
	}
	cout<<n<<endl;
}