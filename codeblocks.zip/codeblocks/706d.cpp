#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<stdio.h>
#include<string.h>
using namespace std;
using namespace std;
struct node
{
	int x;
	node *next[2];
	node()
	{
		x=0;
		next[0]=NULL;
		next[1]=NULL;
	}
};
int cbit,rbit;
node *root;
void insert(int x)
{
	node *it=root;
	//it->x++;
	for(int i=31;i>=0;i--)
	{
		cbit=((x>>i)&1);
		if(!it->next[cbit])
		{
			it->next[cbit]=new node();
		}
		it->x++;
		it=it->next[cbit];
	}
	it->x++;
}
long long int query(int x)
{
	node *it=root;
	long long int s=0;

	for(int i=31;i>=0;i--)
	{
		cbit=((x>>i)&1);
		rbit=cbit^1;
		if(it->next[rbit]&&it->next[rbit]->x>0)
		{
			s+=(1<<i);
			it=it->next[rbit];
		}
		else
		{
			it=it->next[cbit];
		}
	}
	return s;
}
void deleteo(int x)
{
	node *it=root;
	//it->x--;
	for(int i=31;i>=0;i--)
	{
		cbit=((x>>i)&1);
		it->x--;
		it=it->next[cbit];
	}
	it->x--;
}
int main()
{
	root=new node();
	int n,x;
	scanf("%d",&n);
	char a[5];
	insert(0);
	while(n--)
	{
		scanf("%s %d",a,&x);
		if(a[0]=='+')
			insert(x);
		else if(a[0]=='-')
			deleteo(x);
		else printf("%I64d\n",query(x));
	}	
}