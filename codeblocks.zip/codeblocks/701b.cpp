#include<iostream>
#include<vector>
#include<set>
#include<algorithm>
using namespace std;
vector<int>r[100009],c[100009];
vector<long long int >sol;
int main()
{
	long long int n,m,total,totalrows=0,totalcols=0;
	int x,y;
	cin>>n>>m;
	total=n*n;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		if(r[x].size()==0&&c[y].size()==0)
		{
			total-=2*n-1;
			//cout<<"case1:"<<tot
			total+=totalcols+totalrows;
			totalrows++;
			totalcols++;
		}
		else if(r[x].size()==0)
		{
			total-=n;
			total+=totalcols;
			totalrows++;
		}
		else if(c[y].size()==0)
		{
			total-=n;
			total+=totalrows;
			totalcols++;
		}
		r[x].push_back(y);
		c[y].push_back(x);	
		sol.push_back(total);
	}
	for(int i=0;i<sol.size();i++)
		cout<<sol[i]<<" ";
}