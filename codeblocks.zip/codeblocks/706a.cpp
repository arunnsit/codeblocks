#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#include<iomanip>
#include<math.h>
using namespace std;
int main()
{
	cout<<fixed;
	double a,b,x,y,speed,dist,tim=10000000000000.0;
	cin>>a>>b;
	int n;
	cin>>n;
	while(n--)
	{
		cin>>x>>y>>speed;
		dist=(x-a)*(x-a)+(y-b)*(y-b);
		dist=sqrt(dist);
		tim=min(tim,dist/speed);
	}
	cout<<setprecision(9)<<tim<<endl;
}