#include<iostream>
using namespace std;
int main()
{
	int n,x,y;
	cin>>n;
	cout<<2*((n+2))/3-1;
}