#include<stdio.h>
#include<unordered_map>
#include<vector>
#include<algorithm>
using namespace std;
unordered_map<int,int>ma;
struct node 
{
	int x,y,x2,y2,nos;

};
vector<int>v;
node a[1000009];
bool cmp(node a,node b)
{
	if(a.x==b.y)
		return a.y<b.y;
	return a.x<b.x;
}
int marker[4000009]={0};
int inversecomp[4000009]={0};
int main()
{
	int n,k;
	scanf("%d %d",&n,&k);
	for(int i=0;i<n;i++)
	{
		scanf("%d %d",&a[i].x,&a[i].y);
		v.push_back(a[i].x);
		v.push_back(a[i].y);
		a[i].nos=i+1;
	}
	sort(v.begin(),v.end());
	int comp=0;
	for(int i=0;i<v.size();i++)
	{
		if(!ma[v[i]])
		{
			ma[v[i]]=comp+2;
			inversecomp[comp+2]=v[i];			
			comp+=2;
		}
	}
	for(int i=0;i<n;i++)
	{
		a[i].x2=ma[a[i].x];
		a[i].y2=ma[a[i].y];
		marker[a[i].x2]++;
		marker[a[i].y2+1]--;
	}
	for(int i=2;i<=comp;i++)
	{
		marker[i]+=marker[i-1];
		//cout<<marker[i]<<" ";
	}
	int cm,lx,ly;
	vector<pair<int,int> >v;

		if(marker[3]<k&&marker[2]>=k)
		{
			v.push_back(make_pair(inversecomp[2],inversecomp[2]));
		}
	for(int i=4;i<=comp;i+=2)
	{
		cm=marker[i-1];
		if(cm>=k)
		{       
			    if(v.size())
			    {
			    	lx=v[v.size()-1].first;
			        ly=v[v.size()-1].second;
			        if(ly==inversecomp[i-2])
			    {
			    	v.pop_back();
			    	v.push_back(make_pair(lx,inversecomp[i]));
			    }
			    else 
			    {
			    	v.push_back(make_pair(inversecomp[i-2],inversecomp[i]));
			    }
			    }
				else v.push_back(make_pair(inversecomp[i-2],inversecomp[i]));
			}
		else if(marker[i]>=k)
		{
			v.push_back(make_pair(inversecomp[i],inversecomp[i]));
		}
	}
	printf("%lu\n",v.size());
	for(int i=0;i<v.size();i++)
		printf("%d %d\n",v[i].first,v[i].second);




}