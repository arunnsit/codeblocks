#include<iostream>
#include<algorithm>
#include<vector>
#include<unordered_map>
#include<set>
#include<string>
using namespace std;
struct lex_compare {
    bool operator() (const pair<int,string> a, const pair<int,string> b) const{
        return a.first > b.first;
    }
};
multiset<pair<int,string>,lex_compare>s[10008];
int main()
{
	int n,m,score,region;
	cin>>n>>m;
	string a;
	while(n--)
	{
		cin>>a>>region>>score;
		s[region].insert(make_pair(score,a)); 
	}
	pair<int,string>c1,c2;
	for(int i=1;i<=m;i++)
	{
		c1=*s[i].begin();
		s[i].erase(s[i].begin());
		c2=*s[i].begin();
		s[i].erase(s[i].begin());
		if(!s[i].empty()&&((*s[i].begin())).first==c2.first)
		{
			cout<<"?\n";
		}
		else cout<<c1.second<<" "<<c2.second<<endl;

	}
}