#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
vector<int>adj[100009];
int pa[100009];
void dfs(int start,int parent)
{
	pa[start]=parent;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=parent){
		dfs(adj[start][i],start);
	}
}
int main()
{
	int n,r1,r2,x;
	cin>>n>>r1>>r2;
	for(int i=1;i<=n;i++)
	{
		if(r1!=i)
		{
			cin>>x;
			adj[x].push_back(i);
			adj[i].push_back(x);
		}
	}
	dfs(r2,-1);
	for(int i=1;i<=n;i++)
	{if(pa[i]!=-1)
		cout<<pa[i]<<" ";
	}	

}