#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
using namespace std;
vector<int>adj[100005];
int marks[100005],smark[100005],pop[100005];
queue<int>q;
int main()
{
	int t,x,y,k,m,u,n;
	cin>>n>>m;
	while(m--)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
		{
			cin>>smark[i];
			if(smark[i]==marks[i])
			{
				q.push(i);
			}
		}
		int c=0;
	while(!q.empty())
	{
		u=q.front();
		q.pop();
		if(smark[u]!=marks[u])
		{

		}
		else
		{
		pop[u]=1;
		marks[u]++;
		c++;
		for(int i=0;i<adj[u].size();i++)
		{
			marks[adj[u][i]]++;
			if(!pop[adj[u][i]])
			{
				q.push(adj[u][i]);
			}
		}}
	}
	int i;
	for(i=1;i<=n;i++)
		if(marks[i]==smark[i])
			break;
	if(i==n+1)
	{
		cout<<c<<endl;
		for(int i=1;i<=n;i++)
			if(pop[i])
				cout<<i<<" ";
	}
	else cout<<-1<<endl;
}