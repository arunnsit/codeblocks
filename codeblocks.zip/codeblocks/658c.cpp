#include<iostream>
#include<vector>
#include<algorithm>
#define N 100008
using namespace std;
vector<int>adj[N];

int sol_dia=1;
int dfs(int u)
{
	int x=0;
	int h[3]={0};
	for(int i=0;i<adj[u].size();i++)
	{
		h[0]=dfs(adj[u][i]);
		sort(h,h+3);
	}	
	if(h[2]==0)
		return 1;
	else
	{
		sol_dia=max(sol_dia,h[2]+h[1]);
		return h[2]+1;
	}
}
int main()
{
	int n,d,h,sol_h,dc,tc=0,nvs=0;
	int edges=0;
	cin>>n>>d>>h;
	dc=d;
		if(d>h)
		{
			for(int i=1;i<=h;i++)
				adj[i].push_back(i+1);
			edges+=h;
			d-=h;
			int newv=h+2;
			if(d>0)
			{
				adj[1].push_back(newv);
				edges++;
				d--;
				tc=d;
				nvs=newv;
				while(d--)
				{
					adj[newv].push_back(newv+1);
					newv++;
					edges++;
				}
				newv=nvs+tc+1;
				if(edges<n-1)
				{
					while(edges<n-1)
					{
						edges++;
						adj[1].push_back(newv);
						newv++;
					}
				}
			}
		}
		else if(d==h)
		{
			for(int i=1;i<=h;i++)
				adj[i].push_back(i+1);
			edges+=h;
			int newv=h+2;
			while(edges<n-1)
			{
				edges++;
				adj[2].push_back(newv);
				newv++;
			}
		}
		
		
	sol_h=dfs(1)-1;	
	//cout<<edges<<" "<<sol_dia<<" "<<sol_h<<endl;
	if(edges==n-1&&sol_h==h&&sol_dia==dc)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=0;j<adj[i].size();j++)
				cout<<i<<" "<<adj[i][j]<<endl;
		}	
	}
	else cout<<"-1\n";

}