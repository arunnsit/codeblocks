#include<iostream>
#include<algorithm>
#include<math.h>
#include<set>
#include<vector>
using namespace std;
int main()
{
	int n,k,m,b,p,x=0,y=0,oc;
	cin>>n>>b>>p;
	oc=n;
	while(n!=1)
	{
		x=1;
		while(x<=n)
		{
			x*=2;
		}
		x/=2;
		//cout<<x<<"..\n";
		y+=(x/2)*(2*b+1);
		n-=x/2;
	}
	cout<<y<<" "<<p*oc<<endl;
}