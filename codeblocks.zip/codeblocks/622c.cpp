#include<iostream>
#include<vector>
#include<set>
#include<stdio.h>
#include<algorithm>
using namespace std;
int a[200009];
int fsol[200009]={0};
struct node
{
	int x,y;
};
struct node2
{
	int x,y;
};
bool cmp(node2 a,node2 b)
{
	return a.x>b.x;
}
node tree[700008],tree2[700008];
node2 arr[5];
node c;
int cal=0;
node merge1(node a,node b)
{	
	node c;
	if(a.x>b.x)
	{
		c.x=a.x;
		c.y=a.y;
	}
	else
	{
		c.x=b.x;
		c.y=b.y;
	} 

	return c;
}
node merge2(node a,node b)
{	
	node c;
	if(a.x<b.x)
	{
		c.x=a.x;
		c.y=a.y;
	}
	else
	{
		c.x=b.x;
		c.y=b.y;
	} 
	return c;
}
void maketree(int curr,int l,int r)
{
	if(l==r)
	{
		tree[curr].x=a[l];
		tree[curr].y=l;
		return;
	}
	int mid=l+((r-l)>>1);
	maketree((curr<<1)+1,l,mid);
	maketree((curr<<1)+2,mid+1,r);
	tree[curr]=merge1(tree[(curr<<1)+1],tree[(curr<<1)+2]);
}
void maketree2(int curr,int l,int r)
{
	if(l==r)
	{
		tree2[curr].x=a[l];
		tree2[curr].y=l;
		return;
	}
	int mid=l+((r-l)>>1);
	maketree2((curr<<1)+1,l,mid);
	maketree2((curr<<1)+2,mid+1,r);
	tree2[curr]=merge2(tree2[(curr<<1)+1],tree2[(curr<<1)+2]);
}
node nul1,nul2;

node query(int curr,int l,int r,int x,int y)
{
	if(x>r||y<l)
	{
		return nul1;
	}
	if(l>=x&&r<=y)
		return tree[curr];
	int mid=l+((r-l)>>1);
	node c=merge1(query((curr<<1)+1,l,mid,x,y),query((curr<<1)+2,mid+1,r,x,y));
	return c;
}
node query2(int curr,int l,int r,int x,int y)
{
	if(x>r||y<l)
	{
		return nul2;
	}
	if(l>=x&&r<=y)
		return tree2[curr];
	int mid=l+((r-l)>>1);
	node c=merge2(query2((curr<<1)+1,l,mid,x,y),query2((curr<<1)+2,mid+1,r,x,y));
	return c;
}
int main()
{
	//ios_base::sync_with_stdio(false);
	int n,m,x,y,z;
	nul1.x=-1;
	nul1.y=0;
	nul2.x=10000000;
	nul1.y=0;
	scanf("%d %d",&n,&m);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	maketree(0,0,n-1);
	maketree2(0,0,n-1);
    node se,l,r;
	for(int i=1;i<=m;i++)
		{
			scanf("%d %d %d",&x,&y,&z);
			x--;
			y--;
			l=query(0,0,n-1,x,y);
			r=query2(0,0,n-1,x,y);
			//bcout<<l.x<<" "<<r.x<<endl;
			if(z!=l.x&&l.x>=0&&l.x<=1000000)
				printf("%d\n",l.y+1);
			else if(z!=r.x&&r.x>=0&&r.x<=1000000)
				printf("%d\n",r.y+1);
			else printf("-1\n");
		}
	
}