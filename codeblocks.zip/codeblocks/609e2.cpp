#include<stdio.h>
#include<vector>
#include<iostream>
#include<algorithm>
#define N 200100
#define LOGN 22
using namespace std;
vector<int>adj[N],weight[N],number[N];
int P[N],siz[N],level[N];
struct node
{
	int x,y,z,no;
};
bool cmp(node a,node b)
{
	return a.z<b.z;
}
node ed[N];
void createset(int x)
{
	if(P[x]!=0)
		return ;
	P[x]=x;
	siz[x]=1;
}
int find_parent(int x)
{
	if(x==P[x])
		return x;
	P[x]=find_parent(P[x]);
	return P[x];
}
void merge(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(v==u)
		return ;
	if(u>v)
	{
		P[u]=v;
		siz[v]+=siz[u];
		siz[u]=1;
	}
	else
	{
		P[v]=u;
		siz[u]+=siz[v];
		siz[v]=1;
	}
}
int inmst[N];
int n,dp[LOGN+3][N],dp2[LOGN+3][N];
int dfs1(int start,int p)
{
	int s=0;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=p){
		s+=dfs1(adj[start][i],start);
	}
	return s+1;
}
void dfs0(int curr,int p)
{
	for(int i=0,it;i<adj[curr].size();i++)
	{
		it=adj[curr][i];
		if(it!=p)
	{   
		dp[0][it]=curr;
		dp2[0][it]=weight[curr][i];
		level[it]=level[curr]+1;
		dfs0(it,curr);
	}}
}
void preprocess()
{
	level[0]=0;
	dp[0][0]=0;
	dp2[0][0]=0;
	dfs0(0,0);
	for(int i=1;i<LOGN;i++)
		{
			for(int j=0;j<n;j++)
			{
				dp[i][j] = dp[i-1][dp[i-1][j]];
				//cout<<dp[i-1][j]<<" ";
			}
		//	cout<<endl;
	}
	for(int i=1;i<LOGN;i++)
		{
			for(int j=0;j<n;j++)
		    {
		    	dp2[i][j]=max(dp2[i-1][j],dp2[i-1][dp[i-1][j]]);
		    	//cout<<dp2[i-1][j]<<" ";	
		    }	
		  //  cout<<endl;
		} 
}
int lca(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			b=dp[i][b];
	if(a==b)return a;
	for(int i=LOGN-1;i>=0;i--)
		if(dp[i][a]!=dp[i][b])
			a=dp[i][a],b=dp[i][b];
	return dp[0][a];
}
int query(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	int s=0;
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			{
				s=max(s,dp2[i][b]);
				//cout<<"considered: "<<dp2[i][b]<<endl;
				b=dp[i][b];
			}
	return s;		
}
long long int soluton[N]={0};
int main()
{
	int m;
	scanf("%d %d",&n,&m);
	long long int mst=0;
	for(int i=0;i<m;i++)
	{
	    scanf("%d %d %d",&ed[i].x,&ed[i].y,&ed[i].z);
		ed[i].no=i+1;
	}
	sort(ed,ed+m,cmp);
	for(int i=0;i<m;i++)
	{
		createset(ed[i].x);
		createset(ed[i].y);
		if(find_parent(ed[i].x)!=find_parent(ed[i].y))
		{
			inmst[ed[i].no]++;
			//cout<<"..."<<ed[i].x<<" "<<ed[i].y<<" "<<ed[i].z<<endl;
			adj[ed[i].x-1].push_back(ed[i].y-1);
			adj[ed[i].y-1].push_back(ed[i].x-1);
			weight[ed[i].x-1].push_back(ed[i].z);
			weight[ed[i].y-1].push_back(ed[i].z);
			number[ed[i].x-1].push_back(ed[i].no-1);
		    number[ed[i].y-1].push_back(ed[i].no-1);
			merge(ed[i].x,ed[i].y);
			mst+=ed[i].z;
		}
	}
  //  cout<<" "<<mst<<endl;
    dfs1(0,0);
	preprocess();
   // cout<<"yeah: "<<mainq(6,4)<<endl;
    for(int i=0;i<m;i++)
    {
    	if(inmst[ed[i].no])
    	{
    		soluton[ed[i].no]=(long long int)mst;
    	}
    	else 
    		{
    			int lc=lca(ed[i].x-1,ed[i].y-1);
    			//cout<<"lca of "<<ed[i].x<<" "<<ed[i].y<<" "<<lc+1<<endl;
    			soluton[ed[i].no]=mst-max(query(ed[i].x-1,lc),query(ed[i].y-1,lc))+(long long int)ed[i].z;
    		}
    }
    for(int i=1;i<=m;i++)
    	printf("%I64d\n",soluton[i]);
}