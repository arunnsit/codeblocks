#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#define N 100009
#define MAXN 100000000000000000LL
using namespace std;
long long int c[100009];
vector<string>v;
int dp2[N][2][2]={0};
bool cmp(int x,int or1,int or2)
{
	if(dp2[x][or1][or2]!=-1)
		return dp2[x][or1][or2];
	string a=v[x],b=v[x+1];

	if(or1)
		reverse(a.begin(),a.end());
	if(or2)
		reverse(b.begin(),b.end());
	if(a<=b)
		dp2[x][or1][or2]=1;
	else dp2[x][or1][or2]=0;
	return a<=b;
}
long long int dp3[N][2];
long long int dp(int n,int prev)
{
	long long int sol=MAXN;
	if(n==1)
	{
		if(cmp(n,0,prev))
		{
			return 0;
		}
		else if(cmp(n,1,prev))
		{
			return c[n];
		}
		else return sol;
	}
	if(dp3[n][prev]!=-1)
		return dp3[n][prev];
	if(cmp(n,0,prev))
	{
		sol=min(sol,dp(n-1,0));
	}
	if(cmp(n,1,prev))
	{
		sol=min(sol,dp(n-1,1)+c[n]);
	}
	return dp3[n][prev]=sol;
}
int main()
{
	int n;
	memset(dp2,-1,sizeof(dp2));
	memset(dp3,-1,sizeof(dp3));
	cin>>n;
	v.push_back("");
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	string a;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
		v.push_back(a);
	}
	long long int sol=min(dp(n-1,0),dp(n-1,1)+c[n]);
	if(sol>=MAXN)
		cout<<-1<<endl;
	else cout<<sol<<endl;
}