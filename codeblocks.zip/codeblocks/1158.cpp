//makes me sad , but i took help for this one
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<string.h>
using namespace std;
vector<int>v;
class BigInt // Solution can be up to 50^50
{
    char A[200];
    int n;
public:

    BigInt(int k = 0)
    {
        memset(A, 0, sizeof(A));
        A[0] = k;
        n = 0;
        while(k)
            A[n] = k, k /= 10;
    }

    void operator+=(BigInt& b)
    {
        int carry = 0, i;
        for(i = 0; i <= b.n; i++)
        {
            A[i] += (b.A[i]+carry);
            carry = A[i]/10;
            A[i] -= carry*10;
        }
        while(carry)
        {
            A[i] += (b.A[i]+carry);
            carry = A[i]/10;
            A[i++] -= carry*10;
        }
        n = std::max(n, i-1);
    }

    void operator-=(BigInt& b)
    {
        int borrow = 0;
        for(int i = 0; i <= n; i++)
        {
            A[i] -= (b.A[i]+borrow);
            borrow = 0;
            if(A[i] < 0)
                A[i] += 10, borrow = 1;
        }
        while(n && !A[n])
            n--;
    }

    operator std::string ()
    {
        std::string ret;
        for(int i = n; i >= 0 ; i--)
            ret += ('0' + A[i]);
        return ret;
    }
}; 
vector<int>ending[350];
BigInt A[505],F[502][502];
vector<pair<int,int> >pre[505];
bool cmp(string a,string b)
{
	return a.size()<b.size();
}
int main()
{
	long long int n,m,p;
	cin>>n>>m>>p;
	A[0]=1;
	string letter,tmp;
	cin>>letter;
	string b;
	vector<string>forb,ffb;
	
	for(int i=0;i<p;i++)
	{
		cin>>b;
		forb.push_back(b);
	}
	sort(forb.begin(),forb.end(),cmp);
	//filter
	int k=0,ch=0;
	for(int i=forb.size()-1;i>=0;i--)
	{
		ch=0;
		for(int j=i-1;j>=0;j--)
		{
			if(forb[i].find(forb[j])!=-1)
			{
				ch=1;
			}
		}
		if(ch==0)
		ffb.push_back(forb[i]);
	}
	sort(ffb.begin(),ffb.end());
	for(int i=0;i<ffb.size();i++)
	{
		//cout<<ffb[i]<<endl;
		for(int j=0;j<ffb.size();j++)
		{
			for(k=1;k<ffb[j].size()&&k<ffb[i].size();k++)
			{
				int u=0;
				for(u=0;u<k;u++)
					if(ffb[i][ffb[i].size()-k+u] != ffb[j][u])
					{
						break;
					}
				if(u==k)	
				{
				pre[j].push_back(make_pair(i,k));
				//cout<<"aL"<<i<<" "<<k<<endl;
			    }
			}
		}
		if(ffb[i].size())
		ending[ffb[i][ffb[i].size()-1]].push_back(i);
	}
	BigInt adder=0;
	int x,y,sz;
	for(int i=1;i<=m;i++)
	{
		for(int j=0;j<letter.size();j++)
		{
			A[i]+=A[i-1];
			for(int k=0;k<ending[letter[j]].size();k++)
			{
				adder=(ffb[ending[letter[j]][k]].size()<=i)?A[i-ffb[ending[letter[j]][k]].size()]:0;
				for(int o=0;o<pre[ending[letter[j]][k]].size();o++)
				{
					x=pre[ending[letter[j]][k]][o].first;
					y=pre[ending[letter[j]][k]][o].second;
					sz=ffb[ending[letter[j]][k]].size();
					if(i-sz+y>0)
						adder-=F[x][i-sz+y];
				}
				//cout<<ending[letter[j]][k]<<" "<<pre[ending[letter[j]][k]].size()<<endl;
				F[ending[letter[j]][k]][i]=adder;
				A[i]-=adder;
				//cout<<(string)A[i]<<" "<<(string)adder<<endl;
			}
		}
	}
	cout<<(string)A[m]<<endl;
}