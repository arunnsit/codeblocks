#include<iostream>
#include<algorithm>
using namespace std;
struct point
{
	long long int x,y,nos,dist;
};
point store[100009];
bool cmp(point a,point b)
{
	return a.dist<b.dist;
}
bool cmp2(point a,point b)
{
	if(a.x==b.x)
		return a.y>b.y;
	else 
		return a.x<b.x;
}
bool check(int a)
{
	if((store[0].y-store[1].y)*(store[0].x-store[a].x)==(store[0].y-store[a].y)*(store[0].x-store[1].x))
		return 0;
	else return 1;

}
int main()
{
	int n,i,j,k,x,y;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>store[i].x;
		cin>>store[i].y;
		store[i].nos=i+1;
	}
	sort(store,store+n,cmp2);
	for(i=0;i<n;i++)
	{
		store[i].dist=(store[i].x-store[0].x)*(store[i].x-store[0].x)+(store[i].y-store[0].y)*(store[i].y-store[0].y);
	}
	sort(store,store+n,cmp);
	for(i=2;i<n;i++)
		if(check(i)==1)
			break;
	cout<<store[0].nos<<" "<<store[1].nos<<" "<<store[i].nos;	
}