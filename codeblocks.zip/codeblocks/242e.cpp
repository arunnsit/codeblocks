#include<iostream>
#include<algorithm>
#define N 500005
using namespace std;
struct node
{
	long long int sum,xordy;
	int coun[22];
};
node merge(node a,node b)
{
	node c;
	c.sum=a.sum+b.sum;
	c.xordy=0;
	for(int i=0;i<=21;i++)
		c.coun[i]=a.coun[i]+b.coun[i];
	return c;
}
node nulli()
{
	node c;
	c.sum=0;
	for(int i=0;i<=21;i++)
		c.coun[i]=0;
	return c;
}
node tree[5*N];
long long int pi=1;
int a[N];
void flush_down(int cur,int sz)
{
	//cout<<cur<<"cur"<<tree[cur].xordy<<"......\n";
	tree[2*cur+1].xordy^=tree[cur].xordy;
	tree[2*cur+2].xordy^=tree[cur].xordy;
	pi=1;
	tree[cur].sum=0;
	for(int i=0;i<=21;i++)
	{
		if((tree[cur].xordy>>i)&1)
		{
			tree[cur].coun[i]=sz-tree[cur].coun[i];
		}
		tree[cur].sum+=1LL*tree[cur].coun[i]*pi;
		pi*=2;
	}
	tree[cur].xordy=0;
}
void make_tree(int cur,int l,int r)
{
	if(l==r)
	{
		tree[cur].xordy=0;
		tree[cur].sum=a[l];
		for(int i=0;i<=21;i++)
		{
			tree[cur].coun[i]=((a[l]>>i)&1);
		}
		return ;
	}
	int mid=l+(r-l)/2;
	make_tree(2*cur+1,l,mid);
	make_tree(2*cur+2,mid+1,r);
	tree[cur]=merge(tree[2*cur+1],tree[2*cur+2]);
}
void update(int cur,int l,int r,int x,int y,int xordy)
{
	flush_down(cur,r-l+1);
	if(r<x||y<l)
	{
		return ;
	}
	if(x<=l&&r<=y)
	{
		tree[cur].xordy=xordy;
		flush_down(cur,r-l+1);
		return ;
	}
	int mid=l+(r-l)/2;
	update(2*cur+1,l,mid,x,y,xordy);
	update(2*cur+2,mid+1,r,x,y,xordy);
	tree[cur]=merge(tree[2*cur+1],tree[2*cur+2]);
}
long long int query(int cur,int l,int r,int x,int y)
{
	flush_down(cur,r-l+1);
	if(r<x||y<l)
	{
		return 0;
	}
	if(x<=l&&r<=y)
	{
		return tree[cur].sum;
	}
	int mid=l+(r-l)/2;
	return query(2*cur+1,l,mid,x,y)+query(2*cur+2,mid+1,r,x,y);
}
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	make_tree(0,0,n-1);
	//cout<<query(0,0,n-1,0,n-1)<<endl;
	int q,x,y,z,ti;
	cin>>q;
	while(q--)
	{
		cin>>ti;
		if(ti==1)
		{
			cin>>x>>y;
			cout<<query(0,0,n-1,x-1,y-1)<<endl;
		}
		else
		{
			cin>>x>>y>>z;
			update(0,0,n-1,x-1,y-1,z);
		}
	}
}