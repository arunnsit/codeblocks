#include<iostream>
#include<algorithm>
#include<set>
#include<math.h>
#include<vector>
#include<string>
#include<string.h>
#include<stdio.h>
using namespace std;
int p[10000];
char a[100000];
int main()
{
	int n,ch=1,cp=0,mcp=0,poswe;
	cin>>n;

	for(int i=1;i<=n;i++)
	{
		cin>>p[i];
	}
	getchar();
	for(int i=1;i<=n;i++)
	{
		cin.getline(a,1000);
		cp=0;
		poswe=0;
		mcp=0;
		for(int j=0;a[j]!='\0';j++)
		{
			if(a[j]=='a'||a[j]=='e'||a[j]=='i'||a[j]=='o'||a[j]=='u'||a[j]=='y')
			{
				cp++;
				poswe++;
			}
			if(a[j]==' ')
			{
				if(poswe)
					mcp++;
				poswe=0;
			}
		}
		if(poswe)
		mcp++;
		poswe=0;
		if(cp>=p[i]&&p[i]>=mcp)
		{

		}
		else ch=0;
		//cout<<"ch:"<<ch<<endl;
	}
if(ch)
	cout<<"YES\n";
else cout<<"NO\n";
}