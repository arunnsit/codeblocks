#include<iostream>
#include<set>
#include<vector>
using namespace std;
set<pair<double,int> >s;
double d[100009],total;
int deleted[100009],deleted2[100009];
vector<int>adj[100009],sol;
int main()
{
	int n,m,k,x,y,unmark=0;
	cin>>n>>m>>k;
	for(int i=0;i<k;i++)
	{
		cin>>x;
		deleted[x]=1;
		deleted2[x]=1;
	}
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
	if(!deleted[i]){
		total=0;
		for(int j=0;j<adj[i].size();j++)
		if(!deleted[adj[i][j]]){
			total++;
		}
		d[i]=(total*1.0)/(adj[i].size()*1.0);
		//cout<<i<<"..."<<d[i]<<endl;
		s.insert(make_pair((total*1.0)/(adj[i].size()*1.0),i));
	}
	double mi=0,ma=0,mo=0;
	while(!s.empty())
	{
		mi=(*s.begin()).first;
		x=(*s.begin()).second;
		s.erase(s.begin());
		if(d[x]==mi&&mi>=0&&deleted[x]==0)
		{
			ma=max(mi,ma);
			//cout<<mi<<" "<<x<<endl;
			for(int i=0;i<adj[x].size();i++)
			if(!deleted[adj[x][i]]){
				d[adj[x][i]]=(1.0*d[adj[x][i]]*adj[adj[x][i]].size()-1.0)/(1.0*adj[adj[x][i]].size());
				s.insert(make_pair(d[adj[x][i]],adj[x][i]));
			}
			deleted[x]=1;
		}
	}
	for(int i=1;i<=n;i++)
	if(!deleted2[i]){
		total=0;
		for(int j=0;j<adj[i].size();j++)
		if(!deleted2[adj[i][j]]){
			total++;
		}
		d[i]=(total*1.0)/(adj[i].size()*1.0);
		//cout<<i<<"..."<<d[i]<<endl;
		s.insert(make_pair((total*1.0)/(adj[i].size()*1.0),i));
	}
	while(!s.empty())
	{
		mi=(*s.begin()).first;
		x=(*s.begin()).second;
		s.erase(s.begin());
		if(d[x]==mi&&mi>=0&&deleted2[x]==0)
		{
			mo=max(mi,mo);
			if(mo==ma)
			{
				sol.push_back(x);
				while(!s.empty())
				{
					mi=(*s.begin()).first;
					x=(*s.begin()).second;
					if(d[x]==mi&&mi>=0&&deleted2[x]==0)
					sol.push_back(x);
					s.erase(s.begin());
				}
				break;
			}
			for(int i=0;i<adj[x].size();i++)
			if(!deleted2[adj[x][i]]){
				d[adj[x][i]]=(1.0*d[adj[x][i]]*adj[adj[x][i]].size()-1.0)/(1.0*adj[adj[x][i]].size());
				s.insert(make_pair(d[adj[x][i]],adj[x][i]));
			}
			deleted2[x]=1;
		}
	}
	cout<<sol.size()<<endl;
	for(int i=0;i<sol.size();i++)
		cout<<sol[i]<<" ";
}