#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<map>
#include<vector>
using namespace std;
int arr[300005];
map<int,int>m;
vector<pair<int,int> >v;
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&arr[i]);
	}
	int k=0,last=1;
	for(int i=1;i<=n;i++)
	{
		if(m[arr[i]])
		{
			v.push_back(make_pair(last,i));
			for(int j=last;j<=i;j++)
			{
				m[arr[j]]=0;
			}
			last=i+1;
		}
		else
		{
			m[arr[i]]=i;
		}
	}
	
	if(v.size())
	{v[v.size()-1].second=n;
		printf("%lu\n",v.size());
	for(int i=0;i<v.size();i++)
	{
		printf("%d %d\n",v[i].first,v[i].second);
	}
}else printf("-1\n");
}