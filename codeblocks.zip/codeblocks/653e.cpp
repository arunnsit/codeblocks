#include<iostream>
#include<vector>
#include<set>
using namespace std;
#define N 500009
set<int>adj[N],s;

void dfs(int u)
{
	//cout<<"u:"<<u<<endl;
	while(!s.empty())
	{
		set<int>::iterator it=s.begin();
		while(it!=s.end())
		{
			if(adj[u].find(*it)==adj[u].end())
			{
				break;
			}
			it++;
		}
		if(it!=s.end())
		{
			int x=*it;
			s.erase(it);
			dfs(x);
		}
		else break;
	}
}
int main()
{
	int n,m,k,mdeg=0;
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		if(x==1||y==1)
			mdeg++;
		adj[x].insert(y);
		adj[y].insert(x);
	}
	for(int i=1;i<=n;i++)
		s.insert(i);
	int coun=0;
	while(!s.empty())
	{
		coun++;
		int x=*s.begin();
		s.erase(s.begin());
		dfs(x);
	}
	//cout<<"ini:"<<coun<<endl;
	if(coun!=1)
		cout<<"impossible\n";
	else 
	{
		mdeg=n-mdeg-1;
		for(int i=2;i<=n;i++)
			adj[1].insert(i);
		s.clear();
		for(int i=1;i<=n;i++)
		s.insert(i);
		coun=0;
		while(!s.empty())
		{
			coun++;
			int x=*s.begin();
			s.erase(s.begin());
			dfs(x);
		}
		if(k<=mdeg&&k>=coun-1)
		{
			cout<<"possible\n";
		}
		else cout<<"impossible\n";
	}
}