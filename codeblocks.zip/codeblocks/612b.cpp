#include<iostream>
#include<algorithm>
using namespace std;
struct node
{
	int x,y;
};
bool cmp(node a,node b)
{
	return a.x<b.x;
}
node a[1000000];
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i].x;
		a[i].y=i;
	}
	sort(a,a+n,cmp);
	long  long int sol=0;
	for(int i=1;i<n;i++)
	{
		sol+=abs(a[i].y-a[i-1].y);
	}
	cout<<sol<<endl;

}