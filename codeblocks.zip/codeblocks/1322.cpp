#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
struct node
{
	int x,y;
};
bool cmp(node a,node b)
{
	if(a.x==b.x)
		return a.y<b.y;
	return a.x<b.x;
}
vector<node >v;
int main()
{
	int n;
	string a,b,d,e;
	cin>>n;
	cin>>a;
	node tmp;
	for(int i=0;i<a.length();i++)
	{
		tmp.x=a[i];
		tmp.y=i;
		v.push_back(tmp);
	}
	sort(v.begin(),v.end(),cmp);
	int x=n-1,c=0;

	while(c!=a.length())
	{
		c++;
		b.push_back(v[x].x);
		x=v[x].y;
	}
	
	cout<<b<<endl;
}