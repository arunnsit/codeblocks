#include <cstdio>
#include <climits>
#include <algorithm>
#include <vector>
#include <map>
#include <iostream>
#define N 30000
using namespace std;

struct flow_graph{
    int MAX_V,E,s,t,head,tail;
    int *cap,*to,*next,*last,*dist,*q,*now;
    
    flow_graph(){}
    
    flow_graph(int V, int MAX_E){
        MAX_V = V; E = 0;
        cap = new int[2*MAX_E], to = new int[2*MAX_E], next = new int[2*MAX_E];
        last = new int[MAX_V], q = new int[MAX_V], dist = new int[MAX_V], now = new int[MAX_V];
        fill(last,last+MAX_V,-1);
    }
    
    void clear(){
        fill(last,last+MAX_V,-1);
        E = 0;
    }
    
    void add_edge(int u, int v, int uv, int vu = 0){
        to[E] = v, cap[E] = uv, next[E] = last[u]; last[u] = E++;
        to[E] = u, cap[E] = vu, next[E] = last[v]; last[v] = E++;
    }
	
	bool bfs(){
		fill(dist,dist+MAX_V,-1);
		head = tail = 0;
		
		q[tail] = t; ++tail;
		dist[t] = 0;
		
		while(head<tail){
			int v = q[head]; ++head;
			
			for(int e = last[v];e!=-1;e = next[e]){
				if(cap[e^1]>0 && dist[to[e]]==-1){
					q[tail] = to[e]; ++tail;
					dist[to[e]] = dist[v]+1;
				}
			}
		}
		
		return dist[s]!=-1;
	}
	
	int dfs(int v, int f){
		if(v==t) return f;
		
		for(int &e = now[v];e!=-1;e = next[e]){
			if(cap[e]>0 && dist[to[e]]==dist[v]-1){
				int ret = dfs(to[e],min(f,cap[e]));
				
				if(ret>0){
					cap[e] -= ret;
					cap[e^1] += ret;
					return ret;
				}
			}
		}
		
		return 0;
	}
	
	long long max_flow(int source, int sink){
		s = source; t = sink;
		long long f = 0;
		int x;
		
		while(bfs()){
			for(int i = 0;i<MAX_V;++i) now[i] = last[i];
			
			while(true){
				x = dfs(s,INT_MAX);
				if(x==0) break;
				f += x;
			}
		}
		
		return f;
	}
}G;
vector<int>o,e,ops,eps;
int primes[N],coun=0;
vector<int>adj[N],cyc[N];
int visit[N];
void dfs(int u,int p)
{
	if(visit[u])
		return ;
	visit[u]=1;
	cyc[coun].push_back(u);
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		dfs(adj[u][i],u);
	}
}
int main(){
	for(int i=2;i<N;i++)
	{
		if(!primes[i])
		for(int j=2*i;j<N;j+=i)
		{
			primes[j]++;
		}
	}
	int n,os=0,es=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		if(x&1)os++,o.push_back(x),ops.push_back(i+1);
		else es++,e.push_back(x),eps.push_back(i+1);
	}
	if(os!=es)
		cout<<"Impossible\n";
	else
	{
		flow_graph G(o.size()+e.size()+3,40000);
		int s=0;
		for(int i=0;i<o.size();i++)
		{
			G.add_edge(s,i+1,2,0);
		}
		for(int i=0;i<o.size();i++)
		{
			for(int j=0;j<e.size();j++)
			if(!primes[o[i]+e[j]])
			{
				G.add_edge(i+1,j+1+o.size(),1);
			}
		}
		for(int j=0;j<e.size();j++)
			{
				G.add_edge(j+1+o.size(),e.size()+1+o.size(),2);
			}
		int mf=G.max_flow(0,e.size()+1+o.size());
		if(mf!=2*os)
		cout<<"Impossible\n";
		else
		{
			for(int i=0;i<G.E;i+=2)
			{
				int u=G.to[i],v=G.to[i+1];
				swap(u,v);
				if(u>=1&&u<=o.size()&&v>=1+o.size()&&v<=e.size()+o.size())
				{
					if(!G.cap[i])
					{
						adj[ops[u-1]].push_back(eps[v-o.size()-1]);
						adj[eps[v-o.size()-1]].push_back(ops[u-1]);
						//cout<<ops[u-1]<<" "<<eps[v-o.size()-1]<<endl;
					}
				}
			}

			for(int i=1;i<=n;i++)
			if(!visit[i])
			{
				coun++;
				dfs(i,i);
			}
			cout<<coun<<endl;
			for(int i=1;i<=coun;i++)
			{
				cout<<cyc[i].size()<<" ";
				for(int j=0;j<cyc[i].size();j++)
					cout<<cyc[i][j]<<" ";
				cout<<endl;
			}
		}	
	}
	return 0;
}