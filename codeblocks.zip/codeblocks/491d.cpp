#include<iostream>
#define lli long long int
using namespace std;

int main()
{
  lli n;
  cin>>n;
  
  if(n%2==1)
     cout<<"black"<<endl;
     
     else
     {
        cout<<"white"<<endl;
        cout<<"1 2"<<endl;
        
        }
        return 0;
        }