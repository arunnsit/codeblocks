#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<map>
#include<vector>
#include<math.h>
#define N 100009
using namespace std;
int col[N];
long long int sol[N];
map<int,int>ma[N];
vector<int>adj[N];
long long int sum[N],mx[N];
void merge(int u,int v)
{
	if(ma[u].size()<ma[v].size())
	{
		sum[u]=sum[v];
		mx[u]=mx[v];
		swap(ma[u],ma[v]);
	}
	for(map<int,int>::iterator it=ma[v].begin();it!=ma[v].end();it++)
	{
		ma[u][it->first]+=it->second;
		if(ma[u][it->first]>mx[u])
		{
			mx[u]=ma[u][it->first];
			sum[u]=it->first;
		}
		else if(ma[u][it->first]==mx[u])
		{
			sum[u]+=it->first;
		}
	}

}
void dfs(int u,int p)
{
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		dfs(adj[u][i],u);
		merge(u,adj[u][i]);
	}
}
int main()
{
	int n,x,y;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>col[i];
		ma[i][col[i]]++;
		mx[i]=1;
		sum[i]=col[i];
	}
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	dfs(1,1);
	for(int i=1;i<=n;i++)
		cout<<sum[i]<<" ";
}