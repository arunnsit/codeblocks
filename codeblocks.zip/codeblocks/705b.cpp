#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<string>
#include<math.h>
#include<string.h>
using namespace std;
int main()
{
	long long int s=0,a,n;
	cin>>n;
	while(n--)
	{
		cin>>a;
		s+=a-1;
		if(s%2==0)
			cout<<2<<endl;
		else cout<<1<<endl;
	}
}