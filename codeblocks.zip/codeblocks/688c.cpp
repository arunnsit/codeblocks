#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include<string>
#define N 100008
#include<string.h>
using namespace std;
vector<int>adj[N];
int vis[N],color[N];
int ch=0;
void dfs(int u,int p,int c)
{
	color[u]=c;
	vis[u]=1;
	for(int i=0;i<adj[u].size();i++)
	{
		if(p==adj[u][i])
			continue;
		if(vis[adj[u][i]]&&color[adj[u][i]]!=(c^1))
		{
			ch=1;
		}
		if(!vis[adj[u][i]])
		dfs(adj[u][i],u,c^1);
	}
}
vector<int>vet[4];
int main()
{
	int n,m,x,y;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
	if(!vis[i])
	dfs(i,0,2);
	if(ch)
	{
		cout<<-1<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		vet[color[i]].push_back(i);
	}
	cout<<vet[2].size()<<endl;
	for(int i=0;i<vet[2].size();i++)
		cout<<vet[2][i]<<" ";
	cout<<endl;

	cout<<vet[3].size()<<endl;
	for(int i=0;i<vet[3].size();i++)
		cout<<vet[3][i]<<" ";
	cout<<endl;

}