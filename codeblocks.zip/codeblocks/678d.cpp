#include<iostream>
using namespace std;
long long int mod=1000000007;
int c=0;
long long int pow_bhaji(long long int x,long long int y)
{
	long long int w;
	if(y==0)
		return 1;
	if(y&1)
		{
			w=pow_bhaji(x,(y-1)/2)%mod;
			return (((x*w)%mod)*w)%mod;
		}
	else 
		{
			w=pow_bhaji(x,(y)/2)%mod;
			return (w*w)%mod;
		}
}
int main()
{
	long long int a,b,n,x,inverse,gp,apower;
	cin>>a>>b>>n>>x;
	if(a==1)
	{
		cout<<(x+(b*(n%mod))%mod)%mod<<endl;
	}
	else
	{
		inverse=pow_bhaji(a-1,mod-2);
		apower=pow_bhaji(a,n);
		gp=(apower-1+mod)%mod;
		gp=(gp*inverse)%mod;
		cout<<((apower*x)%mod+(gp*b)%mod)%mod;
	}
}