#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
struct node
{
	int x,y;
};
bool cmp(node a,node b)
{
	return a.x<b.x;
}
bool cmp2(node a,node b)
{
	return a.y<b.y;
}
node a[300000];
map<pair<int,int>,int> ma;
int main(){
	int n;
	cin>>n;
	long long int eq=0;
	for(int i=0;i<n;i++)
	{
		cin>>a[i].x>>a[i].y;
		eq+=ma[make_pair(a[i].x,a[i].y)];
			ma[make_pair(a[i].x,a[i].y)]++;
	}
	sort(a,a+n,cmp);
	long long int sol1=0,sol2=0,sol=0,tmp=1;
	for(int i=0;i<n-1;i++)
	{
		if(a[i].x==a[i+1].x)
		{
			tmp++;
		}
		else
		{
			sol1+=((tmp)*(tmp-1))/2;
			tmp=1;
		}
	}
	//cout<<sol1<<endl;
	sol1+=((tmp)*(tmp-1))/2;
	sort(a,a+n,cmp2);
	tmp=1;
	for(int i=0;i<n-1;i++)
	{
		if(a[i].y==a[i+1].y)
		{
			tmp++;
		}
		else
		{
			sol1+=((tmp)*(tmp-1))/2;
			tmp=1;
		}
	}
	//cout<<sol1<<endl;
	sol1+=((tmp)*(tmp-1))/2;
	cout<<sol1-eq<<endl;
}
