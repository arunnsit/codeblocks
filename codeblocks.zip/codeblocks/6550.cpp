#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
	string a,b,c,d,e,f;
	cin>>a>>b>>c>>d;
	for(int i=0;i<a.size();i++)
	{
		if(a[i]!='X')
			e.push_back(a[i]);
	}
	for(int i=b.size()-1;i>=0;i--)
	{
		if(b[i]!='X')
			e.push_back(b[i]);
	}
	for(int i=0;i<c.size();i++)
	{
		if(c[i]!='X')
			f.push_back(c[i]);
	}
	for(int i=d.size()-1;i>=0;i--)
	{
		if(d[i]!='X')
			f.push_back(d[i]);
	}
	f+=f;
	int ch=0;
	for(int i=0;i<f.size();i++)
	{
		int j=0;
		for(j=0;j<e.size();j++)
		if(i+j<f.size()&&e[j]==f[i+j]){
		}
		else break;
		if(j==e.size())
			ch=1;
	}
	if(ch)
		cout<<"YES\n";
	else cout<<"NO\n";
}