#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<math.h>
#include<string>
#include<string.h>
#define N 100008
using namespace std;
char a[1000][1000];
int main()
{
	int n,x,y,d,coun=0,ch=0,days=0;
	cin>>n>>d;
	for(int i=0;i<d;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<d;i++)
	{
		ch=0;
		for(int j=0;j<n;j++)
		{
			if(a[i][j]=='0')
			{
				ch=1;
			}
		}
		if(ch)
		{
			coun++;
		}
		else
		{
			days=max(coun,days);
			coun=0;
		}
	}
	days=max(coun,days);
	cout<<days<<endl;
}