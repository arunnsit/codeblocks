#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
long long int sum[5008],consum[5003];
int main()
{
	std::ios::sync_with_stdio(false);
	int n,a[3000];
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	sort(a,a+n);
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			sum[a[j]-a[i]]++;
		}
	}
	consum[0]=0;
	for(int i=5001;i>=0;i--)
		consum[i]=consum[i+1]+sum[i];
	long long int sol=0;
	for(int i=0;i<=5001;i++)
	{
		for(int j=0;j<=5001-i;j++)
		if(sum[i]&&sum[j]&&consum[j+i+1])
		{
			sol+=sum[j]*sum[i]*consum[j+i+1];
			//cout<<i<<" "<<j<<" "<<sol<<endl;
		}
	}
	double power=(n*(n-1))/2;
    double fsol=sol/power;
    fsol/=power;
    fsol/=power; 
	cout<<fixed;
	cout<<setprecision(10)<<fsol<<endl;
}