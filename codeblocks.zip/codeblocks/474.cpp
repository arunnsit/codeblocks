#include<algorithm>
#include<iostream>
#include<set>
#include<
int bit[1000009][2]={0};

int main()
{

}