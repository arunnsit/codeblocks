#include<iostream>
#include<algorithm>
#include<set>
#include<math.h>
#include<vector>
#include<string>
#include<string.h>
using namespace std;
int main()
{
	string a;
	int c;
	cin>>c>>a;
	if(c==12)
	{
		if(a[3]>='0'&&a[3]<='5')
		{

		}
		else a[3]='1';
		if((a[0]-'0')*10+a[1]-'0'>12&&a[1]=='0')
		{
			a[0]='1';
		}
		else if((a[0]-'0')*10+a[1]-'0'>12&&a[1]!='0')
		{
			a[0]='0';
		}
		else if(a[0]=='0'&&a[1]=='0')
		{
			a[1]='1';
		}
		cout<<a<<endl;
	}
	else
	{
		if(a[3]>='0'&&a[3]<='5')
		{

		}
		else a[3]='1';
		if((a[0]-'0')*10+a[1]-'0'>23)
		{
			a[0]='0';
		}
		cout<<a<<endl;
	}
}