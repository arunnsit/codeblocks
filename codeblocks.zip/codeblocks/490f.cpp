#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#define N 6009
using namespace std;
vector<int>adj[N];
int val[N];
int value=0;
int len[N];
vector<int>s;
void dfs(int u,int p)
{
	value=max(value,(int)s.size());
	for(int i=0;i<adj[u].size();i++)
	{
		if(adj[u][i]==p)
		continue;	
		int va=-1,x;
		if(val[adj[u][i]]>s.back())
		{
			s.push_back(val[adj[u][i]]);
		}
		else
		{
			x=lower_bound(s.begin(),s.end(),val[adj[u][i]])-s.begin();
			va=s[x];
			s[x]=val[adj[u][i]];
		}
		dfs(adj[u][i],u);
		if(va==-1)
		{
			s.pop_back();
		} 
		else
		{
			s[x]=va;
		}
	}
}
int main()
{
	int n,x,y;
	cin>>n;
	val[0]=-1;
	for(int i=1;i<=n;i++)
	{
		cin>>val[i];
	}
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	for(int i=1;i<=n;i++)
	{
		 s.clear();
		 s.push_back(val[i]);
		 dfs(i,-1);
	}
	cout<<value<<endl;
}