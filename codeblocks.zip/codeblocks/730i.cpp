#include<iostream>
#include<algorithm>
#include<vector>
#include<string.h>
#define NMAX 3008
using namespace std;
vector<pair<pair<int,int>,int> >v;
vector<int>a,b;
int N,P,S,x,y,dp1[NMAX][NMAX],dp2[NMAX][NMAX];
int solve2(int n,int s)
{
	if(s==-1)
		return -5000000;
	if(n==-1&&s!=0)
	return -5000000;
	if(n==-1)
		return 0;
	if(dp2[n][s]!=-1)
		return dp2[n][s];
	if(s==0)
	{
		return dp2[n][s]=v[n].first.first+solve2(n-1,s);
	}
	else return dp2[n][s]=max(v[n].first.first+solve2(n-1,s),v[n].first.second+solve2(n-1,s-1));
}
int solve(int n,int s)
{
	if(s==-1)
		return -5000000;
	if(n==-1&&s!=0)
	return -5000000;
	if(n==-1)
		return 0;
	if(dp1[n][s]!=-1)
		return dp1[n][s];
	if(P+s==n+1)
	{
		return dp1[n][s]=solve2(n,s);
	}
	else
	{
		return dp1[n][s]=max(solve(n-1,s-1)+v[n].first.second,solve(n-1,s));
	}
}
vector<int>pros,sport;
void tester(int n,int s,int p)
{
	//cout<<".."<<n<<" "<<s<<" "<<p<<endl;
	if(n==-1)
		return ;
	if(p+s==n+1)
	{
		if(s==0)
		{
			//cout<<"here:\n";
			pros.push_back(v[n].second);
			tester(n-1,s,p-1);
		}
		else
		{
			if(v[n].first.first+solve2(n-1,s)>v[n].first.second+solve2(n-1,s-1))
			{
				pros.push_back(v[n].second);
				tester(n-1,s,p-1);
			}
			else 
			{
				sport.push_back(v[n].second);
				tester(n-1,s-1,p);
			}
		}
	}
	else
	{
		if(solve(n-1,s-1)+v[n].first.second>solve(n-1,s))
		{
			sport.push_back(v[n].second);
			tester(n-1,s-1,p);
		}
		else
		{
			tester(n-1,s,p);
		}
	}
}
int main()
{
	cin>>N>>P>>S;
	for(int i=0;i<N;i++)
	{
		cin>>x;
		a.push_back(x);
	}
	for(int i=0;i<N;i++)
	{
		cin>>x;
		b.push_back(x);
	}
	for(int i=0;i<N;i++)
	{
		v.push_back(make_pair(make_pair(a[i],b[i]),i+1));
	}
	sort(v.begin(),v.end());
	reverse(v.begin(),v.end());
	memset(dp1,-1,sizeof(dp1));
	memset(dp2,-1,sizeof(dp2));
	cout<<solve(N-1,S)<<endl;
	tester(N-1,S,P);
	for(int i=0;i<pros.size();i++)
		cout<<pros[i]<<" ";
	cout<<endl;
	for(int i=0;i<sport.size();i++)
		cout<<sport[i]<<" ";
	cout<<endl;
}