#include<iostream>
using namespace std;
int main()
{
	long long int n,x=0;
	cin>>n;

	while(n-x-1>0)
	{
		x++;
		n-=x;
	}
	cout<<n<<endl;
}