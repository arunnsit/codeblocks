#include<iostream>
#include<map>
#include<vector>
#include<algorithm>
#include<string>
#include<string.h>
using namespace std;
vector<int>v;
int loner=0,calls=0;
int dp[1002][(1<<8)-1][8]={0};
int cur_solve(int n,int mask,int cor)
{
	calls++;
	//cout<<n<<" "<<mask<<" "<<cor<<" ..\n";
	if(n<=0||mask==0)
		return dp[n][mask][cor]=-100000;
	if(dp[n][mask][cor]!=-1)
		return dp[n][mask][cor];
	int idx1=-1,idx2=-1,cur=0;
	if(loner==0)
		idx1=n;
	for(int i=n;i>=1;i--)
	{
		if(v[i]==cor+1)
		{
			cur++;
			if(cur==loner+1)
			{
				idx2=i-1;
				break;
			}
			if(cur==loner)
			{
				idx1=i-1;
			}
		}
	}
	mask^=(1<<(cor));
	if(mask==0)
	{
		if(idx2!=-1)
			return dp[n][mask][cor]=1;
		else if(idx1!=-1)
			return dp[n][mask][cor]=0;
		else return dp[n][mask][cor]=-100000;
	}
	int momo=-100000;
	for(int i=0;i<8;i++)
	if((mask>>i)&1)
	{
		if(idx1!=-1)
		momo=max(cur_solve(idx1,mask,i),momo);
		if(idx2!=-1)
		momo=max(cur_solve(idx2,mask,i)+1,momo);
	}
	return dp[n][mask][cor]=momo;
}
int solve(int n)
{
	int momo=-1000000;
	memset(dp,-1,sizeof(dp));
	for(int i=0;i<8;i++)
	{
		momo=max(momo,cur_solve(n,((1<<8)-1),i));
	}
	return momo;
}
int main()
{
	int n;
	v.push_back(0);
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		v.push_back(x);
	}
	int l=0,r=1000,mid,fsol=0;
	while(l<=r)
	{
		int mid=(l+r)/2,sol;
		loner=mid;
		sol=solve(n);
		cout<<"mid:"<<mid<<" "<<sol<<" "<<calls<<endl;
		if(sol>=0)
		{
			fsol=max(fsol,8*mid+sol);
			l=mid+1;
		}
		else r=mid-1;
	}
	cout<<fsol<<endl;
}