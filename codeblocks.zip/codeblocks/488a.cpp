#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int check(int n)
{
	int x=0;
	n=abs(n);
	while(n!=1&&n!=0)
	{
		if(n%10==8)
			x=1;
		n/=10;
	}
	return x;
}
int main()
{
	int n,x,y;
	cin>>n;
	y=n;
	while(!check(++n))
	{

	}
	cout<<n-y<<endl;
}