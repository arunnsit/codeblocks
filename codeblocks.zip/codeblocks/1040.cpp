#include<iostream>
#include<algorithm>
#include<math.h>
#include<vector>
#define N 60
using namespace std;
vector<int>adj[N],num[N*N];
int vis[N]={0},vis2[N]={0},sol[N*N]={0};
int timer=0;
int gcd(int x,int y)
{if (y==0){return x;}else return gcd(y,x%y);}
void dfs(int u,int p)
{
	vis[u]++;
	for(int i=0;i<adj[u].size();i++)
	{
		if(!sol[num[u][i]])
		sol[num[u][i]]=++timer;
		if(!vis[adj[u][i]]){
		dfs(adj[u][i],u);
	}
    }
}
int degree[N]={0},ch=-1;
void dfs2(int u,int p)
{
	vis2[u]++;
	int x=0;
	for(int i=0;i<adj[u].size();i++)
	{
	 	if(adj[u].size()!=1)
	 	{
	 		if(x==0)
	 		{
	 			x=sol[num[u][i]];
	 		}
	 		else 
	 		{
	 			x=gcd(x,sol[num[u][i]]);
	 		}

	 	}
	 	if(!vis2[adj[u][i]]&&(adj[u][i]!=p))
		{
			dfs2(adj[u][i],u);
	 	}
	}
	//cout<<u<<".. "<<x<<endl;
	if(x!=0&&x!=1)
	{
	//	cout<<u<<" "<<endl;
		ch=1;
	}
}
int main()
{
	int n,x,y,m;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		num[x].push_back(i+1);
		num[y].push_back(i+1);
		degree[x]++;
		degree[y]++;
	}
	for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			dfs(i,0);	
		}
	for(int i=1;i<=n;i++)
	if(!vis2[i]){
		dfs2(i,0);
	}	
	if(ch==-1)
	{
	cout<<"YES\n";	
	for(int i=1;i<=m;i++)
		cout<<sol[i]<<" ";
		cout<<endl;
	}
	else cout<<"NO\n"<<endl;
}