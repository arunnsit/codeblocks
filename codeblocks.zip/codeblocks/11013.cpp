#include<stdio.h>
int main(){
	char a[5][5],c[]={A,2,3,4,5,6,7,8,9,T,J,Q,K,A,2,3,4,5,6,7,8,9,T,J,Q,K};
    int b[200],i;
    for(i=0;i<13;i++){
    	b[c[i]]=i+1;
    }
	scanf("%s %s %s %s %s",a[0],a[1],a[2],a[3],a[4]);
	while(a[0][0]!='#')


}