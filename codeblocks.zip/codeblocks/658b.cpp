#include<iostream>
#include<set>
#include<stdio.h>
#include<vector>
using namespace std;
struct lex_compare {
    bool operator() (const int a, const int b) const{
        return a > b;
    }
};
set<int,lex_compare>s;
int arr[200000];
vector<int> vec;
int check(int x,int k)
{
	int check=0,p;
	while(!s.empty()&&k)
	{
		p=(*s.begin());
		vec.push_back(p);
		if(p==arr[x])
			check=1;
		s.erase(s.begin());
		k--;
	}
	for(int i=0;i<vec.size();i++)
		s.insert(vec[i]);
	vec.clear();
	return check;

}
int main()
{
	int n,k,q,ty,x;
	scanf("%d %d %d",&n,&k,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&arr[i]);

	while(q--)
	{
		scanf("%d %d",&ty,&x);
		if(ty==1)
		{
			s.insert(arr[x]);
			//cout<<"front:"<<(*s.begin())<<endl;
		}
		else
		{
			if(check(x,k))
				cout<<"YES\n";
			else cout<<"NO\n";
		}
	}

}