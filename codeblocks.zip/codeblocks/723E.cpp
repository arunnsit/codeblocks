#include<map>
#include<vector>
#include<algorithm>
#include<iostream>
#define N 300009
using namespace std;
map<pair<int,int>,bool>deleted,niggs;
map<pair<int,int>,int>freq;
vector<int>eu,adj[N],tmp;
void euler(int v)
{
	while(!adj[v].empty())
	{
		int u=adj[v].back();
		adj[v].pop_back();
		if(!deleted[make_pair(v,u)])
		{
			freq[make_pair(v,u)]--;
			freq[make_pair(u,v)]--;
			if(freq[make_pair(v,u)]==0)
			deleted[make_pair(v,u)]=deleted[make_pair(u,v)]=true;
			euler(u);
		}
	}
	eu.push_back(v);
}
int deg[N],vis[N];
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,m;
		deleted.clear();
		niggs.clear();
		tmp.clear();
		freq.clear();
		cin>>n>>m;
		eu.clear();
		for(int i=1;i<=n;i++)
		{
			vis[i]=0;
			deg[i]=0;
			adj[i].clear();
		}
		for(int i=0;i<m;i++)
		{
			int x,y;
			cin>>x>>y;
			adj[x].push_back(y);
			adj[y].push_back(x);
			freq[make_pair(x,y)]++;
			freq[make_pair(y,x)]++;
			deg[x]++;
			deg[y]++;
		}
		int aol=n;
		for(int i=1;i<=n;i++)
		{
			if(deg[i]&1)
			{
				aol--;
				tmp.push_back(i);
			}
		}
		for(int i=1;i<tmp.size();i+=2)
		{
			adj[tmp[i]].push_back(tmp[i-1]);
			adj[tmp[i-1]].push_back(tmp[i]);
			deg[tmp[i]]++;
			deg[tmp[i-1]]++;
			niggs[make_pair(tmp[i],tmp[i-1])]=1;
			niggs[make_pair(tmp[i-1],tmp[i])]=1;
			freq[make_pair(tmp[i],tmp[i-1])]++;
			freq[make_pair(tmp[i-1],tmp[i])]++;
			//cout<<"addding:"<<tmp[i]<<" "<<tmp[i-1]<<endl;
		}
		cout<<aol<<endl;
		for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			euler(i);

			//cout<<eu.size()<<".."<<tmp.size()<<" "<<eu[0]<<endl;
			vis[eu[0]]++;
			for(int i=1;i<eu.size();i++)
			{
				if(!niggs[make_pair(eu[i],eu[i-1])])
				{
					cout<<eu[i]<<" "<<eu[i-1]<<endl;
				}
				else niggs[make_pair(eu[i],eu[i-1])]=0,niggs[make_pair(eu[i-1],eu[i])]=0;
				vis[eu[i]]++;
			}
			eu.clear();
		}
	}
}