#include<iostream>
#include<vector>
#include<set>
using namespace std;
vector<int>v[200009];
vector<long long int>w[200009];
int level[200009]={0},P[200009],jumper[200009],disc[200009],timer=0;
long long int value[200009];
set<int>lamda[200009];
int upda(int x,int y)
{
	return level[x]>level[y]?x:y;
}
void dfs(int u,int p,int nonzero)
{
	disc[u]=++timer;
	for(int i=0;i<v[u].size();i++)
	if(v[u][i]!=p){
		level[v[u][i]]=level[u]+1;
		P[v[u][i]]=u;
		lamda[nonzero].insert(v[u][i]);
		jumper[v[u][i]]=nonzero;
		value[v[u][i]]=w[u][i];
		//cout<<v[u][i]<<" "<<value[v[u][i]]<<endl;
		dfs(v[u][i],u,w[u][i]==1?nonzero:v[u][i]);
	}
}
long long int query(int x,int y,long long int u)
{
	if(disc[x]>disc[y])
	{
		swap(x,y);
	}
	while(disc[y]>disc[x]&&u)
	{
		u/=value[y];
		//cout<<"1:"<<value[y]<<" "<<y<<endl;
		y=jumper[y];
	}
	while(disc[x]>disc[y]&&u)
	{
		u/=value[x];
		//cout<<"2:"<<value[x]<<" "<<x<<endl;
		x=jumper[x];
	}
	return u;
}
vector<pair<int,int> >eds;
void update(int u,long long int y)
{
	int x=upda(eds[u].first,eds[u].second),o;
	//cout<<"up:"<<x<<endl;
	o=jumper[x];
	if(y==value[x]||(y!=1&&value[x]!=1))
	{
		value[x]=y;
	}
	else
	{
		if(value[x]==1)
		{
			for(set<int>::iterator it=lamda[o].begin();it!=lamda[o].end();it++)
			{
				if(disc[*it]>disc[x])
				{
					lamda[x].insert(*it);
					jumper[*it]=x;
				}
			}
			for(set<int>::iterator it=lamda[x].begin();it!=lamda[x].end();it++)
			{
				lamda[o].erase(lamda[x].find(*it));
			}
		}
		else
		{
			for(set<int>::iterator it=lamda[x].begin();it!=lamda[x].end();it++)
			{
				lamda[o].insert(*it);
				jumper[*it]=o;
			}
			lamda[x].clear();
		}
		value[x]=y;
	}
}
int main()
{
	value[0]=1;
	value[1]=1;
	int n,x,y,q;
	long long int z;
	cin>>n>>q;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y>>z;
		v[x].push_back(y);
		v[y].push_back(x);
		w[x].push_back(z);
		w[y].push_back(z);
		eds.push_back(make_pair(x,y));
	}
	dfs(1,0,0);
	int type;
	while(q--)
	{
		cin>>type;
		if(type&1)
		{
			cin>>x>>y>>z;
			cout<<query(x,y,z)<<endl;
		}
		else
		{
			cin>>x>>z;
			update(x-1,z);
		}
	}
}