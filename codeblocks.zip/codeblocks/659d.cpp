#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<pair<int,int > >v;
int check(int x)
{
	pair<int,int>prev,curr,next;
	prev=v[x-1];
    curr=v[x];
    next=v[x+1];

    if(prev.first==curr.first&&prev.second>curr.second)
    {
    	if(next.first>curr.first)
    	{
    		return 1;
    	}
    	else return 0;
    }
    else if(prev.first==curr.first&&prev.second<curr.second)
    {
    	if(next.first<curr.first)
    	{
    		return 1;
    	}
    	else return 0;
    }
    else if(prev.second==curr.second&& prev.first>curr.first)
    {
    	if(next.second<curr.second)
    	{
    		return 1;
    	}
    	else return 0;
    }
    else if(prev.second==curr.second&& prev.first<curr.first)
    {
    	if(next.second>curr.second)
    	{
    		return 1;
    	}
    	else return 0;
    }
    return 0;
}
int main()
{
	int n,x,y;
	cin>>n;
	for(int i=0;i<n+1;i++)
	{
		cin>>x>>y;
		v.push_back(make_pair(x,y));
	}
	int coun=0;
	for(int i=1;i<n;i++)
	{
		if(check(i))
		{
			coun++;
		}
	}
	cout<<coun<<endl;
}