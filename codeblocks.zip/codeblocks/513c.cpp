#include<iostream>
#include<map>
#include<vector>
#include<algorithm>
#include<iomanip>
using namespace std;
vector<pair<int,int> >v;
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		v.push_back(make_pair(x,y));
	}
	double sol=0,l,pro;
	for(int i=0;i<=10000;i++)
	{
		for(int j=0;j<(1<<n);j++)
		{
			for(int k=0;k<(1<<n);k++)
			{
				if((j&k)==0)
				{
					l=((1<<n)-1)^(j|k);
					pro=1;
					for(int u=0;u<n;u++)
					{
						if((j>>u)&1)
						{
							if(i>=v[u].second)
							{
								pro=0;
							}
							else if(i>=v[u].first&&i<=v[u].second)
							{
								pro*=((double)(v[u].second-i))/((double)(v[u].second-v[u].first+1));
							}
							//if(i==2)
							//	cout<<pro<<" 1"<<endl;
						}
						else if((k>>u)&1)
						{
							if(i<=v[u].first)
							{
								pro=0;
							}
							else if(i>v[u].first&&i<=v[u].second)
							{
								pro*=((double)(i-v[u].first))/((double)(v[u].second-v[u].first+1));
							}
							//if(i==2)
							//	cout<<pro<<" 2"<<endl;
						}
						else
						{
							if(i>=v[u].first&&i<=v[u].second)
							{
								pro*=((double)(1.0))/((double)(v[u].second-v[u].first+1));
							}
							else pro=0;
							//if(i==2)
							//	cout<<pro<<" 3"<<endl;
						}
					}
					if((__builtin_popcount(j)==1&&__builtin_popcount(l)>=1&&pro>0)||(__builtin_popcount(j)==0&&__builtin_popcount(l)>=2&&pro>0))
					{
						//cout<<i<<" "<<pro<<" "<<j<<" "<<k<<" "<<l<<endl;
						sol+=(pro*1.0*i);
					}
				}
			}
		}
	}
	cout<<fixed<<setprecision(11)<<sol<<endl;
}