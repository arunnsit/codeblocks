#include<iostream>
#include<algorithm>
#include<set>
#include<stdio.h>
#include<vector>
#include<math.h>
#include<string>
using namespace std;
pair<int,int> arr[15];
vector <pair<int,int> >v;
int mark[5][5];
int main()
{
	int n;
	cin>>n;
	arr[0]=make_pair(4,2);
	arr[1]=make_pair(1,1);
	arr[2]=make_pair(1,2);
	arr[3]=make_pair(1,3);
	arr[4]=make_pair(2,1);
	arr[5]=make_pair(2,2);
	arr[6]=make_pair(2,3);
	arr[7]=make_pair(3,1);
	arr[8]=make_pair(3,2);
	arr[9]=make_pair(3,3);
	string a;
	cin>>a;
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
			mark[i][j]=1;
		mark[4][2]=1;
	for(int i=1;i<a.length();i++)
	{
		v.push_back(make_pair(arr[a[i]-'0'].first-arr[a[i-1]-'0'].first,arr[a[i]-'0'].second-arr[a[i-1]-'0'].second));
	}
	int check=0,dx,dy;
	for(int i=1;i<=4;i++)
	{
		for(int j=1;j<=3;j++)
		if(mark[i][j]){
			dx=i;
			dy=j;
			int k=0;
			//cout<<"stat:"<<" "<<dx<<" "<<dy<<endl;
			for(k=0;k<v.size();k++)
			{
				dx+=v[k].first;
				dy+=v[k].second;
				//cout<<dx<<" "<<dy<<" "<<v[k].first<<" "<<v[k].second<<endl;
				if(dy>=1&&dy<=3&&dx>=1&&dx<=4&&mark[dx][dy])
				{

				}
				else break;

			}
			if(k==v.size())
				check++;
		}
	}
	//cout<<check<<endl;
	if(check==1)
		cout<<"YES\n";
	else cout<<"NO\n";
}