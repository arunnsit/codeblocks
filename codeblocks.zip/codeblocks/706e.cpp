#include<iostream>
#include<algorithm>
using namespace std;
int a[1025][1024],b[33][33];
int main()
{
	for(int i=1;i<=32;i++)
		for(int j=1;j<=32;j++)
		{
			b[i][j]=(i-1)*32+j;
		}
	int n,m,q,x1,y1,x2,y2,h,w;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	}
	while(q--)
	{

	}
}