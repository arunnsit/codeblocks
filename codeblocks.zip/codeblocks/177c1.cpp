#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>
#define N 2000
using namespace std;
vector<int> adj[N];
int pa[N];
void create_set(int x)
{
	if(pa[x])
		return ;
	else
	{
		pa[x]=x;
	}
}
int parent(int x)
{
	if(pa[x]==x)
		return x;
	return parent(pa[x]);
}
void merge(int x,int y)
{
	int u=parent(x);
	int v=parent(y);
	if(u>v)
	{
		pa[u]=v;
	}
	else
	{
		pa[v]=u;
	}
}
int mark[N],vis[N];
int dfs(int u ,int p)
{
	vis[u]=1;
	int x=0;
	if(mark[u])
		x=-50000;
	for(int i=0;i<adj[u].size();i++)
	{
		if(!vis[adj[u][i]]&&u!=p)
		{
			x+=dfs(adj[u][i],u);
		}
	}
	return x+1;
}
int main()
{
	int n,k,m,x,y;
	cin>>n;
	cin>>k;
	while(k--)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		create_set(x);
		create_set(y);
		merge(x,y);
	}
	cin>>m;
	while(m--)
	{
		cin>>x>>y;
		if(parent(x)==parent(y))
		{
			mark[parent(x)]=1;
		}
	}
	int sol=0;
	for(int i=1;i<=n;i++)
	{
		if(!mark[i]&&!vis[i])
		{
			sol=max(sol,dfs(i,-1));
		}
	
	}
		cout<<sol<<endl;


}