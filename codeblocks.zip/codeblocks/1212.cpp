#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
using namespace std;
vector<int>row[30009],col[30009];
int main()
{
	int n,m,l,x,y,len,x1,y1;
	string a;
	cin>>n>>m>>l;
	while(l--)
	{
		cin>>y>>x>>len>>a;
		if(a[0]=='V')
		{
			y1=y;
			x1=x+len-1;
			x=max(1,x-1);
			y=max(1,y-1);
			x1=min(x1+1,n);
			y1=min(y1+1,m);
		//	cout<<".... "<<x<<" "<<y<<" | "<<x1<<" "<<y1<<endl;
			for(int i=x;i<=x1;i++)
			{
				for(int j=y;j<=y1;j++)
				col[i].push_back(j);
			}
			for(int i=y;i<=y1;i++)
			{
				for(int j=x;j<=x1;j++)
				row[i].push_back(j);
			}
		}
		else
		{
			y1=y+len-1;
			x1=x;
			x=max(1,x-1);
			y=max(1,y-1);
			x1=min(x1+1,n);
			y1=min(y1+1,m);
			//cout<<".... "<<x<<" "<<y<<" | "<<x1<<" "<<y1<<endl;
			for(int i=x;i<=x1;i++)
			{
				for(int j=y;j<=y1;j++)
				col[i].push_back(j);
			}
			for(int i=y;i<=y1;i++)
			{
				for(int j=x;j<=x1;j++)
				row[i].push_back(j);
			}
		}
	}
	for(int i=1;i<=n;i++)
		{
			col[i].push_back(0);
			col[i].push_back(m+1);
			sort(col[i].begin(),col[i].end());
		}
	for(int i=1;i<=m;i++)
		{
			row[i].push_back(0);
			row[i].push_back(n+1);
			sort(row[i].begin(),row[i].end());
		}
	int coun=0;
	int k;
	cin>>k;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<col[i].size()-1;j++)
		{
			coun+=max(0,col[i][j+1]-col[i][j]-k);
			//cout<<"width: "<<i<<" : "<<col[i][j]<<" "<<col[i][j+1]<<endl;	
		}
	}
	for(int i=1;i<=m;i++)
	{
		for(int j=0;j<row[i].size()-1;j++)
		{
			coun+=max(0,row[i][j+1]-row[i][j]-k);
		   // cout<<"width: "<<i<<" : "<<row[i][j]<<" "<<row[i][j+1]<<endl;	
		}
	}
	if(k==1)cout<<coun/2<<endl;
	else cout<<coun<<endl;

}