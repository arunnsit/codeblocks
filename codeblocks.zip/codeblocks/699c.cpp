#include<iostream>
#include<algorithm>
#include<string.h>
using namespace std;
int a[200];
int dp[200][3];
int solve(int n,int p)
{
	if(n==-1)
		return 0;
	if(dp[n][p]!=-1)
		return dp[n][p];
	if(a[n]==0)
	{
		return dp[n][p]=solve(n-1,0)+1;
	}
	else if(a[n]==1)
	{ 
		if(p==0)
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,1));
		}
		else if(p==1)
		{
			return dp[n][p]=solve(n-1,0)+1;
		}
		else
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,1));
		}
	}
	else if(a[n]==2)
	{
		if(p==0)
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,2));
		}
		else if(p==1)
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,2));
		}
		else
		{
			return dp[n][p]=solve(n-1,0)+1;
		}
	}
	else
	{
		if(p==0)
		{
			return dp[n][p]=min(solve(n-1,0)+1,min(solve(n-1,2),solve(n-1,1)));
		}
		else if(p==1)
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,2));
		}
		else
		{
			return dp[n][p]=min(solve(n-1,0)+1,solve(n-1,1));
		}
	}
}
int main()
{
	int n;
	cin>>n;
	memset(dp,-1,sizeof(dp));
	for(int i=0;i<n;i++)
		cin>>a[i];
	cout<<solve(n-1,0)<<endl;
}