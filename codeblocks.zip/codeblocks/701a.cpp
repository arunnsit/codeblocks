#include<iostream>
#include<vector>
#include<set>
#include<algorithm>
#include<map>
using namespace std;
int arr[1000];
vector<int> ma[1000];
int main()
{
	int n;
	cin>>n;
	long long int s=0;
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
		s+=arr[i];
		ma[arr[i]].push_back(i+1);
	}
	s=(s*2)/n;
	//cout<<".."<<s<<endl;
	for(int i=1;i<=100;i++)
	{
		while(ma[i].size())
		{
			cout<<ma[i].back();
			ma[i].pop_back();
			cout<<" "<<ma[s-i].back()<<endl;
			ma[s-i].pop_back();
		}
	}
}