#include<iostream>
using namespace std;
int main()
{
	double a,b,c,d,r;
	cin>>a>>b>>c>>d;1
    r=(1-a/b)*(1-c/d);
    cout<<fixed;
    cout<<a/(b-b*r)<<endl;

}