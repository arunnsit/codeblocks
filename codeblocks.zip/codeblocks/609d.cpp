#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<vector>
using namespace std;
struct node
{
	int x,nos;
};
bool cmp(node a,node b)
{
	return a.x<b.x;
}
vector<node>gad[3];
node a[200009]={0},acon[200009],b[200009],bcon[200009];

int main()
{
	int n,m,k,x,y;
	double s;
	cin>>n>>m>>k>>s;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].x;
		a[i].nos=i;
		if(i==1)
			acon[i]=a[i];
		else
		{
			if(acon[i-1].x>a[i].x)
			{
				acon[i]=a[i];
			}
			else acon[i]=acon[i-1];
		}
	}
	for(int i=1;i<=n;i++)
	{
		cin>>b[i].x;
		b[i].nos=i;
		if(i==1)
			bcon[i]=b[i];
		else
		{
			if(bcon[i-1].x>b[i].x)
			{
				bcon[i]=b[i];
			}
			else bcon[i]=bcon[i-1];
		}
	}
	node tmp;
	for(int i=1;i<=m;i++)
	{
		cin>>x>>tmp.x;
		tmp.nos=i;
		gad[x].push_back(tmp);
	}
	sort(gad[2].begin(),gad[2].end(),cmp);
	sort(gad[1].begin(),gad[1].end(),cmp);
	int l=0,r=n+1,mid,boun=0,X,Y;
	long long int ts=0,sol=0;

	while(1)
	{
		mid=l+(r-l)/2;
		x=0;
		y=0;
		ts=0;
		boun=0;
		//cout<<"bhey"<<endl;
		while(1&&mid!=0)
		{
			//cout<<"hey"<<endl;
			boun++;
			if(y!=gad[2].size()&&(x==gad[1].size()||(gad[1][x].x*acon[mid].x>gad[2][y].x*bcon[mid].x)))
			{
				ts+=1LL*gad[2][y].x*bcon[mid].x;
				y++;
			}
			else 
				{ts+=1LL*gad[1][x].x*acon[mid].x;x++;}
			if(boun==k)
				break;
		}
		//cout<<l<<" "<<r<<" "<<ts<<endl;

		if(ts<=s&&mid!=0)
		{
			r=mid-1;
			sol=mid;
			X=x;
			Y=y;
		}
		else 
		{
			l=mid+1;
		}
		if(l>r)break;
	}
	if(sol==0||sol>n)
	{
		cout<<-1<<endl;
		return 0;
	}
cout<<sol<<endl;
for(int i=0;i<X;i++)
	cout<<gad[1][i].nos<<" "<<acon[sol].nos<<endl;
for(int i=0;i<Y;i++)
	cout<<gad[2][i].nos<<" "<<bcon[sol].nos<<endl;

}