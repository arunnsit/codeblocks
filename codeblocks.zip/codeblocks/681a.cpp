#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<string.h>
using namespace std;
vector<char [2]>v;
int main()
{



}