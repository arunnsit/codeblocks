#include<iostream>
#include<string>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
using namespace std;
string a;
int main()
{
	cin>>a;
	int sol=0,cr=0,x;
	for(int i=0;i<a.size();i++)
	{
		x=a[i]-'a';
		sol+=min((x-cr+26)%26,(cr-x+26)%26);
		cr=x;
	}
	cout<<sol<<endl;
}