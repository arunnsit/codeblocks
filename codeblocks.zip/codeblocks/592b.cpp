#include<iostream>
using namespace std;
int main()
{
	long long int n;
	cin>>n;
	cout<<(3*(n-3))+(n-3)*(n-4)+1<<endl;
}