#include<iostream>
#include<string.h>
#define N 1002
using namespace std;
int dp[N][N],mod=1000000007;
int No,M;
int solve(int n,int m)
{
	int colors_used_once;
	if(n>No)
		return 0;
	if(n==No)
		return 1;
	if(dp[n][m]!=-1)
		return dp[n][m];
	colors_used_once=2*n-m;
	colors_used_once=n-colors_used_once;
	int sol=0;
	//cout<<n<<" "<<m<<" "<<colors_used_once<<endl;
	if(colors_used_once&&m<=M)
	{
		sol=(sol+2*colors_used_once*1LL*(M-m)*solve(n+1,m+1))%mod;
	}
	
	if(M-m>=2)
	{
		sol=(sol+(M-m)*(M-m-1)*1LL*solve(n+1,m+2))%mod;
	}
	if(colors_used_once>=1)
	{
		sol=(sol+colors_used_once*(colors_used_once)*1LL*solve(n+1,m))%mod;
	}
	return dp[n][m]=sol;
}
int main()
{
	int t;
	scanf("%d",&t);
	memset(dp,-1,sizeof(dp));
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("%d\n",solve(n,m));
	}
}