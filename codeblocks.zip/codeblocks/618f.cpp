
#include<iostream>
#include<unordered_map>
#include<vector>
using namespace std;
unordered_map<int,pair<pair<int,int>,int> > ma1;
int main()
{
	std::ios::sync_with_stdio(false);
	int i,j,k,l,n,x;
	vector<long long int>a,b;
	long long int s=0;
    cin>>n;
    for(i=0;i<n;i++)
    {
    	cin>>x;
    	s+=x;
    	a.push_back(s);
    }
    s=0;
    for(i=0;i<n;i++)
    {
    	cin>>x;
    	s+=x;
    	b.push_back(s);
    }
    int ch=0;
    if(a[n-1]>b[n-1])
    	{
    		swap(a,b);
    		ch=1;
    	}
    ma1[0]=make_pair(make_pair(-1,-1),1);
    pair<pair<int,int>,int> pop;
    long long int sap=0;
    int low=0,xp;
    for(i=0;i<n;i++)
    {xp=0;
    	while(low<n&&b[low]<=a[i])
    		{
    			xp=1;
    			low++;
    		}

    		if(xp==1)
    			low--;
    		if(ma1[a[i]-b[low]].second)
    			{pop=make_pair(make_pair(i,low),a[i]-b[low]);break;}
    		else ma1[a[i]-b[low]]=make_pair(make_pair(i,low),1);
    }
    int y=pop.first.first,p=ma1[pop.second].first.second,q=pop.first.second;
    x=ma1[pop.second].first.first;
    if(x>=-1&x<n&&y>=-1&y<n&&p>=-1&p<n&&q>=-1&q<n&&ch)
    {
    	cout<<q-p<<endl;
    	for(int i=p+1;i<=q;i++)
    		cout<<i+1<<" ";
    	cout<<endl;
    	cout<<y-x<<endl;
    	for(int i=x+1;i<=y;i++)
    		cout<<i+1<<" ";
    	cout<<endl;
    }
    else if(x>=-1&x<n&&y>=-1&y<n&&p>=-1&p<n&&q>=-1&q<n&&!ch)
    {
    	cout<<y-x<<endl;
    	for(int i=x+1;i<=y;i++)
    		cout<<i+1<<" ";
    	cout<<endl;
    	cout<<q-p<<endl;
    	for(int i=p+1;i<=q;i++)
    		cout<<i+1<<" ";
    	cout<<endl;
    }
    else cout<<-1;
}