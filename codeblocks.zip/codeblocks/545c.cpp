#include<iostream>
using namespace std;
long long int a[100008][3];
int main()
{
	int n,s=1;
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i][0]>>a[i][1];
	a[n][0]=100000000000;
	a[n][1]=100000000000;
	for(int i=1;i<n;i++)
	{
		if(a[i-1][0]<a[i][0]-a[i][1])
		{
			s++;
		}
		else if(a[i][0]+a[i][1]<a[i+1][0])
		{
			s++;
			a[i][0]+=a[i][1];
		}
	}
	cout<<s<<endl;


}