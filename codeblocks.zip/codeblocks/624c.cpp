#include<iostream>
#include<algorithm>
#include<iomanip>
#include<vector>
#include<string.h>
using namespace std;
vector<int>adj[600];
int vis[600]={0};
int color[600]={0};
void dfs(int curr,int par,int col)
{
	vis[curr]=1;
	for(int i=0;i<adj[curr].size();i++)
		if(adj[curr][i]!=par&&vis[adj[curr][i]])
		{
			dfs(adj[curr][i],curr,col);
		}
}
int xy[505][505]={0},xy2[505][505]={0};
int main()
{
	int n,m,x,y,cc=0,ch=0;
	cin>>n>>m;
	string a;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		xy[x][y]=1;
		xy[y][x]=1;
	}	
	
	for(int i=1;i<=n;i++)
	color[i]=1;

	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	if(i!=j&&xy[i][j]==0){
			 if(color[j]==1)
		{
			color[i]=3;
			for(int k=0;k<adj[i].size();k++)
				if(color[adj[i][k]]!=3)
				color[adj[i][k]]=2;
		}
		else if(color[i]==1)
		{
			color[j]=3;
			for(int k=0;k<adj[j].size();k++)
				if(color[adj[j][k]]!=3)
				color[adj[j][k]]=2;
		}
		else if((color[i]==1&&color[j]==3)||(color[i]==3&&color[j]==1))
		{

		}
		else ch=1;
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	if(abs(color[i]-color[j])<=1&&i!=j){
		xy2[i][j]=1;
		xy2[j][i]=1;
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
		if(i!=j&&xy2[i][j]!=xy[i][j])
			ch=1;
	for(int j=1;j<=n;j++)
			if(color[j]==1)
				a.push_back('a');
			else if(color[j]==2)
				a.push_back('b');
			else if(color[j]==3)
				a.push_back('c');
	if(ch)
	cout<<"No"<<endl;
	else cout<<"Yes\n"<<a<<endl;	
}