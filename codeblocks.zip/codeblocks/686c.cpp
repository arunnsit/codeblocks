#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<stdio.h>
#include<map>
using namespace std;
int ar[7]={0,1,2,3,4,5,6};
map<pair<int,int>,int>m1;
int main()
{
	long long int n,m,cn,cm;
	scanf("%lld %lld",&n,&m);
	int d1=0,d2=0,total=0;
	n--;
	m--;
	cn=n;
	cm=m;
	if(!cn)
	{
		d1++;
	}
	if(!cm)
	{
		d2++;
	}
	while(cn)
	{
		cn/=7;
		d1++;
	}
	while(cm)
	{
		cm/=7;
		d2++;
	}
	total=d1+d2;
	if(total>7)
	{
		printf("0\n");
	}
	else
	{
		long long int t1=0,t2=0,seven=1,coun=0,tc=0;
		do
		{
			seven=1;
			t1=0;
			t2=0;
			for(int i=d1-1;i>=0;i--)
			{
				t1+=seven*ar[i];
				seven*=7;
			}
			seven=1;
			for(int i=d2+d1-1;i>=d1;i--)
			{
				t2+=seven*ar[i];
				seven*=7;
			}
			if(t1<=n&&t2<=m&&m1[make_pair(t1,t2)]==0)
			{
				m1[make_pair(t1,t2)]=1;
				coun++;
			}
			tc++;
		}
		while ( std::next_permutation(ar,ar+7) );
		printf("%lld\n",coun);
	}
}