#include<iostream>
#include<algorithm>
#include<math.h>
using namespace std;
long long int gcd(long long int a,long long int b)
{
	if(a==0)swap(a,b);
	if(b==0)return a;
	return gcd(b,a%b);
}
int main()
{
	long long int a,b,c,d,m=-1,k=-1,N=-1;
	cin>>a;
	if(a&1)
	{

		if((a-1)%4==0)
		{
			d=sqrt(a);
			for(long long int n=2;n<=d+1;n++)
			{
				if(sqrt(a-n*n)*sqrt(a-n*n)==a-n*n)
				{
					N=n;
					m=a-n*n;
					break;
				}
			}
			if(N!=-1)
			cout<<2*m*N<<" "<<abs(m*m-N*N)<<endl;
			else cout<<-1<<endl;
		}
		else
		{
			
		}
	}
	else
	{
		d=sqrt(a);
		a/=2;
		for(long long int n=2;n<=d+1;n++)
		{
			if(a%n==0)
			{
				//k=gcd(n,a/n);
				N=n;
				m=a/(n);
				break;
			}
		}
		if(N!=-1)
		{
			cout<<abs((m*m-N*N))<<" "<<(m*m+N*N)<<endl;
		}
		else cout<<-1<<endl;
	}
}