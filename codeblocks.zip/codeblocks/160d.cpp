/*
10 40
4 1 3
3 2 1
4 3 3
9 4 2
5 6 2
4 7 1
4 8 2
5 9 3
9 10 3
8 5 3
2 10 2
6 2 2
3 5 1
1 7 1
7 2 1
4 5 3
8 1 3
4 6 2
1 9 2
6 9 3
6 3 1
2 8 2
6 1 1
9 8 2
1 5 3
3 10 3
7 8 3
3 9 1
1 2 2
1 3 3
8 10 2
6 7 1
7 5 3
10 5 1
2 5 1
9 2 1
10 1 3
2 4 1
9 7 1
4 10 2
*/
/*
8 16
4 3 1
7 5 3
8 6 2
4 7 1
4 8 3
1 2 1
5 4 3
8 5 3
6 5 1
7 6 3
1 4 1
8 7 2
5 1 1
2 6 1
3 8 2
5 2 1

*/

#include<iostream>
#include<vector>
#include<algorithm>
#include<unordered_map>
#define N 100009
using namespace std;
vector<int> adj[N],scc_graph[N],num[N],scc_num[N];
vector<pair<int,int> > bridges;
vector<int> midgraph;
struct node
{
	int x,y,w,nos;
};
bool cmp(node a,node b)
{
	return a.w<b.w;
}
vector<node>edges,mst,un_sor_edge;

int P[N];

void create_set(int x)
{
	if(P[x])
		return ;
	 P[x]=x;
}
int find_parent(int x)
{
	if(P[x]==x)
		return x;
	else return find_parent(P[x]);
}
void merge_set(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(u>v)
		P[u]=v;
	else P[v]=u;
}

int disc[N],vis[N],low[N],bridge_checker,tim=0,mark_diff_ed[N],vis_for_sol[N],vis_for_sol2[N];

void dfs(int u,int p)
{
	vis[u]=1;
	disc[u]=low[u]=tim++;           //initial timer
	for(int i=0;i<adj[u].size();i++)
	{
			if(!vis[adj[u][i]])     
		{
			//P[adj[u][i]]=u;
			dfs(adj[u][i],u);
			low[u]=min(low[u],low[adj[u][i]]);

			if(disc[u]<low[adj[u][i]])  //lowest from this group has no edge above u , so they can be separated
			{
				bridges.push_back(make_pair(u,adj[u][i]));
				bridges.push_back(make_pair(adj[u][i],u));
				//cout<<adj[u][i]<<" "<<u<<endl;
			}
			else if(!mark_diff_ed[num[u][i]])
			{
				//cout<<"in1:"<<u<<" "<<adj[u][i]<<endl;
				scc_graph[u].push_back(adj[u][i]);
			    scc_graph[adj[u][i]].push_back(u);
			    scc_num[u].push_back(num[u][i]);
			    scc_num[adj[u][i]].push_back(num[u][i]);
			    //cout<<"in2:"<<u<<" "<<adj[u][i]<<" "<<num[u][i]<<endl;
			    mark_diff_ed[num[u][i]]++;
			}
		}
		else if(p!=adj[u][i])
		{
			low[u]=min(low[u],low[adj[u][i]]);
			if(!mark_diff_ed[num[u][i]])
			{scc_graph[u].push_back(adj[u][i]);
			scc_graph[adj[u][i]].push_back(u);
			scc_num[u].push_back(num[u][i]);
			scc_num[adj[u][i]].push_back(num[u][i]);
			mark_diff_ed[num[u][i]]++;
			//cout<<"in2:"<<u<<" "<<adj[u][i]<<" "<<num[u][i]<<endl;
		}
		}
    }
}
int solution[N]={0};

unordered_map<int,int>in_weights,actualinweight;
void dfs2(int u)
{
	for(int i=0;i<scc_graph[u].size();i++)
	if(!vis_for_sol[scc_num[u][i]]){
		vis_for_sol[scc_num[u][i]]=1;
		dfs2(scc_graph[u][i]);
		in_weights[un_sor_edge[scc_num[u][i]-1].w]++;
		if(solution[scc_num[u][i]])
			actualinweight[un_sor_edge[scc_num[u][i]-1].w]++;
	}
}
void dfs3(int u)
{
	for(int i=0;i<scc_graph[u].size();i++)
	if(!vis_for_sol2[scc_num[u][i]]){
		vis_for_sol2[scc_num[u][i]]=1;
		dfs3(scc_graph[u][i]);
//		cout<<"at: "<<u<<" "<<scc_graph[u][i]<<" "<<scc_num[u][i]<<" "<<un_sor_edge[scc_num[u][i]-1].w<<" "<<in_weights[un_sor_edge[scc_num[u][i]-1].w]<<" "<<actualinweight[edges[scc_num[u][i]-1].w]<<endl;
		if(in_weights[un_sor_edge[scc_num[u][i]-1].w]>actualinweight[un_sor_edge[scc_num[u][i]-1].w]&&actualinweight[un_sor_edge[scc_num[u][i]-1].w])
		{
			solution[scc_num[u][i]]=2;
		};
	}
}
int main()
{
	std::ios::sync_with_stdio(false);
	int n,m,x,y,z;
	cin>>n>>m;
	node tmp;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y>>z;
		tmp.x=x;
		tmp.y=y;
		tmp.w=z;
		tmp.nos=i+1;
		un_sor_edge.push_back(tmp);
		edges.push_back(tmp);
	}
	sort(edges.begin(),edges.end(),cmp);
	int curw=0;
	vector<pair<pair<int,int>,int> >merger;
	int preve=0;
	for(int i=0;i<m;i++)
	{
		if(preve!=edges[i].w)
		{
			for(int j=0;j<merger.size();j++)
			{
				if(find_parent(merger[j].first.first)!=find_parent(merger[j].first.second)){
				merge_set(merger[j].first.first,merger[j].first.second);
							solution[merger[j].second]=1;
										//mst.push_back(edges[i]);
									//	cout<<"yeah:"<<merger[j].first.first<<" "<<merger[j].first.second<<endl;

			}
			adj[merger[j].first.first].push_back(merger[j].first.second);
		 	    adj[merger[j].first.second].push_back(merger[j].first.first);
			    num[merger[j].first.first].push_back(merger[j].second);
			    num[merger[j].first.second].push_back(merger[j].second);
		     	midgraph.push_back(merger[j].second);
			}
			merger.clear();
		}
		create_set(edges[i].x);
		create_set(edges[i].y);
		if(find_parent(edges[i].x)!=find_parent(edges[i].y))
		{
			merger.push_back(make_pair(make_pair(edges[i].x,edges[i].y),edges[i].nos));
		}
		preve=edges[i].w;
		
	}
	for(int j=0;j<merger.size();j++)
			{
				if(find_parent(merger[j].first.first)!=find_parent(merger[j].first.second)){
				merge_set(merger[j].first.first,merger[j].first.second);
							solution[merger[j].second]=1;
										//mst.push_back(edges[i]);
										//cout<<"yeah:"<<merger[j].first.first<<" "<<merger[j].first.second<<endl;

			}
			adj[merger[j].first.first].push_back(merger[j].first.second);
		 	    adj[merger[j].first.second].push_back(merger[j].first.first);
			    num[merger[j].first.first].push_back(merger[j].second);
			    num[merger[j].first.second].push_back(merger[j].second);
		     	midgraph.push_back(merger[j].second);
			}
			merger.clear();
	
	dfs(1,0);
	/*for(int i=1;i<=n;i++)
	{
		for(int j=0;j<scc_graph[i].size();j++)
			cout<<i<<" "<<scc_graph[i][j]<<" "<<scc_num[i][j]<<endl;
	}*/
	for(int i=1;i<=n;i++)
	{
		dfs2(i);
		dfs3(i);
		in_weights.clear();
		actualinweight.clear();
	}
	for(int i=1;i<=m;i++)
	{
		if(solution[i]==1)
		{
			cout<<"any"<<endl;
		}
		else if(solution[i]==2)
		{
			cout<<"at least one"<<endl;
		}
		else cout<<"none"<<endl;
	}
}