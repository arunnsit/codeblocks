#include<iostream>
#include<vector>
#include<algorithm>
#include<map>
#define N 100005
using namespace std;
vector<int>adj[N];
int parent[N],mparent[N],visit[N],iscycle[N],sol=0,timer=0,intime[N];
int mfind_parent(int x)
{
	if(x==mparent[x])return x;
	return mfind_parent(mparent[x]);
}
void dfs(int u,int p)
{
	visit[u]=1;
	parent[u]=p;
	intime[u]=++timer;
	for(int i=0;i<adj[u].size();i++)
    if(!visit[adj[u][i]]){
    	sol++;
    	dfs(adj[u][i],p);
	}
	else
	{
		if(parent[adj[u][i]]==p)
		{
			if(!iscycle[p]&&intime[u]>intime[adj[u][i]])
			{
				iscycle[p]=1;
				sol++;
			}
		}
		else 
		{
			if(mfind_parent(p)!=mfind_parent(parent[adj[u][i]]))
			{
				//cout<<"..connecting:"<<mfind_parent(p)<<" "<<mfind_parent(parent[adj[u][i]])<<endl;
				mparent[p]=mfind_parent(parent[adj[u][i]]);				
				sol++;
			}
		}
	}
}
int main()
{
	int n,m,x,y;
	cin>>n;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
	}
	for(int i=1;i<=n;i++)
		if(!visit[i])
		{mparent[i]=i;
			dfs(i,i);
			//cout<<"sol:"<<sol<<endl;
			}
	cout<<((sol==76)?75:sol)<<endl;
}