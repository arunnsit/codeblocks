#include<iostream>
#include<algorithm>
#include<math.h>
#include<set>
#include<vector>
#include<string>
using namespace std;
int main()
{
	int c=0;
	string a;
	cin>>a;
	long long int sol=0;
	if(a.size()==1)
	{
		if((a[0]-'0')%4==0)
			cout<<1<<endl;
		else cout<<0<<endl;
		return 0;
	}
	for(int i=1;i<a.length();i++)
	{
		c=(a[i-1]-'0')*10+a[i]-'0';
		if(c%4==0)
		{
			sol+=i;
		}
	}
	for(int i=0;i<a.length();i++)
	{
		if((a[i]-'0')%4==0)sol++;
	}
	cout<<sol<<endl;
}