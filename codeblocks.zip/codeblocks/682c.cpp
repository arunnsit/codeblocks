#include<iostream>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<vector>
using namespace std;
long long int a[100009];
vector<int>adj[100009];
vector<long long int>w[100009];
int coun=0;
void dfs(int u,int p,long long int sum)
{
	coun++;
	if(a[u]<sum)
	{
		coun--;
		return ;
	}
	for(int i=0;i<adj[u].size();i++)
	{
		if(adj[u][i]!=p)
		{
			dfs(adj[u][i],u,max(0LL,sum+w[u][i]));
		}
	}
}
int main()
{
	int n,p;
	cin>>n;
	long long int c;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<n;i++)
	{
		cin>>p>>c;
		adj[i+1].push_back(p);
		adj[p].push_back(i+1);
		w[i+1].push_back(c);
		w[p].push_back(c);
	}
	dfs(1,0,0);
	cout<<n-coun<<endl;
}