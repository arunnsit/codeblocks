#include<iostream>
#include<string>
using namespace std;
string a[1009];
int xs[1009],ys[1008];
int main()
{
	int n,m,ts=0;
	cin>>n>>m;
	for(int i=0;i<n;i++)
		cin>>a[i];
	int x=-1,y=-1;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			
			if(a[i][j]=='*')
			{
				ys[j]+=1;
				xs[i]+=1;
				ts++;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			if(a[i][j]=='*'&&ys[j]+xs[i]==ts+1)
			{
				x=i+1;
				y=j+1;
			}
			else if(a[i][j]!='*'&&ys[j]+xs[i]==ts)
			{
				x=i+1;
				y=j+1;
			}
		}
	}
	if(x!=-1)
	{
		cout<<"YES\n"<<x<<" "<<y<<endl;

	}
	else cout<<"NO\n";
}