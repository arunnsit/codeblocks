#include<iostream>
#include<algorithm>
#include<vector>
#include<unordered_map>
using namespace std;
vector<int>adj[100008];
int main()
{
	int n,m,h,t,c,x,y;
	cin>>n>>m>>h>>t;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	int u=0,v=0;
	unordered_map<int,int>map1;
	for(int i=1;i<=n;i++)
		sort(adj[i].begin(),adj[i].end());
	for(int i=1;i<=n;i++)
	{
		map1.clear();

		if(h<=adj[i].size()-1)
		{
			for(int j=0;j<adj[i].size();j++)
			{
				map1[adj[i][j]]++;
			}
			for(int j=0;j<adj[i].size();j++)
		{
			cout<<"yeah:"<<i<<" "<<adj[i][j]<<endl;
			if(t==adj[adj[i][j]].size()-1)
			{
				u=i;
				v=adj[i][j];
			}
		}
	}
	}
	if(u)
	{   cout<<"YES\n";
        cout<<u<<" "<<v<<endl;
		for(int j=0;j<adj[u].size();j++)
			if(adj[u][j]!=v)
			cout<<adj[u][j]<<" ";
		cout<<endl;
		for(int j=0;j<adj[v].size();j++)
			if(adj[v][j]!=u)
			cout<<adj[v][j]<<" ";
		cout<<endl;
	}
	else cout<<"NO\n";
}