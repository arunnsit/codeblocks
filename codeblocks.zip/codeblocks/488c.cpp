#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int h1,a1,d1,h2,a2,d2,h,a,d;
	cin>>h1>>a1>>d1>>h2>>a2>>d2>>h>>a>>d;

	

}