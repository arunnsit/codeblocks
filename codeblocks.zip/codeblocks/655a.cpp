#include<iostream>
#include<string>
using namespace std;
char next_(char a, char b)
{
	for(int i=0;i<26;i++)
	{
		if(i+'a'!=a&&i+'a'!=b)
			return i+'a';
	}
}
int main()
{
	string a;
	cin>>a;
	for(int i=1;i<a.length();i++)
	{
		if(a[i-1]==a[i]&&i<a.length())
		{
			a[i]=next_(a[i-1],a[i+1]);
		}
		else if(a[i-1]==a[i]) a[i]=next_(a[i-1],a[i-1]);
	}
	cout<<a<<endl;
}