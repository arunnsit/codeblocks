#include<iostream>
#include<set>
#include<algorithm>
using namespace std;
multiset<int>s;
int a[100008];
int main()
{
	int n,x,y;
	long long int sum=0,sol=0,f1=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		sum+=a[i];
	}
	sort(a,a+n);
	sum/=n;
	//cout<<sum<<endl;
	for(int i=0;i<n;i++)
	{
		if(a[i]<=sum)
		{
			sol+=sum-a[i];
		}
		else
		{
			f1+=a[i]-sum-1;
		}
		 
	}
	cout<<sol+max(0LL,f1-sol)<<endl;
}