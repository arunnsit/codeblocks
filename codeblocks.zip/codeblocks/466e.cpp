#include <iostream>
#include <stdio.h>
#include <vector>
#define N 100006
using namespace std;
int parent[N],in[N],out[N],timer=0,query[N][5],mark[N],info[N],qtime[N],to;
vector<int> adj[N],q[N];
void createset(int x)
{
	if(parent[x])
		return ;
	else parent[x]=x;
}
int fp(int x)
{
	if(parent[x]==x)
		return x;
	else return fp(parent[x]);
}
void merge(int x,int y)
{
	int u,v;
	u=fp(x);
	v=fp(y);
	if(u<v)
		parent[v]=u;
	else parent[u]=v;
}
void dfs(int x)
{
	timer++;
	in[x]=timer;
	for(int i=0;i<adj[x].size();i++)
	{
		dfs(adj[x][i]);
	}
	timer++;
	out[x]=timer;
}
int main()
{
	int n,m,x,y,z,c=0;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x;
		if(x==1)
		{
			cin>>y>>z;
			query[i][0]=x;
			query[i][1]=y;
			query[i][2]=z;
			adj[z].push_back(y);
			mark[y]++;
		}
		else if(x==2)
		{
			cin>>y;
			c++;
			query[i][0]=x;
			query[i][1]=y;
			query[i][2]=c;
		}
		else
		{
			cin>>y>>z;
			query[i][0]=x;
			query[i][1]=y;
			query[i][2]=z;
			q[z].push_back(i); 
		}
	}
	for(int i=1;i<=n;i++)
		if(!mark[i])
			{
				dfs(i);
			}
	for(int i=0;i<m;i++)
	{
		if(query[i][0]==1)
		{
			createset(query[i][1]);
			createset(query[i][2]);
			merge(query[i][1],query[i][2]);
		}
		if(query[i][0]==2)
		{
			createset(query[i][1]);
			for(int j=0;j<q[query[i][2]].size();j++)
			{
				to=query[q[query[i][2]][j]][1];
				createset(to);
				//cout<<"to:"<<to<<" "<<query[i][2]<<" "<<query[i][1]<<endl;
				if(fp(query[i][1])==fp(to)&&in[to]<=in[query[i][1]]&&out[to]>=out[query[i][1]])
				{
					query[q[query[i][2]][j]][4]=1;
				}
			}
		}
	}
		for(int i=0;i<m;i++)
		{
			if(query[i][0]==3)
			{
				if(query[i][4]==1)
					cout<<"YES\n";
				else cout<<"NO\n";
			}
		}

}