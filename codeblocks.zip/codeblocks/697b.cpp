#include<iostream>
#include<vector>
#include<string>
using namespace std;
int main()
{
	string a;
	cin>>a;
	int x=0,po=1,dotp=0;
	for(int i=a.length()-1;i>=0;i--)
	{
		if(a[i]=='e')break;
		x+=(a[i]-'0')*po;
		po*=10;
	}
	//cout<<x<<endl;
	string b;
	for(int i=0;i<a.length();i++)
	{
		if(a[i]=='e')
		{
			break;
		}
		if(a[i]=='.')
		{
			dotp=i;
		}
		else b.push_back(a[i]);
	}
	while(b.back()=='0')
	{
		b.pop_back();
	}
	dotp+=x;
	if(b.size()==0)
	{
		cout<<"0"<<endl;
	}
	else if(dotp>=b.length())
	{
		string c;
		for(int j=0;j<b.length();j++)
		{
			c.push_back(b[j]);
		}
		int y=dotp-b.length();
		while(y--)
		{
			c.push_back('0');
		}
		while(c.length()>2&&c[0]=='0'&&c[1]!='.')
		{
			c.erase(c.begin());
		}
		cout<<c<<endl;
	}
	else
	{
		string c;
		for(int i=0;i<b.length();i++)
		{
			if(i==dotp)
				c.push_back('.');
			c.push_back(b[i]);
		}
		while(c.length()>2&&c[0]=='0'&&c[1]!='.')
		{
			c.erase(c.begin());
		}
		cout<<c<<endl;
	}
}