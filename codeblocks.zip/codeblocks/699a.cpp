#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int b[200009];
int main()
{
	string a;
	int x=2000000000,n;
	cin>>n;
	cin>>a;
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
		if(i)
		{
			if(a[i]=='L'&&a[i-1]=='R')
			{
				x=min(x,(b[i]-b[i-1]+1)/2);
			}
		}
	}
	if(x!=2000000000)cout<<x<<endl;
	else cout<<-1<<endl;
}