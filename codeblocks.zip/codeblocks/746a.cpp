#include<iostream>
using namespace std;
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	int x=min(a,min(b/2,c/4));

	cout<<x+2*x+4*x<<endl;
}