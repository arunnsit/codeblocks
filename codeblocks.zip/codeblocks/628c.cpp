#include<string>
#include<algorithm>
#include<iostream>
using namespace std;
int main()
{
	string a,b;
	int n,k;
	cin>>n>>k;
	cin>>a;
	int ma=0;
	for(int i=0;i<a.size();i++)
	{
		ma+=max(abs(a[i]-'a'),abs(a[i]-'z'));
	}
	if(ma<k)
		cout<<-1<<endl;
	else 
	{
		int ch=0,cma=0;
		for(int i=0;i<a.size();i++)
		{
			if(!k)
			{
				b.push_back(a[i]);
			}
			else
			{
				cma=max(abs(a[i]-'a'),abs(a[i]-'z'));
				if(cma>k)
				{
					if('z'-a[i]>=k)
					{
						b.push_back(a[i]+k);
					}
					else b.push_back(a[i]-k);
					k=0;
				}
				else
				{
					if(abs(a[i]-'a')>abs(a[i]-'z'))
					{
						b.push_back('a');
					}
					else b.push_back('z');
					k-=cma;
				}
			}
		}
		cout<<b<<endl;
	}
}