#include<iostream>
using namespace std;
int arr[1000008];
int main()
{
	int n;
	cin>>n;
	int l=1,r=n+1;
	for(int i=1;i<n;i++)
	{
		if(i%2)
		{
			arr[l]=i;
			arr[l+n-i]=i;
			l++;
		}
		else
		{
			arr[r]=i;
			arr[r+n-i]=i;
			r++;
		}
	}
	for(int i=1;i<=2*n;i++)
		if(arr[i])
			cout<<arr[i]<<" ";
		else cout<<n<<" ";
}