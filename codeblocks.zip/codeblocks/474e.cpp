#include<algorithm>
#include<iostream>
#include<set>
#include<vector>
#include<algorithm>
#include<unordered_map>
using namespace std;
unordered_map<long long int ,int>ma;
long long int in[1000009];
struct node
{
	int v,p;
};
node tree[6000009];
vector<long long int>v;
node merge(node a,node b)
{
	if(a.v>b.v)
	{
		return a;
	}
	return b;
}
int u;
void update(int curr,int l,int r,int x,int val)
{
	if(l==r)
	{
		tree[curr].v=val;
		tree[curr].p=u;
		return;
	}
	int mid=l+((r-l)>>1);
	if(x>mid)
		update(2*curr+2,mid+1,r,x,val);
	else update(2*curr+1,l,mid,x,val);
	tree[curr]=merge(tree[2*curr+1],tree[2*curr+2]);
}
node query(int curr,int x,int y,int l,int r)
{
	if(l>y||r<x)
	{
		node c;
		c.v=-1;
		c.p=-1;
		return c;
	}
	if(x<=l&&r<=y)
	{
		return tree[curr];
	}
	int mid=l+((r-l)>>1);
	return merge(query(2*curr+1,x,y,l,mid),query(2*curr+2,x,y,mid+1,r));
}
int arr[1000000];
vector<int>vos;
int main()
{
	int n,d;
	cin>>n>>d;
	for(int i=1;i<=n;i++)
	{
		cin>>in[i];
		v.push_back(in[i]);
		v.push_back(in[i]-d);
		v.push_back(in[i]+d);
	}
	sort(v.begin(),v.end());
	int timer=0;
	for(int i=0;i<v.size();i++)
	{
		if(!ma[v[i]])
		{
			ma[v[i]]=timer++;
		}
		//cout<<v[i]<<" "<<ma[v[i]]<<endl;
	}
	node sol;
	int vo=0,mar=0;
	for(int i=1;i<=n;i++)
	{
		u=i;
		sol=query(0,0,ma[in[i]-d],0,timer-1);
		sol=merge(sol,query(0,ma[in[i]+d],timer-1,0,timer-1));
		arr[i]=sol.p;
		update(0,0,timer-1,ma[in[i]],sol.v+1);
		if(mar<sol.v)
		{
			mar=sol.v;
			vo=i;
		}
	}
	int x=vo;
	while(x!=0)
	{
		//cout<<x<<" ";
		vos.push_back(x);
		x=arr[x];
	}
	cout<<vos.size()<<endl;
	for(int i=vos.size()-1;i>=0;i--)
		cout<<vos[i]<<" ";
}