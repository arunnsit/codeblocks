#include<iostream>
#include<vector>
#include<algorithm>
#define N 100009
#define LOGN 23
using namespace std;
vector<int>adj[N],num[N];
int coun[N],dp[LOGN][N],level[N],n,nodemark[N];
void dfs0(int curr,int p)
{
	for(vector<int>::iterator it=adj[curr].begin();it!=adj[curr].end();it++)
	if(*it!=p)
	{   
		dp[0][*it]=curr;
		level[*it]=level[curr]+1;
		dfs0(*it,curr);
	}
}
void preprocess()
{
	level[0]=0;
	dp[0][0]=0;
	dfs0(0,0);
	for(int i=1;i<LOGN;i++)
		for(int j=0;j<n;j++)
			dp[i][j] = dp[i-1][dp[i-1][j]];
}
int lca(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			b=dp[i][b];
	if(a==b)return a;
	for(int i=LOGN-1;i>=0;i--)
		if(dp[i][a]!=dp[i][b])
			a=dp[i][a],b=dp[i][b];
	return dp[0][a];
}
int dfs(int start,int p)
{
	int s=0,tot=0;
	for(int i=0;i<adj[start].size();i++)
		if(adj[start][i]!=p)
		{
			s=dfs(adj[start][i],start);
			//cout<<"edge:"<<adj[start][i]<<" s:"<<s<<endl;
			tot+=s;
			coun[num[start][i]]=s;
		}
		//cout<<"at:"<<start<<" tot:"<<tot<<endl;
		return tot+nodemark[start];
}
int main()
{
	cin>>n;
	int x,y,k,c;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		x--;
		y--;
		adj[x].push_back(y);
		adj[y].push_back(x);
        num[x].push_back(i);
		num[y].push_back(i);
	}
	preprocess();
	cin>>k;
	for(int i=0;i<k;i++)
	{
		cin>>x>>y;
		x--;
		y--;
		c=lca(x,y);
		nodemark[c]-=2;
		nodemark[x]++;
		nodemark[y]++;
	}
	dfs(0,0);
	for(int i=0;i<n-1;i++)
		cout<<coun[i]<<" ";
}