#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
int dp[5][10]={0},l=0;
string a;
int main()
{
	cin>>a;
	for(int i=0;i<a.length();i++)
		{
		  if(a[i]=='1')
		   {
		   	dp[(i+1)%2][1]=dp[i%2][1]+1;
		   	dp[(i+1)%2][2]=dp[i%2][2];
		   	dp[(i+1)%2][3]=dp[i%2][3];
		   	dp[(i+1)%2][4]=dp[i%2][4];
		   }
		   if(a[i]=='8')
		   {
		   	dp[(i+1)%2][1]=dp[i%2][1];
		   	dp[(i+1)%2][2]=max(dp[i%2][2],dp[i%2][1])+1;
		   	if(dp[i%2][1]||dp[i%2][2]){}
		   	else dp[(i+1)%2][2]=0;
		   	dp[(i+1)%2][3]=dp[i%2][3];
		   	dp[(i+1)%2][4]=dp[i%2][4];
		   }
		   if(a[i]=='0')
		   {
		   	dp[(i+1)%2][1]=dp[i%2][1];
		   	dp[(i+1)%2][2]=dp[i%2][2];
		   	dp[(i+1)%2][3]=max(dp[i%2][3],dp[i%2][2])+1;
		   	if(dp[i%2][3]||dp[i%2][2]){}
		   	else dp[(i+1)%2][3]=0;
		   	dp[(i+1)%2][4]=dp[i%2][4];
		   }
		   if(a[i]=='7')
		   {
		   	dp[(i+1)%2][1]=dp[i%2][1];
		   	dp[(i+1)%2][2]=dp[i%2][2];
		   	dp[(i+1)%2][3]=dp[i%2][3];
		   	dp[(i+1)%2][4]=max(dp[i%2][4],dp[i%2][3])+1;
		   	if(dp[i%2][4]||dp[i%2][3]){}
		   	else dp[(i+1)%2][4]=0;
		   }
		}
	cout<<dp[a.length()%2][4]<<endl;	
}