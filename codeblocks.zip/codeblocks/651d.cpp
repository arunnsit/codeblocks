#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
using namespace std;
vector<int> lef,rig;
int ri[700000];
int main()
{
	int n,a,b,t,lf=0;
	cin>>n>>a>>b>>t;
	string in;
	cin>>in;
	int x=0,y=n-1;
	int total=0;
	if(in[0]=='h')
	lef.push_back(1);
    else 
    lef.push_back(b+1);	

	for(int i=1;i<n;i++)
		if(in[i]=='h')
		{
			lef.push_back(lef[i-1]+a+1);
		}
		else
		{
			lef.push_back(lef[i-1]+a+b+1);
		}

	if(in[n-1]=='h')
	ri[n-1]=a+1;
    else 
    ri[n-1]=b+a+1;

	for(int i=n-2;i>=0;i--)
		if(in[i]=='h')
		{
			ri[i]=ri[i+1]+1+a;
		}
		else
		{
			ri[i]=ri[i+1]+a+b+1;
		}
	for
	(int i=n-1;i>=0;i--)
	{
		rig.push_back(ri[i]);
		//cout<<lef[n-1-i]<<" ";
	}
	//cout<<endl;
	int curr=0,sol=0,l=0;
	sol=0;
	for(int i=0;i<n;i++)
	{		
	    if(in[i]=='h')
	    {
	    	curr+=a+1;
	    }
	    else
	    {
	    	curr+=b+a+1;
	    }
	    if(i==0)
	    	curr-=a;
	    l++;
	    if(curr>t)break;
	    sol=max(sol,l+(int)(upper_bound(rig.begin(),rig.end(),t-curr-(l-1)*a)-rig.begin()));
	  // cout<<curr<<" "<<sol<<" "<<l<<endl;
	}
	curr=lef[0],l=1;
	int sol2=1;
	if(curr>t)
		sol2=0;
	for(int i=n-1;i>0;i--)
	{		
	    if(in[i]=='h')
	    {
	    	curr+=a+1;
	    }
	    else
	    {
	    	curr+=b+a+1;
	    }
	    l++;
	    if(curr>t)break;
	    sol2=max(sol2,l+(int)(upper_bound(lef.begin(),lef.end(),t-curr-(l-1)*a+lef[0])-lef.begin())-1);
	   //cout<<curr<<" "<<sol2<<" "<<l<<" "<<(int)(upper_bound(lef.begin(),lef.end(),t-curr-(l)*a+lef[0]-1+a)-lef.begin())-1<<" "<<t-curr-(l-1)*a+lef[0]-1<<endl;
	}
	cout<<min(max(sol,sol2),n)<<endl;
}