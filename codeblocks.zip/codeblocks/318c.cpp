#include<iostream>
#include<algorithm>
#include<math.h>
#include<set>
#include<string.h>
using namespace std;
set<pair<int,pair<long long int,long long int> > >s;
long long int m;
int solve(long long int x,long long int y)
{
	s.insert(make_pair(0,make_pair(x,y)));
	int c=0,cou;
	while(!s.empty())
	{
		c=(*s.begin()).first;
		x=(*s.begin()).second.first;
		y=(*s.begin()).second.second;
		//cout<<c<<" "<<x<<" "<<y<<endl;
		s.erase(s.begin());
		if(x>=m||y>=m)
			return c;
		{
			if((x<x+y))
			s.insert(make_pair(c+1,make_pair(x+y,y)));
			if((y<x+y))
			s.insert(make_pair(c+1,make_pair(x,y+x)));
		}
		cou++;
		if(cou>=500000)
			break;
	}
	return -1;
}
int main()
{
	long long int x,y;
	cin>>x>>y>>m;
	cout<<solve(x,y)<<endl;
}