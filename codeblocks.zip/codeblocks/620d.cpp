#include<iostream>
#include<vector>
#include<set>
#include<unordered_map>
using namespace std;
int a[3000],b[3000];
set<long long int >y;
vector<pair<int,int> >v;
long long int min_k=10000000000000000LL;
int n,m;
unordered_map<int,int>mas;
void recurse(long long int s1,long long int s2,int depth)
{
	long long int del=s1-s2,temp,val,val2;
	int pos;
	set<long long int>::iterator it,it2;
	for(int i=0;i<n;i++)
	{
		val=a[i];
		temp=del-a[i];
		it=y.lower_bound(temp);
		if(it!=y.end())
		{
			val2=*it;
			pos=mas[val2];
		}
	}
}
int main()
{
	long long int s1=0,s2=0,del;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		s1+=a[i];
	}
	scanf("%d",&m);
	for(int i=0;i<m;i++)
	{
		scanf("%d",&b[i]);
		s2+=b[i];
		y.insert(b[i]);
		mas[b[i]]=i;
	}
}