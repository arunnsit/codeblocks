#include<iostream>
#include<algorithm>
#include<set>
#include<vector>
#include<string>
#include<stdio.h>
#include<string.h>
#include<unordered_map>
using namespace std;
unordered_map<int,int>m;
int main()
{
	int n,ch=0;
	int a=1234567,b=123456,c=1234,pop;
	scanf("%d",&n);
	for(int i=0;i<=(1000000000/a)+1;i++)
		{
			if(i*a>n)
				break;
			for(int j=0;j<=(1000000000/b)+1;j++)
			if(i*a+j*b<=n){
				if((n-(i*a+j*b))%c==0)
				{
					ch=1;
				}
			}
			else break;
	}
	
	if(ch)
		printf("YES\n");
	else printf("NO\n");
}