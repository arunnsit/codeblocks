#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
	string a,b;
	cin>>a>>b;
	if(a==b)
	{
		cout<<a<<endl;
	}
	else cout<<1<<endl;
}