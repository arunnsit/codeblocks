#include<iostream>
#include<vector>
using namespace std;
vector<int>v;
int main()
{
	int n,tmp;
	for(int i=0;i<n;i++)
	{
		cin>>tmp;
		v.push_back(tmp);
	}
}