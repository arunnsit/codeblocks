#include<iostream>
#include<algorithm>
#include<math.h>
#include<map>
#include<vector>
#include<queue>
using namespace std;
int mo[405][405];
queue<pair<int,int> >q;

int d[4][2]={{1,0},{0,-1},{0,1},{-1,0}};
void simulate(int n)
{
	mo[200][200]=n;
	q.push(make_pair(200,200));
	int x,y,dx,dy;
	while(!q.empty())
	{
		x=q.front().first;
		y=q.front().second;
		if(mo[x][y]>=4)
		{
			for(int i=0;i<4;i++)
			{
				dx=x+d[i][0];
				dy=y+d[i][1];
				mo[dx][dy]+=mo[x][y]/4;
				if(mo[dx][dy]>=4)
				q.push(make_pair(dx,dy));
			}
		}
		mo[x][y]%=4;
		q.pop();
	}
	//cout<<"done\n";
}
int main()
{
	int n,t,x,y;
	cin>>n>>t;
	simulate(n);
	while(t--)
	{
		cin>>x>>y;
		if(200+x>=0&&200+x<=400&&200+y>=0&&200+y<=400)
		cout<<mo[200+x][200+y]<<endl;
	else cout<<0<<endl;
	}
}