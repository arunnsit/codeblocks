#include<iostream>
#include<vector>
#include<algorithm>
#include<complex>
#include<vector>
#include<string>
#include<math.h>
using namespace std;
typedef complex<double> base;
int rev (int num, int lg_n) {
    int res = 0;
    for (int i=0; i<lg_n; ++i)
        if (num & (1<<i))
            res |= 1<<(lg_n-1-i);
    return res;
}
void fft (vector<base> & a, bool invert) {
    int n = (int) a.size();
    int lg_n = 0;
    while ((1 << lg_n) < n)  ++lg_n;
 
    for (int i=0; i<n; ++i)
        if (i < rev(i,lg_n))
            swap (a[i], a[rev(i,lg_n)]);
        
    for (int len=2; len<=n; len<<=1) {
        double ang = 2*M_PI/len * (invert ? -1 : 1);
        base wlen (cos(ang), sin(ang));
        for (int i=0; i<n; i+=len) {
            base w (1);
            for (int j=0; j<len/2; ++j) {
                base u = a[i+j],  v = a[i+j+len/2] * w;
                a[i+j] = u + v;
                a[i+j+len/2] = u - v;
                w *= wlen;
            }
        }
    }
    if (invert)
        for (int i=0; i<n; ++i)
            a[i] /= n;
}
vector<int> multiply (const vector<int> & a, const vector<int> & b) {
    vector<base> fa (a.begin(), a.end()),  fb (b.begin(), b.end());
    size_t n = 1;
    while (n < max (a.size(), b.size()))  n <<= 1;
    n <<= 1;
    fa.resize (n),  fb.resize (n);
  vector<int> res;
    fft (fa, false),  fft (fb, false);
    for (size_t i=0; i<n; ++i)
        fa[i] *= fb[i];
    fft (fa, true);
 
    res.resize(n);
    for (size_t i=0; i<n; ++i)
        res[i] = int (fa[i].real() + 0.5);
        return res;
}
int mo[300]={0};
vector<int>a[4],b[4],c[4],res[4];
int n,m,k;
int check(int y,int x,int ch)
{
    x=min(x,n-1);
    if(y-1<0)
        return c[ch][x];
    else return c[ch][x]-c[ch][y-1];
}
int main()
{
    cin>>n>>m>>k;
    string s,t;
    cin>>s>>t;
    mo['C']=1;
    mo['G']=2;
    mo['T']=3;
    for(int i=0;i<4;i++)
    {
        a[i].resize(n+1,0);
        c[i].resize(n+1,0);
        b[i].resize(m+1,0);
        res[i].resize(3*n,0);
    }
    for(int i=0;i<n;i++)
    {
        a[mo[s[i]]][i]=1;
        c[mo[s[i]]][i]=1;
    }
    for(int i=1;i<n;i++)
    {
        for(int j=0;j<4;j++)
        {
            c[j][i]+=c[j][i-1];
        }
    }
    for(int i=0;i<m;i++)
    {
        b[mo[t[i]]][m-1-i]=1;
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<4;j++)
        if(check(i-k,i+k,j))
        {
            a[j][i]=1;
        }
    }
    for(int i=0;i<4;i++)
    {
        res[i]=multiply(a[i],b[i]);
    }
    int x=0,sans=0;
    for(int i=m-1;i<n;i++)
    {
        x=0;
        for(int j=0;j<4;j++)
        {
            x+=res[j][i];

        }
        if(x==m)
        {
            sans++;
        }
    }
    cout<<sans<<endl;
}