#include<iostream>
#include<algorithm>
#include<stack>
using namespace std;
int arr[1000000];
int main()
{
	int n,i,j,k,x,c=0;
	cin>>n;
	stack<int> sexy;
	for(i=0;i<n;i++)
	{
		x=1;
		while(!sexy.empty()&&x==sexy.top())
		{
			x+=1;
			sexy.pop();
		}
		sexy.push(x);
	}
	while(!sexy.empty())
	{
		arr[c++]=sexy.top();
		sexy.pop();
	}
	for(i=c-1;i>=0;i--)
		cout<<arr[i]<<" ";
}