#include<iostream>
using namespace std;
int arr[200000];
int main()
{
	int n,s,l;
	cin>>n>>s>>l;
	for(int i=0;i<n;i++)
		cin>>arr[i];
	int x=-1,y=0,len=1,sol=0;
	while(y<n)
	{
		if(arr[y])
	}
}