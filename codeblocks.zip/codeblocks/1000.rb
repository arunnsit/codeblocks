require 'scanf'
a=scanf("%d %d")
puts a[0] + a[1]