#include<iostream>
#include<map>
#include<vector>
#include<math.h>
#include<algorithm>
#include<stdio.h>
using namespace std;
vector<pair<int,int> >p;
int gcd(int a,int b)
{
	if(b==0)
		return a;
	return gcd(b,a%b);
}
map<pair<int,int>,vector<pair< pair<int,int>,pair<int,int> > > >m;

double infi=1000000005;
int main()
{
	int n;
	scanf("%d",&n);
	int x,y;
	int x1=0,y1=0,y2,x2,x3,y3,x4,y4,mi;
	int sol=0;
	for(int i=0;i<n;i++)
	{
		scanf("%d %d",&x,&y);
		p.push_back(make_pair(x,y));
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(p[i].first==p[j].first)
			{
				if(p[i]<p[j])
				m[make_pair(infi,0)].push_back(make_pair(p[i],p[j]));
				else m[make_pair(infi,0)].push_back(make_pair(p[j],p[i]));
			}
			else
			{
				x1=p[i].first;
				y1=p[i].second;
				x2=p[j].first;
				y2=p[j].second;
				mi=1;
				if(y2-y1<0||x2-x1<0)
				{
					if(y2-y1<0&&x2-x1<0)
					{

					}
					else mi=-1;
				}

				if(p[i]<p[j])
				m[make_pair(mi*abs(y2-y1)/gcd(abs(y2-y1),abs(x2-x1)),abs(x2-x1)/gcd(abs(y2-y1),abs(x2-x1)))].push_back(make_pair(p[i],p[j]));
				else m[make_pair(mi*abs(y2-y1)/gcd(abs(y2-y1),abs(x2-x1)),abs(x2-x1)/gcd(abs(y2-y1),abs(x2-x1)))].push_back(make_pair(p[j],p[i]));
			}
		}
	}
	for(map<pair<int,int>,vector<pair< pair<int,int>,pair<int,int> > > >::iterator it=m.begin();it!=m.end();it++)
	{
		sort(it->second.begin(),it->second.end());
	}
	for(map<pair<int,int>,vector<pair< pair<int,int>,pair<int,int> > > >::iterator it=m.begin();it!=m.end();it++)
	{
		//cout<<it->first<<".."<<endl;
		if(it->second.size()>=2)
		{

			int ctr=0;
				//cout<<"yeah"<<" "<<it->first.first<<endl;
				for(int i=0;i<it->second.size();i++)
				{
					for(int j=i+1;j<it->second.size();j++)
					{
						x1=it->second[i].first.first;
						y1=it->second[i].first.second;
						x2=it->second[i].second.first;
						y2=it->second[i].second.second;
						x3=it->second[j].first.first;
						y3=it->second[j].first.second;
						x4=it->second[j].second.first;
						y4=it->second[j].second.second;
					//cout<<x1<<" "<<y1<<" "<<x2<<" "<<y2<<" "<<x3<<" "<<y3<<" "<<x4<<" "<<y4<<endl;	
					if((y2-y1)*(x4-x3)==(y4-y3)*(x2-x1)&&(y4-y2)*(x3-x1)==(y3-y1)*(x4-x2))
					{
					sol++;
					}
					}	
				}	
		}
	}
	printf("%d\n",sol/2);
}