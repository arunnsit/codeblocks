#include<iostream>
#include<vector>
using namespace std;
int a[200][200];
vector<pair<pair<int,int>,pair<int,int> > >v;
vector<int>s1;
int n,m,q,x,y,z,w;
void shift1(int r)
{
	s1.clear();
	s1.push_back(a[r][m-1]);
	for(int i=0;i<m-1;i++)
	{
		s1.push_back(a[r][i]);
	}
	for(int i=0;i<s1.size();i++)
	{
		a[r][i]=s1[i];
	}
}
void shift2(int c)
{
	s1.clear();
	s1.push_back(a[n-1][c]);
	for(int i=0;i<n-1;i++)
	{
		s1.push_back(a[i][c]);
	}
	for(int i=0;i<s1.size();i++)
	{
		a[i][c]=s1[i];
	}
}

int main()
{
	cin>>n>>m>>q;
	for(int i=0;i<q;i++)
	{
		cin>>x>>y;
		if(x==1||x==2)
		{
			v.push_back(make_pair(make_pair(x,y),make_pair(0,0)));
		}
		else
		{
			cin>>z>>w;
			v.push_back(make_pair(make_pair(x,y),make_pair(z,w)));
		}		
	}
	for(int i=q-1;i>=0;i--)
	{
		if(v[i].first.first==3)
		{
			a[v[i].first.second-1][v[i].second.first-1]=v[i].second.second;
		}
		else
		{
			if(v[i].first.first==1)
				shift1(v[i].first.second-1);
			else
			{
				shift2(v[i].first.second-1);
			}
		}
	}
	for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			cout<<a[i][j]<<" ";
		cout<<"\n";
	}


}