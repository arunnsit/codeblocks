#include<vector>
#include<algorithm>
#include<iostream>
#include<stdio.h>
using namespace std;
vector<int>v[1000009],in,poser[1000008],sol;
int coun[1000002],coun2[1000002];
int main()
{
	int n,m,x;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&x);
		if(x<=1000000)
		{
			coun[x]++;
			poser[x].push_back(i);
		}
	}

	for(int i=1;i<=1000000;i++)
		for(int j=i;j<=1000000;j+=i)
		{
			coun2[j]+=coun[i];
			v[j].push_back(i);
		}
	int mlcm=1,mval=0;	
	for(int i=1;i<=m;i++)
	{
		if(mval<coun2[i])
		{
			mval=coun2[i];
			mlcm=i;
		}
	}

	printf("%d %d\n",mlcm,mval);
	for(int i=0;i<v[mlcm].size();i++)
	{
		for(int j=0;j<poser[v[mlcm][i]].size();j++)
		{
			sol.push_back(poser[v[mlcm][i]][j]);
		}
	}	
	sort(sol.begin(),sol.end());
	for(int i=0;i<sol.size();i++)
		printf("%d ",sol[i]);
	printf("\n");
}