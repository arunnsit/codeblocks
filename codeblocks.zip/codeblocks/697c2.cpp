#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<unordered_map>
#include<stdio.h>
using namespace std;
unordered_map<long long int ,long long int>ma;
int logs(long long int x)
{
	int c=0;
	while(x)
	{
		x/=2;
		c++;
	}
	return c;
}
int main()
{
	int q;
	long long int x,y,w;
	int type;
	scanf("%d",&q);
	while(q--)
	{
		
		scanf("%d",&type);
		if(type==1)
		{
			scanf("%lld %lld %lld",&x,&y,&w);
			while(x!=y)
		{
			if(logs(x)>logs(y))
			{
				ma[x]+=w;
				x/=2;
			}
			else if(logs(x)<logs(y))
			{
				ma[y]+=w;
				y/=2;
			}
			else
			{
				ma[y]+=w;
				y/=2;
				ma[x]+=w;
				x/=2;
			}
		}
	}
		else
		{
			scanf("%lld %lld",&x,&y);
			long long int sol=0;
		while(x!=y)
		{
			if(logs(x)>logs(y))
			{
				sol+=ma[x];
				x/=2;
			}
			else if(logs(x)<logs(y))
			{
				sol+=ma[y];
				y/=2;
			}
			else
			{
				sol+=ma[y];
				y/=2;
				sol+=ma[x];
				x/=2;
			}
		}
			printf("%lld\n",sol);
		}

	}
}