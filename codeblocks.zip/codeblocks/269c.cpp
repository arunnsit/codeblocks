//flow arrangement
#include<iostream>
#include<queue>
#include<vector>
#define N 200009
using namespace std;
vector<int>adj[N],w[N],num[N],type[N];
int ans[N],f[N];
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		ans[i]=-1;
		int x,y,z;
		cin>>x>>y>>z;
		adj[x].push_back(y);
		adj[y].push_back(x);
		type[x].push_back(0);
		type[y].push_back(1);
		num[x].push_back(i);
		num[y].push_back(i);
		w[x].push_back(z);
		w[y].push_back(z);
		f[x]+=z;
		f[y]+=z;
	}
	for(int i=2;i<n;i++)
		f[i]/=2;
	queue<int>q;
	q.push(1);
	int x;
	while(!q.empty())
	{
		x=(q.front());
		q.pop();
		for(int i=0;i<adj[x].size();i++)
		if(ans[num[x][i]]==-1)
		{
			ans[num[x][i]]=type[x][i];
			f[adj[x][i]]-=w[x][i];
			f[x]+=w[x][i];
			if(f[adj[x][i]]==0)
			{
				q.push(adj[x][i]);
			}
		}
	}
	for(int i=0;i<m;i++)
		cout<<ans[i]<<endl;
}