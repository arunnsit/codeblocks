#include<stdio.h>
#include<algorithm>
#include<iostream>
#include<string.h>
#include<stack>
using namespace std;
string a;
int N,c,k;
int dp[600000][30]={0};

int main()
{
	cin>>N>>c;
	cin>>a;
	int x=N;
	int sap=0;
	for(int j=1;j<=c;j++)
		dp[0][j]=1;
	dp[0][a[0]-64]=0;
	for(int i=1;i<N;i++)
		{
			for(int j=1;j<=c;j++)
			{sap=N;
				for(int k=1;k<=c;k++)
					if(k!=j)
					{
						sap=min(dp[i-1][k],sap);
					}
			if(j==a[i]-64)
			   dp[i][j]=sap;
			else
			   	dp[i][j]=sap+1;	
			}
		}		
for(int j=1;j<=c;j++)
	x=min(x,dp[N-1][j]);

	cout<<x<<endl;
	stack<char>sol;
    x=N;
   
	for(int i=N-1;i>=0;i--)
		{
			x=N;
			for(int j=1;j<=c;j++)
		    if(!(!sol.empty()&&sol.top()-64==j))x=min(x,dp[i][j]);
		    for(int j=1;j<=c;j++)
		    	if(!(!sol.empty()&&sol.top()-64==j)&&x==dp[i][j])
		    		{
		    			sol.push(j+64);
		    			break;
		    		}			
		}		
		while(!sol.empty())
		{
			cout<<sol.top();
			sol.pop();
		}
}