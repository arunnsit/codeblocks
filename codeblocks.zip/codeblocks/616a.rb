require 'scanf'
a=scanf("%d")[0]
b=scanf("%d")[0]
if a==b
	printf("=")
end
if a>b
	printf(">")
end
if a<b
	printf("<")
end
else