#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
int dp[102][300000]={0};
int k,a[1000],b[1000];
int solve(int c,int sum)
{
	if(c<0&&sum==0)
		return 0;
	if(c<0)
		return -9999999;
	if(dp[c][sum+100000])
		return dp[c][sum+100000];
	int x=max(solve(c-1,sum+a[c]-k*b[c])+a[c],solve(c-1,sum));
	return dp[c][sum+100000]=x;
}
int main()
{
	int n,s;
	cin>>n>>k;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=0;i<n;i++)
		cin>>b[i];
	s=solve(n-1,0);
	if(s<=0)
		cout<<-1<<endl;
	else
	cout<<s<<endl;
}