#include<iostream>
#include<algorithm>
#include<math.h>
#include<map>
#include<set>
#include<vector>
#include<string>
#include<string.h>
#include<unordered_map>
#include<stdio.h>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,m,d,D;
		cin>>n>>m>>d>>D;
		if(D*n>=m&&m>=d*n)
		{
			int x=1,y=1,dif=0;
			while(m)
			{
				if(x==1)
				{
					y=x+dif;
					dif++;
				}
				cout<<x<<" "<<y<<"\n";
				x++;
				y++;
				if(x>n)
				{
					x=1;
				}
				if(y>n)
				{
					y=1;
				}
				m--;
			}
		}
		else cout<<-1<<"\n";
	}
}
