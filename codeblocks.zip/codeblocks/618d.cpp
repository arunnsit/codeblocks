#include<iostream>
#include<algorithm>
#include<vector>
#include<stack>
#define N 200000
using namespace std;	
vector<int>adj[N];
long long int count_leaf(int n)
{
	long long int c=0;
	for(int i=1;i<=n;i++)
	{
		if(adj[i].size()==1)
			c++;
	}
	return c;
}
int a,b;
stack<pair<int,int> >sexy;
long long int sexysol=0;
void dfs(int start,int parent,int x,int y)
{
	int check=0;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=parent&&!check){
		check++;
		sexysol+=x;
		dfs(adj[start][i],start,x,y);
	}
	else if(adj[start][i]!=parent)
	{
		sexy.push(make_pair(adj[start][i],parent));
		sexysol+=y;
	}
	if(check==0&&!sexy.empty())
	{
		a=sexy.top().first;
		b=sexy.top().second;
		sexy.pop();
		dfs(a,b,x,y);	
	}	
}
int main()
{
	long long int n,i,j,k,x,y,X,Y,rooty;
	cin>>n>>X>>Y;
	for(i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	for(i=1;i<=n;i++)
		if(adj[i].size()==1)
			rooty=i;
	if(X<=Y)
	{
		long long int coun=count_leaf(n);
		long long int sol=0;
		if(coun==2)
		{
			sol=(n-1)*X;
		}
		else
		{
			dfs(rooty,-1,X,Y);
			sol=sexysol;
		}
		cout<<sol<<endl;
	}
	else
	{
		long long int coun=count_leaf(n);
		long long int sol=0;
		if(n==2)
		{
			cout<<X<<endl;
		}
		else
		{	if(coun==n-1)
		{
			sol=(n-2)*Y+X;
		}
		else
		{
			sol=(n-1)*Y;
		}
		cout<<sol<<endl;
	}
	}

}