#include<iostream>
#include<stack>
#include<map>
#include<vector>
#include<algorithm>
#define N 100009
using namespace std;
map<pair<int,int>,int>ma,mop2;
stack<int>s;
int vis[N];
vector<int>adj[N];
void dfs(int u,int p)
{
	vis[u]=1;

	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&vis[adj[u][i]]==0){
		dfs(adj[u][i],u);
	}
	s.push(u);
}
vector<pair<int,int> >v;
int main()
{
	int n,m;
	cin>>n>>m;
	int x,y;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		v.push_back(make_pair(x,y));
		adj[x].push_back(y);
		ma[make_pair(x,y)]=1;
	}
	for(int i=1;i<=n;i++)
	if(!vis[i])
	{
		dfs(i,i);
	}
	x=s.top();
	s.pop();
	y=0;
	int ch=0,total=0;
	while(!s.empty())
	{
		y=s.top();
		if(!ma[make_pair(x,y)])ch=1;
		mop2[make_pair(x,y)]=1;
		total++;
		//cout<<x<<".."<<y<<endl;
		swap(x,y);
		s.pop();
	}
	if(ch){
		cout<<-1<<endl;
		return 0;
	}

	int i=0;
	for(i=0;i<m;i++)
	{
		if(mop2[v[i]])total--;
		if(!total)break;
	}
	cout<<i+1<<endl;
}
