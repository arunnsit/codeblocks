#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
using namespace std;
vector<int>v;
map<int,int>ma,value;
int a[100009],sol[1000009],arr[1000009][4],ar[1000009][4];
int bit[1000009][2];
void update(int pos,int add,int n,int o)
{
	if(pos<0)
	return;
	int ind=pos+1;
	while(ind<=n)
	{
		bit[ind][o]+=add;
			ind=ind+(ind&(-ind));
	}
}
int query(int pos,int o)
{
	if(pos<0)
	return 0;
	int ind=pos+1;
	int sum=0;
	while(ind!=0)
	{
		sum+=bit[ind][o];
		ind=ind-(ind&(-ind));
	}
	return sum;
}
vector<pair<int,int> >vos;

int main()
{
	int n,x,y,timer=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>x>>y;
		if(!value[x])
		{	
			value[x]=x;
		}
		if(!value[y])
		{	
			value[y]=y;
		}
		swap(value[x],value[y]);
	}
	for(map<int,int>::iterator it=value.begin();it!=value.end();it++)
	{
		v.push_back(it->first);
	}
	sort(v.begin(),v.end());
	for(int i=0;i<v.size();i++)
	{
		if(!ma[v[i]])
		{
			ma[v[i]]=timer++;
		}
	}
	long long int sol=0;
	for(map<int,int>::iterator it=value.begin();it!=value.end();it++)
	{
		vos.push_back(make_pair(it->first,it->second));
	}
	int prev=vos[vos.size()-1].first,val=vos[vos.size()-1].second;
	for(int i=vos.size()-1;i>=0;i--)
	{
		arr[ma[vos[i].first]][0]=query(ma[vos[i].first]-1,0);
		arr[ma[vos[i].first]][1]=query(timer-1,0)-query(ma[vos[i].first],0);
		arr[ma[vos[i].first]][2]=query(ma[vos[i].second],0);
		arr[ma[vos[i].first]][3]=query(timer-1,0)-query(ma[vos[i].second],0);
		if(vos[i].first<vos[i].second)
		{
			sol+=vos[i].second-vos[i].first-(arr[ma[vos[i].first]][3]-arr[ma[vos[i].second]][1])-(arr[ma[vos[i].first]][2]-arr[ma[vos[i].second]][0])+arr[ma[vos[i].first]][2];
		}
		else sol+=arr[ma[vos[i].first]][2];
		update(ma[vos[i].second],1,timer,0);
		//cout<<vos[i].first<<" "<<vos[i].second<<" "<<sol<<endl;
	}
	for(int i=0;i<vos.size();i++)
	{
		ar[ma[vos[i].first]][0]=query(ma[vos[i].first]-1,1);
		ar[ma[vos[i].first]][1]=query(timer-1,1)-query(ma[vos[i].first],1);
		ar[ma[vos[i].first]][2]=query(ma[vos[i].second],1);
		ar[ma[vos[i].first]][3]=query(timer-1,1)-query(ma[vos[i].second],1);
		if(vos[i].first>vos[i].second)
		{
			sol+=vos[i].first-vos[i].second-(ar[ma[vos[i].first]][3]-ar[ma[vos[i].second]][1])-(ar[ma[vos[i].first]][2]-ar[ma[vos[i].second]][0]);
		}
		update(ma[vos[i].second],1,timer,1);
	}
	cout<<sol<<endl;


}