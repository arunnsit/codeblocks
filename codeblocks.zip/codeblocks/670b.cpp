#include<iostream>
#include<vector>
using namespace std;
int arr[200000];
int main()
{
	long long int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>arr[i];
	}
	long long int term=1,to=1;
	for(int i=1;i<=n;i++)
	{
		if(k<=i)
		{
			break;
		}
		else
		{
			k-=i;
		}
	}
	cout<<arr[k]<<endl;
}