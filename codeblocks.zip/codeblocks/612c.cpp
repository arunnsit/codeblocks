#include<iostream>
#include<stack>
#include<string>
using namespace std;
stack<char>s;
int main()
{
	int c=0;
	string a;
	cin>>a;
	for(int i=0;i<a.length();i++)
	{
		if(a[i]=='<'||a[i]=='{'||a[i]=='['||a[i]=='(')
		{
			s.push(a[i]);
		}
		else if(!s.empty()) 
		{
			if(a[i]=='}')
			{
				
				if(s.top()!='{')
				{	
					c++;
				}
				s.pop();
			}
			if(a[i]==']')
			{
				
				if(s.top()!='[')
				{	
					c++;
				}
				s.pop();
			}
			if(a[i]=='>')
			{
				
				if(s.top()!='<')
				{	
					c++;
				}
				s.pop();
			}
			if(a[i]==')')
			{
				
				if(s.top()!='(')
				{	
					c++;
				}
				s.pop();
			}
		}
		else 
		{
			c=-1;
			break;
		}
	}
	if(s.empty()&&c!=-1)
		cout<<c<<endl;
	else cout<<"Impossible\n"<<endl;
}