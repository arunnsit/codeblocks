#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<stdio.h>
using namespace std;
int ar[1000];
vector<pair<int,int> >v;
int main()
{
	int n,x,ma,mp;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&ar[i]);
	}
	for(int i=0;i<n;i++)
	{
		ma=0;
		mp=0;
		for(int j=0;j<n-i;j++)
		{
			if(ma<=ar[j])
			{
				ma=ar[j];
				mp=j;
			}
		}
		for(int j=mp;j+1<n-i;j++)
		{
			swap(ar[j],ar[j+1]);
			v.push_back(make_pair(j+1,j+2));
		}
	}
	for(int i=0;i<v.size();i++)
	{
		printf("%d %d\n",v[i].first,v[i].second);
	}
}