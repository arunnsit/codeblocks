#include<iostream>
#include<algorithm>
#include<vector>
#include<map>
using namespace std;

#define N 5009
vector<int>adj[N];
int subtree[N][N]={0};
void input_tree_undir(int n)
{
	int x,y;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
}
int dfs(int u,int p,int mp)
{
	int x=0;
	for(int i=0;i<adj[u].size();i++)
		if(adj[u][i]!=p)
		{
			x+=dfs(adj[u][i],u,mp);
		}
	return subtree[mp][u]=x+1;
}
int mark[10000]={0};
int main()
{
	int n;
	cin>>n;
	input_tree_undir(n);
	for(int i=1;i<=n;i++)
		dfs(i,0,i);
	for(int i=1;i<=n;i++)
	{
		mark[0]=i;
		for(int j=0;j<adj[i].size();j++)
		{
			for(int k=n;k>=0;k--)
			if(mark[k]==i){
				mark[k+subtree[i][adj[i][j]]]=i;
			}
		}
	}
	int coun=0;
	for(int i=1;i<=n-2;i++)
	{
		if(mark[i])
			coun++;
	}
	cout<<coun<<endl;
	for(int i=1;i<=n-2;i++)
	{
		if(mark[i])
			cout<<i<<" "<<n-i-1<<endl;
	}
}