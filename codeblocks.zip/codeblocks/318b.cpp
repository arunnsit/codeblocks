#include<iostream>
#include<algorithm>
#include<math.h>
#include<string>
#include<string.h>
using namespace std;
string a,b="heavy",c="metal";
int main()
{
	long long int sol=0,co=0;
	cin>>a;
	for(int i=0;i<a.size();i++)
	{
		int j=0;
		for(j=0;j<b.size();j++)
		if(i+j>a.size()||b[j]!=a[i+j])break;
		if(j==b.size())
		{
			co++;
		}
		j=0;
		for(j=0;j<c.size();j++)
		if(i+j>a.size()||c[j]!=a[i+j])break;
		if(j==c.size())
		{
			sol+=co;
		}
	}
	cout<<sol<<endl;
}