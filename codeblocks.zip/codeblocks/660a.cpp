#include<iostream>
#include<algorithm>
#include<vector>
#include<math.h>
#include<set>
#include<string>
#include<string.h>
using namespace std;
int gcd(int a,int b)
{
	if(b==0)
		return a;
	return gcd(b,a%b);
}
int ar[1000];
vector<int>v;
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>ar[i];
	}
	v.push_back(ar[0]);
	for(int i=1;i<n;i++)
	{
		if(gcd(v.back(),ar[i])!=1)
		{
			v.push_back(1);
		}
		v.push_back(ar[i]);
	}
	cout<<v.size()-n<<endl;
	for(int i=0;i<v.size();i++)
		cout<<v[i]<<" ";
}