#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<math.h>
#include<vector>
#define N 200009
using namespace std;
int arr[N],level[N],in[N],out[N],vt=0;
vector<int> adj[N],anquery[N],sols;
vector<pair<int,int> >query;
int nextInt() {
    int x = 0, p = 1;
    char c;
    do {
        c = getchar();
    } while (c <= 32);
    if (c == '-') {
        p = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * p;
}
void dfs(int start,int len,int par)
{
	in[start]=++vt;
	level[start]=len;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=par){
		dfs(adj[start][i],len+1,start);
	}
	out[start]=vt;
}
void rebuild(int start,int parent,int adder)
{
   for(int i=0;i<anquery[start].size();i++)  
   adder+=anquery[start][i];
   anquery[start].clear();
   if(level[start]%2==0)
   arr[start]+=adder;
   else 
   arr[start]-=adder;
   for(int i=0;i<adj[start].size();i++)
   if(parent!=adj[start][i])
   rebuild(adj[start][i],start,adder);
}
int main()
{
	int n,x,y,q,blocks,type;
    int a,b,c,sol;
	n=nextInt();
	q=nextInt();
	for(int i=1;i<=n;i++)
		arr[i]=nextInt();
	for(int i=0;i<n-1;i++)
	{
		x=nextInt();
		y=nextInt();
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	blocks=6*sqrt(q);
	dfs(1,0,-1);
	while(q--)
	{
		type=nextInt();
        x=nextInt();
		if(type==2)
		{
			sol=arr[x];
			c=in[x];
			for(int i=0;i<query.size();i++)
			{
				a=in[query[i].first];
				b=out[query[i].first];
				if(c>=a&&c<=b&&(level[x]-level[query[i].first])%2)
                sol-=query[i].second;
                if(c>=a&&c<=b&&(level[x]-level[query[i].first])%2==0)
                sol+=query[i].second;
			}
			sols.push_back(sol);
		}
		else
		{
			y=nextInt();
			query.push_back(make_pair(x,y));
			if(level[x]%2==0)
			anquery[x].push_back(y);
		    else
		    anquery[x].push_back(-y);
		    if(query.size()==blocks)
		    {
		    	rebuild(1,-1,0);
		    	query.clear();
		    }
		}
	}
	for(int i=0;i<sols.size();i++)
		printf("%d\n",sols[i]);
}