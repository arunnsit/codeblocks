#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;
int dp[33][33][53]={0};
int solve(int x,int y,int k)
{
	//cout<<x<<" "<<y<<" "<<k<<endl; 
	if(x*y==k)
		return 0;
	if(x*y<k)
		return 99999999;
	if(k==0)
		return 0;
	if(dp[x][y][k]!=-1)
		return dp[x][y][k];
	int sol=99999999;
	for(int i=1;i<=x-i;i++)
		for(int j=0;j<=k;j++)
			sol=min(sol,solve(i,y,j)+solve(x-i,y,k-j)+y*y);
	for(int i=1;i<=y-i;i++)
		for(int j=0;j<=k;j++)
			sol=min(sol,solve(x,i,j)+solve(x,y-i,k-j)+x*x);	
	return dp[x][y][k]=sol;	
}
int main()
{
	std::ios::sync_with_stdio(false);
	int t;
	memset(dp,-1,sizeof(dp));
	solve(30,30,50);
	cin>>t;
	while(t--)
	{
		int x,y,k;
		cin>>x>>y>>k;
		cout<<solve(x,y,k)<<endl;
	}
}