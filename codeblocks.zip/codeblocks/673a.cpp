#include<iostream>
#include<algorithm>
using namespace std;
int arr[100];
int main()
{
	int n,x,y,z,i;
	cin>>n;
	arr[0]=0;
	for(int i=1;i<=n;i++)
		cin>>arr[i];
	arr[n+1]=90;
	for( i=1;i<=n+1;i++)
	{
		if(arr[i]-arr[i-1]>15)
		{
			break;
		}
	}
	cout<<min(90,arr[i-1]+15)<<endl;
}