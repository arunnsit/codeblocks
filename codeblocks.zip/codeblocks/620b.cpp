#include<iostream>
using namespace std;
int arr[10]={6,2,5,5,4,5,6,3,7,6};
int main()
{
	int a,b,temp;
	cin>>a>>b;
	long long int coun=0;
	for(int i=a;i<=b;i++)
	{
		temp=i;
		if(!temp)
		{
			coun+=6;
		}
		while(temp)
		{
			coun+=arr[temp%10];
			temp/=10;
		}
	}
	cout<<coun<<endl;
}