#include<iostream>
#include<vector>
using namespace std;
vector<int>years[500];
int main()
{
	for(int i=0;i<405;i++)
	{
		for(int j=0;j<13;j++)
		{
			years[i].push_back(0);
		}
	}
	int day=2,lim=0,c=0,tot=0;
	for(int i=1;i<=400;i++)
	{
		c=0;
		//if(i<5)
		//cout<<"tot:"<<tot<<" d:"<<day<<endl;
		//if(i==3)
		//	day=4;
		for(int j=1;j<=12;j++)
		{
			if(j==2)
			{
				if((i+1918)%400==0||((i+1918)%4==0&&(i+1918)%100!=0))
				lim=29;
			    else lim=28;
			}
			else
			{
				if(j<=7)
				{
					lim=30+((j)&1);
				}
				else
				{
					lim=30+(!((j)&1));
				}
			}
		    //cout<<i<<" "<<lim<<endl;	
			for(int k=1;k<=lim;k++)
			{
				//if(i==3&&k==13)
				//		cout<<j<<" "<<day<<endl;
				if(k==13&&day==4)
				{
					
				    c++;
			    }
			    tot++;
			    day=(day+1)%7;
		    }
		}
		years[i][c]++;
	//	cout<<i<<" "<<c<<endl;
	}
	//cout<<"day:"<<day<<endl;
	for(int i=1;i<=400;i++)
	{
		for(int j=0;j<13;j++)
		{
			years[i][j]+=years[i-1][j];
			//cout<<years[i][j]<<endl;
		}
	}
	//for(int j=0;j<13;j++)
	//	cout<<years[400][j]<<endl;
	int a,b;
	cin>>a>>b;
	a-=1919;
	b-=1918;
	int arr[15],brr[15];
	for(int j=0;j<13;j++)
		arr[j]=years[400][j]*(a/400)+years[a%400][j];

	for(int j=0;j<13;j++)
		brr[j]=years[400][j]*(b/400)+years[b%400][j];

	for(int j=0;j<=12;j++)
		cout<<j<<": "<<brr[j]-arr[j]<<endl;
}