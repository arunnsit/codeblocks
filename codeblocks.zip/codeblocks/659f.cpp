#include<iostream>
#include<math.h>
#include<algorithm>
#include<vector>
#define N 2000009
using namespace std;

int arr[1002][1002]={0},n,m,fil[1002][1002],fsol[1002][1002];
long long int k;
vector<pair<int,pair<int,int> > >v;

//****************
int P[N],siz[N];
void createset(int x)
{
	P[x]=x;
	siz[x]=1;
}
int find_parent(int x)
{
	if(x==P[x])
		return x;
	P[x]=find_parent(P[x]);
	return P[x];
}
void merge(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(v==u)
		return ;
	if(u>v)
	{
		P[u]=v;
		siz[v]+=siz[u];
		siz[u]=1;
	}
	else
	{
		P[v]=u;
		siz[u]+=siz[v];
		siz[v]=1;
	}
}
//****************
int dir[4][2]={{0,-1},{0,1},{1,0},{-1,0}},sol=-1,fillcoun=0;
void dfs(int x,int y)
{
	fsol[x][y]=sol;
	fillcoun--;
	for(int i=0;i<4;i++)
	{
		int nx=x+dir[i][0],ny=y+dir[i][1];
		if(nx>=0&&nx<n&&ny>=0&&ny<m&&fil[nx][ny]&&fillcoun&&fsol[nx][ny]==0)
		{
			dfs(nx,ny);
		}
	}
}
int encrypt(int x,int y)
{
	return x*m+y;
}
int main()
{
	std::ios::sync_with_stdio(false);
	cin>>n>>m>>k;

	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
		{
			cin>>arr[i][j];
			v.push_back(make_pair(arr[i][j],make_pair(i,j)));
		}
	sort(v.begin(),v.end());
	int x,y,x2=-1,y2=-1;
	for(int i=v.size()-1;i>=0;i--)
	{
		x=v[i].second.first;
		y=v[i].second.second;
		createset(encrypt(v[i].second.first,v[i].second.second));
		if(x-1>=0&&fil[x-1][y])
		{
			merge(encrypt(x-1,y),encrypt(x,y));
		}
		if(y-1>=0&&fil[x][y-1])
		{
			merge(encrypt(x,y-1),encrypt(x,y));
		}
		if(y+1<m&&fil[x][y+1])
		{
			merge(encrypt(x,y+1),encrypt(x,y));
		}
		if(x+1>=0&&fil[x+1][y])
		{
			merge(encrypt(x+1,y),encrypt(x,y));
		}
		fil[x][y]=1;
		if(siz[find_parent(encrypt(x,y))]>=k/v[i].first&&k%v[i].first==0)
		{
			sol=v[i].first;
			fillcoun=k/v[i].first;
			x2=x;
			y2=y;
			break;
		}
	}	
    if(sol>0)
    {
    	cout<<"YES"<<endl;
    	dfs(x2,y2);
    	for(int i=0;i<n;i++)
    	{
    		for(int j=0;j<m;j++)
    		{
    			cout<<fsol[i][j]<<" ";
    		}
    		cout<<endl;
    	}
    }
    else
    {
    	cout<<"NO\n";
    }
}