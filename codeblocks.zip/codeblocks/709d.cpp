#include<iostream>
#include<string>
#include<vector>
#define N 1000004
using namespace std;
vector<char>v[N];
int main()
{
	long long int a[2][2]={0},o=-1,z=-1;
	cin>>a[0][0]>>a[0][1]>>a[1][0]>>a[1][1];
	long long int c=0;
	for(int i=0;i<=1000000;i++)
	{
		c+=i;
		if(c==a[0][0])
		{
			z=i+1;
		}
		if(c==a[1][1])
		{
			o=i+1;
		}
	}
	if(a[0][1]==0&&a[1][0]==0)
	{
		if(z>=1&&o==1)
		{
			while(z--)
				{cout<<"0";}
			cout<<endl;
		}
		else if(o>1&&z==1)
		{
			while(o--)
				{cout<<"1";}
			cout<<endl;
		}
		else cout<<"Impossible\n";
	}
	else if(z==1&&o==1)
	{
		if(a[0][1]==1&&a[1][0]==0)
		{
			cout<<"01\n";
		}
		else if(a[1][0]==1&&a[0][1]==0)
		{
			cout<<"10\n";
		}
		else
		{
			cout<<"Impossible\n";
		}
	}
	else if(z==-1||o==-1)
	{
		cout<<"Impossible\n";
	}
	else
	{
		long long total=a[0][1]+a[1][0],os=o,zs=z,delta;
		string sol;
		//cout<<os<<".."<<zs<<endl;
		while(total-zs>=a[0][1])
		{
			sol.push_back('1');
			total-=zs;
			os--;
		}
		delta=zs-total+a[0][1];
		//cout<<sol<<"..\n";
		while(delta--)
		{
			sol.push_back('0');
			zs--;
		}
		if(os>=1)
		{os--;
		sol.push_back('1');}
		while(zs>0)
		{
			sol.push_back('0');
			zs--;
		}
		while(os>0)
		{
			sol.push_back('1');
			os--;
		}
		long long int x=0,y=0,c01=0,c10=0;
		for(int i=0;i<sol.size();i++)
		{
			if(sol[i]=='1')
			{
				x++;
				c01+=y;
			}
			else
			{
				y++;
				c10+=x;
			}
		}
		if(x==o&&y==z&&c01==a[0][1]&&c10==a[1][0])
		cout<<sol<<endl;
		else cout<<"Impossible\n";
	}
}