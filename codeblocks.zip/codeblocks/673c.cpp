#include<stdio.h>
#include<vector>
using namespace std;
vector<int>v;
int solution[6000]={0};
int mac[50000]={0};

int main()
{
	int n,x;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&x);
		v.push_back(x);
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
			mac[j]=0;
		int mn=0,mv=0;
		for(int j=i;j<n;j++)
		{
			mac[v[j]-1]++;
			if(mac[v[j]-1]>mv)
			{
				mv=mac[v[j]-1];
				mn=v[j]-1;
			}
			else if(mac[v[j]-1]==mv&&v[j]-1<mn)
			{
				mv=mac[v[j]-1];
				mn=v[j]-1;
			}
			solution[mn]++;
		}
	}
	for(int i=0;i<n;i++)
		printf("%d ",solution[i]);
}