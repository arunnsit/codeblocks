#include<iostream>
#include<math.h>
#include<queue>
#include<algorithm>
#define N 100008
using namespace std;
int a[N],marks[500][100005],sexy_r,sexy_l,block;
queue<int> qu[500],q1;
void right(int x)
{
	
	int y=(x-1)%block+1,u=(x-1)/block+1;
	int p=qu[u].size()-y;

	while(p--)
	{
		q1.push(qu[u].front());
		qu[u].pop();
	}
	sexy_r=qu[u].front();
	
	marks[u][sexy_r]--;

	qu[u].pop();

	while(!qu[u].empty())
	{
		q1.push(qu[u].front());
		qu[u].pop();
	}
	while(!q1.empty())
	{
		qu[u].push(q1.front());
		q1.pop();
	}

}
void left(int y,int op)
{

	int o=(y-1)%block+1,u=(y-1)/block+1;
	int o2=(op-1)/block+1;
	int p=qu[u].size()-o;
	//if(o2==u)
	//	p++;
	//cout<<p<<endl;
	while(p--)
	{
		q1.push(qu[u].front());
		qu[u].pop();
	}

	q1.push(qu[u].front());
		qu[u].pop();
	q1.push(sexy_r);
	marks[u][sexy_r]++;
	while(!qu[u].empty())
	{
		q1.push(qu[u].front());
		qu[u].pop();
	}
	while(!q1.empty())
	{
		qu[u].push(q1.front());
		q1.pop();
	}
}
int sol_rdel(int x,int z)
{
	queue<int> q1;
	int y=(x-1)%block+1,u=(x-1)/block+1;
	int p=qu[u].size()-y;
	int coun=0;
	while(p--)
	{
		q1.push(qu[u].front());
		if(qu[u].front()==z)
			coun++;
		qu[u].pop();
	}
	while(!qu[u].empty())
	{
		q1.push(qu[u].front());
		qu[u].pop();
	}
	while(!q1.empty())
	{
		qu[u].push(q1.front());
		q1.pop();
	}
	return coun;
}
int sol_ldel(int x,int z)
{
	queue<int> q1;
	int y=(x-1)%block+1,u=(x-1)/block+1;
	int p=qu[u].size()-y;
	int coun=0;
	while(p--)
	{
		q1.push(qu[u].front());	
		qu[u].pop();
	}
	q1.push(qu[u].front());
		qu[u].pop();
	while(!qu[u].empty())
	{
		q1.push(qu[u].front());
		if(qu[u].front()==z)
			coun++;
		qu[u].pop();
	}
	while(!q1.empty())
	{
		qu[u].push(q1.front());
		q1.pop();
	}
	return coun;
}
int main()
{
	int n,m,x,y,z;
	cin>>n;
	block=sqrt(n);
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=n;i>=1;i--)
	{
		qu[(i-1)/block+1].push(a[i]);
		marks[(i-1)/block+1][a[i]]++;
		//cout<<"block:"<<(i-1)/block+1<<" "<<qu[(i-1)/block+1].front()<<endl;
	}
	cin>>m;
	int type,u,v,lans=0,x1,y1,z1,o1,o2;
	while(m--)
	{
		cin>>type;
		if(type==1)
		{
			cin>>x1>>y1;
			o1=((x1+lans-1)%n)+1;
			o2=((y1+lans-1)%n)+1;
			x=min(o1,o2);
			y=max(o1,o2);
			u=(x-1)/block+1;
			v=(y-1)/block+1;
			if(x!=y)
			{
			right(y);
			left(x,y);
		}
			for(int i=u;i<v;i++)
			{
				marks[i][qu[i].front()]--;
				marks[i+1][qu[i].front()]++;
				qu[i+1].push(qu[i].front());
				qu[i].pop();
			}
			/*for(int i=n;i>=1;i--)
	        { 
		         cout<<"block:"<<(i-1)/block+1<<" "<<qu[(i-1)/block+1].front()<<endl;
	        }*/
		}
		else
		{
			cin>>x1>>y1>>z1;
			o1=((x1+lans-1)%n)+1;
			o2=((y1+lans-1)%n)+1;
			z=((z1+lans-1)%n)+1;
			x=min(o1,o2);
			y=max(o1,o2);
			u=(x-1)/block+1;
			v=(y-1)/block+1;
			int sol=0;
			for(int i=u;i<=v;i++)
			{
				sol+=marks[i][z];
			}
			cout<<sol-sol_rdel(y,z)-sol_ldel(x,z)<<" "<<endl;
			lans=sol-sol_rdel(y,z)-sol_ldel(x,z);
		}
	}

}