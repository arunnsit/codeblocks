#include <cstdio>
#include <climits>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct flow_graph{
    int MAX_V,E,s,t,head,tail;
    int *cap,*to,*next,*last,*dist,*q,*now;
    
    flow_graph(){}
    
    flow_graph(int V, int MAX_E){
        MAX_V = V; E = 0;
        cap = new int[2*MAX_E], to = new int[2*MAX_E], next = new int[2*MAX_E];
        last = new int[MAX_V], q = new int[MAX_V], dist = new int[MAX_V], now = new int[MAX_V];
        fill(last,last+MAX_V,-1);
    }
    
    void clear(){
        fill(last,last+MAX_V,-1);
        E = 0;
    }
    
    void add_edge(int u, int v, int uv, int vu = 0){
        to[E] = v, cap[E] = uv, next[E] = last[u]; last[u] = E++;
        to[E] = u, cap[E] = vu, next[E] = last[v]; last[v] = E++;
    }
	
	bool bfs(){
		fill(dist,dist+MAX_V,-1);
		head = tail = 0;
		
		q[tail] = t; ++tail;
		dist[t] = 0;
		
		while(head<tail){
			int v = q[head]; ++head;
			
			for(int e = last[v];e!=-1;e = next[e]){
				if(cap[e^1]>0 && dist[to[e]]==-1){
					q[tail] = to[e]; ++tail;
					dist[to[e]] = dist[v]+1;
				}
			}
		}
		
		return dist[s]!=-1;
	}
	
	int dfs(int v, int f){
		if(v==t) return f;
		
		for(int &e = now[v];e!=-1;e = next[e]){
			if(cap[e]>0 && dist[to[e]]==dist[v]-1){
				int ret = dfs(to[e],min(f,cap[e]));
				
				if(ret>0){
					cap[e] -= ret;
					cap[e^1] += ret;
					return ret;
				}
			}
		}
		
		return 0;
	}
	
	long long max_flow(int source, int sink){
		s = source; t = sink;
		long long f = 0;
		int x;
		
		while(bfs()){
			for(int i = 0;i<MAX_V;++i) now[i] = last[i];
			
			while(true){
				x = dfs(s,INT_MAX);
				if(x==0) break;
				f += x;
			}
		}
		
		return f;
	}
}G;
int prefix[100000][5]={0};
vector<pair<int,int> >v,v2;
int main(){
	int V,E,c,n,b,q,x,y,ch=0;
	cin>>n>>b>>q;
	v.push_back(make_pair(0,0));
	for(int i=1;i<=30000;i++)
	{
		for(int j=0;j<=4;j++)
		{
			prefix[i][j]+=prefix[i-1][j];
		}
		prefix[i][i%5]++;
	}
	while(q--)
	{
		cin>>x>>y;
		v.push_back(make_pair(x,y));
	}
	sort(v.begin(),v.end());
	v.push_back(make_pair(b,n));
	for(int i=1;i<v.size();i++)
	{
		v2.push_back(make_pair(v[i].first,v[i].second-v[i-1].second));
		if(v[i].second-v[i-1].second<0)
		{
			ch=1;
		}
	}
	//v2.push_back(make_pair(b,n-v[v.size()-1].second));	
	if(ch)
	{
		cout<<"unfair\n";
	}
	else
	{
		G = flow_graph(2+5+v2.size(),5+6*v2.size());
		//cout<<"...\n";
		for(int i=1;i<=5;i++)
		{
			G.add_edge(0,i,n/5);
			//cout<<0<<" "<<i<<" "<<n/5<<endl;
		}
		for(int i=0;i<v2.size();i++)
		{
			if(i==0)
			{
				for(int j=0;j<=4;j++)
				{
					if(prefix[v2[i].first][j])
					G.add_edge(j+1,i+6,prefix[v2[i].first][j]);
					//cout<<j+1<<" "<<i+6<<" "<<prefix[v2[i].first][j]<<endl;
				}
			}
			else
			{
				for(int j=0;j<=4;j++)
				{
					if(prefix[v2[i].first][j]-prefix[v2[i-1].first][j])
					G.add_edge(j+1,i+6,prefix[v2[i].first][j]-prefix[v2[i-1].first][j]);
					//cout<<j+1<<" "<<i+6<<" "<<prefix[v2[i].first][j]-prefix[v2[i-1].first][j]<<endl;
				}
			}
		}
		
		for(int i=0;i<v2.size();i++)
		{
			if(v2[i].second)
			G.add_edge(i+6,v2.size()+6,v2[i].second);
			//aa<<i+6<<" "<<v2.size()+6<<" "<<v2[i].second<<endl;
		}
		//cout<<"flow:"<<G.max_flow(0,v2.size()+6)<<" "<<G.max_flow(0,v2.size()+6)<<endl;
		if(G.max_flow(0,v2.size()+6)==n)
		{
			cout<<"fair\n";
		}
		else cout<<"unfair\n";
	}
	return 0;
}