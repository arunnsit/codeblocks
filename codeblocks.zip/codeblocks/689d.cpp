#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<math.h>
#include<vector>
#include<map>
#define N 200009
using namespace std;
struct node
{
	int mi,ma;
};
int a[N],b[N];
int dx[20][1 << 20];//max
int dy[20][1 << 20];//min
int lg[1 << 20];
int mx(int l,int r)
{
    int p = lg[r - l + 1];
    return max(dx[p][l],dx[p][r - (1 << p) + 1]);
}
int mn(int l,int r)
{
    int p = lg[r - l + 1];
    return min(dy[p][l],dy[p][r - (1 << p) + 1]);
}
void comp(int a[N],int b[N],int n)
{
    for (int i = 1;i <= n;++i) dx[0][i]=a[i];
    for (int i = 1;i <= n;++i) dy[0][i]=b[i];
    for (int p = 1;(1 << p) <= n;++p)
        for (int i = 1;i + (1 << p) - 1 <= n;++i)
            dx[p][i] = max(dx[p-1][i],dx[p-1][i + (1 << (p-1))]),
            dy[p][i] = min(dy[p-1][i],dy[p-1][i + (1 << (p-1))]);
    for (int i = 2;i <= n;++i)
        lg[i] = lg[i >> 1] + 1;
}
int main()
{
	int n,l,r,mid,rmax,rmin;
	node temp;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
	long long int sol=0;
	comp(a,b,n);
	for(int i=0;i<n;i++)
	{
		l=i;
		r=n-1;
		rmin=n;
		rmax=-1;
		while(1)
		{
			mid=l+(r-l)/2;
			temp.ma=mx(i+1,mid+1);
			temp.mi=mn(i+1,mid+1);
			if(temp.ma-temp.mi==0)
			{
				rmin=min(rmin,mid);
				r=mid-1;
			}
			else if(temp.ma-temp.mi<0)
			{
				l=mid+1;
			}
			else
			{
				r=mid-1;
			}
			if(l>r||mid<i)
			{
				break;
			}
		}
		l=i;
		r=n-1;
		while(1)
		{
			mid=l+(r-l)/2;
			temp.ma=mx(i+1,mid+1);
			temp.mi=mn(i+1,mid+1);
			if(temp.ma-temp.mi==0)
			{
				rmax=max(rmax,mid);
				l=mid+1;
			}
			else if(temp.ma-temp.mi<0)
			{
				l=mid+1;
			}
			else
			{
				r=mid-1;
			}
			if(l>r||mid<i)
			{
				break;
			}
		}
		//cout<<"i:"<<i<<" "<<rmin<<" "<<rmax<<endl;
		if(rmin<n)
		sol+=rmax-rmin+1;
	}
	printf("%lld\n",sol);
}