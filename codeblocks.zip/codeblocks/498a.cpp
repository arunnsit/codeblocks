#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
struct line 
{
	double a,b,c;
};
vector<line>v;
line temp;
vector<double>trip;
int main()
{
	double hx,hy,ux,uy,x,y,z;
	cin>>hx>>hy>>ux>>uy;
	int n,dist=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		line temp;
		cin>>temp.a>>temp.b>>temp.c;
		z=temp.c;
		x=temp.a*hx+temp.b*hy+temp.c;
		y=temp.a*ux+temp.b*uy+temp.c;
		if((x<0&&y<0)||(x>0&&y>0))
		{
		}
		else dist++;
	}
	cout<<dist<<endl;
	
}