#include<iostream>
#include<set>
#include<algorithm>
#include<math.h>
#include<string>
using namespace std;
int main()
{
	string a;
	int n,p,q,x=-1,y=-1;
	cin>>n>>p>>q;
	cin>>a;
	for(int i=0;i<=n;i++)
		if((n-p*i)%q==0&&n-p*i>=0)
		{
			x=i;
			y=(n-p*i)/q;
			break;
		}
	//cout<<x<<" "<<y<<endl;	
	if(x==-1)
	cout<<x<<endl;
	else 
	{
		cout<<x+y<<endl;
		int u=0;
		for(int i=0;i<x;i++)
			{
				for(int j=0;j<p;j++)
			{
				cout<<a[u];
				u++;
			}
			cout<<endl;
		}
		for(int i=0;i<y;i++)
			{
				for(int j=0;j<q;j++)
			{
				cout<<a[u];
				u++;
			}
			cout<<endl;
		}
	}	
}