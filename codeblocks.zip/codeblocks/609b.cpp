#include<iostream>
#include<algorithm>
#include<unordered_map>
using namespace std;
unordered_map<int ,int>ma;
int arr[100009];
int main()
{
	int n,m,c=0,z,a[15]={0};
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
		a[arr[i]]++;
	}
	for(int i=0;i<=m;i++)
	for(int j=i+1;j<=m;j++)
		c+=a[i]*a[j];
	cout<<c<<endl;
}