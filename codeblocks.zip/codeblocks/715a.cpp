#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<math.h>
#include<map>
using namespace std;
int main()
{
	long long int n,x=2,r1,r2,p,popi;
	cin>>n;
	for(long long int k=1;k<=n;k++)
	{
		popi=k*(k+1)*(k+1)-x/k;
		x=k*(k+1);
		cout<<popi<<endl;
	}

}