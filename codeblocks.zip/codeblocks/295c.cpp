#include<iostream>
#include<algorithm>
#include<set>
#include<string.h>
using namespace std;
int F,H,K;
int dp[55][55][2]={0};
pair<int,int>hold[55][55][2];
long long int mod=1000000007;
long long int nc[55][55]={0};
long long int ncr(int n,int r)
{
	if(n==r)
		return 1;
	if(r==1)
		return n;
	if(r==0)
		return 1;
	if(nc[n][r])
		return nc[n][r];
	return nc[n][r]=(ncr(n-1,r-1)+ncr(n-1,r))%mod;
}
long long int dps[52][52][200][2]={0};
long long int ways(int f,int h,int l,int p)
{
	if(f==0&&h==0&&l==0&&p==1)
		return 1;
	if(l==0)
		return 0;
	if(dps[f][h][l][p]!=-1)
		return dps[f][h][l][p];
	long long int sol=0;
	if(p==0)
	{
		for(int i=0;i<=f;i++)
			for(int j=0;j<=h;j++)
				if(!(i==0&&j==0)&&i*50+j*100<=K)
				{
					sol=(sol+(((ncr(f,i)*ways(f-i,h-j,l-1,p^1))%mod)*ncr(h,j))%mod)%mod;
				}
	}
	else
	{
		for(int i=0;i<=F-f;i++)
			for(int j=0;j<=H-h;j++)
				if(!(i==0&&j==0)&&i*50+j*100<=K)
				{
					sol=(sol+(((ncr(F-f,i)*ways(f+i,h+j,l-1,p^1))%mod)*ncr(H-h,j))%mod)%mod;
				}
	}
	return dps[f][h][l][p]=sol;

}
int main()
{
	int n,k,f=0,h=0,tmp;
	cin>>n>>K;
	memset(dps,-1,sizeof(dps));
	for(int i=0;i<n;i++)
	{
		cin>>tmp;
		if(tmp==50)
			F++;
		else H++;
	}
	for(int i=0;i<=n;i++)
		for(int j=0;j<=n;j++)
			dp[i][j][0]=100000000,dp[i][j][1]=100000000;
	set<pair<int,pair<pair<int,int>,int> > >s;
	s.insert(make_pair(0,make_pair(make_pair(F,H),0)));
	dp[F][H][0]=0;
	hold[F][H][0]=make_pair(-1,-1);
	int cf,ch,cp,cd;
	while(!s.empty())
	{
		cd=(*s.begin()).first;
		cf=(*s.begin()).second.first.first;
		ch=(*s.begin()).second.first.second;
		cp=(*s.begin()).second.second;
		s.erase(s.begin());
		//cout<<cd<<" "<<cf<<" "<<ch<<" "<<cp<<endl;
		if(cd==dp[cf][ch][cp])
		{
			if(cp==0)
			{
				for(int i=0;i<=cf;i++)
				{
					for(int j=0;j<=ch;j++)
					if(!(i==0&&j==0)){
						if(dp[cf-i][ch-j][1]>cd+1&&i*50+j*100<=K)
						{
							dp[cf-i][ch-j][1]=cd+1;
							hold[cf-i][ch-j][1]=make_pair(cf,ch);
							s.insert(make_pair(cd+1,make_pair(make_pair(cf-i,ch-j),1)));
						}
					}
				}
			}
			else
			{
				if(F-cf)
				{
					if(dp[cf+1][ch][0]>cd+1&&K>=50)
					{
						dp[cf+1][ch][0]=cd+1;
						hold[cf+1][ch][0]=make_pair(cf,ch);
						s.insert(make_pair(cd+1,make_pair(make_pair(cf+1,ch),0)));
					}
				}
				if(H-ch)
				{
					if(dp[cf][ch+1][0]>cd+1&&K>=100)
					{   dp[cf][ch+1][0]=cd+1;
						hold[cf][ch+1][0]=make_pair(cf,ch);
						s.insert(make_pair(cd+1,make_pair(make_pair(cf,ch+1),0)));
					}
				}
			}
		}
	} 
	if(dp[0][0][1]==100000000)
	{
		cout<<-1<<endl<<0<<endl;
	}
	else
	{
		cout<<dp[0][0][1]<<endl;

		cout<<ways(F,H,dp[0][0][1],0)<<endl;
	}

}