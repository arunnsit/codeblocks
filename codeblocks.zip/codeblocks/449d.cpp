#include<iostream>
using namespace std;
int freq[1<<20],g[1<<20];
int pow_bhaji(int base, int exponent, int mod)
{
    int x = 1;
    int y = base;
    while (exponent > 0)
    {
        if (exponent % 2 == 1)
            x = (x*1ll* y) % mod;
        y = (y *1LL* y) % mod;
        exponent = exponent / 2;
    }
    return x % mod;
}
int mod=1000000007;
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		freq[x]++;
	}
	for(int i=0;i<20;i++)
		for(int j=(1<<20)-1;j>=0;j--)
		if((j&(1<<i))==0)
		{
			freq[j]+=freq[j^(1<<i)];
		}
	for(int j=(1<<20)-1;j>=0;j--)
	g[j]=(pow_bhaji(2,freq[j],mod)-1+mod)%mod;
	
	for(int i=0;i<20;i++)
	for(int j=(1<<20)-1;j>=0;j--)
		if((j&(1<<i))==0)
		{
			g[j]=(g[j]-g[j^(1<<i)]+mod)%mod;
		}
	cout<<g[0]<<endl;		
}