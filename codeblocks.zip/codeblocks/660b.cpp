#include<iostream>
#include<algorithm>
#include<vector>
#include<math.h>
#include<set>
#include<string>
#include<string.h>
using namespace std;
int n,m;
int ar[200][4]={0};
int main()
{
	cin>>n>>m;
	int ctr=0;
	for(int i=1;i<=n;i++)
	{
		if(ctr<m)
		ar[i][0]=ctr++ +1;
		if(ctr<m)
		ar[i][3]=ctr++ +1;	
	}
	for(int i=1;i<=n;i++)
	{
		if(ctr<m)
		ar[i][1]=ctr++ +1;
		if(ctr<m)
		ar[i][2]=ctr++ +1;	
	}
	for(int i=1;i<=n;i++)
	{
		if(ar[i][1])
			cout<<ar[i][1]<<" ";
		if(ar[i][0])
			cout<<ar[i][0]<<" ";
		if(ar[i][2])
			cout<<ar[i][2]<<" ";
		if(ar[i][3])
			cout<<ar[i][3]<<" ";
	}
}