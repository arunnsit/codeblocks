#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<int>div1,div2,leftovers;
int ar1[100090],ar2[100090];
int main()
{
	int n,x,y,z,m,ch=0;
	long long int sol=0;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		if(ar2[max(x,y)]||ar1[min(x,y)])
		{
			ch=1;
		}
		ar1[max(x,y)]++;
		ar2[min(x,y)]++;
		div1.push_back(max(x,y));
		div2.push_back(min(x,y));
	}
	for(int i=1;i<=n;i++)
	{
		if(ar1[i]==0&&ar2[i]==0)
		{
			leftovers.push_back(i);
		}
	}
	int max1=0,max2=0,min1=n+1,min2=n+1;
	for(int i=0;i<div1.size();i++)
	{
		max1=max(max1,div1[i]);
		min1=min(min1,div1[i]);
	}
	for(int i=0;i<div2.size();i++)
	{
		max2=max(max2,div2[i]);
		min2=min(min2,div2[i]);
	}
	if(ch||max2>min1)
		cout<<0<<endl;
	else 
	{
		int trol=0,trol2=0;
		for(int i=0;i<leftovers.size();i++)
		{
			if(leftovers[i]<min1&&leftovers[i]>max2)
			{
				trol++;
			}
		}
		if(div1.size()&&div2.size())
		{
			cout<<trol+1<<endl;
		}
		else if(div1.size()||div2.size())
		{
			cout<<trol<<endl;
		}
		else
			cout<<trol-1<<endl;

	}
}