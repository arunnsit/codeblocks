#include<iostream>
#include<set>
#include<math.h>
#include<algorithm>
#include<vector>
#include<stdio.h>
using namespace std;
int a[20003];
vector<pair<int,pair<float,int> > >rs[20003];
vector<int>p[100];
int posis[65]={0};
set<pair<int,int> >s;
int sols[200003],pows[200][200],cs[100][100]={0};
float logger[100];
int main()
{
	int n,m,mod=1000000007,x;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=90;i++)
	{
		logger[i]=log(i);
	}
	for(int i=1;i<=100;i++)
	{
		pows[i][0]=1;
		for(int j=1;j<=100;j++)
		{
			pows[i][j]=(i*1LL*pows[i][j-1])%mod;
		}
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=2;i<=60;i++)
	if(!p[i].size())
	{
		for(int j=i;j<=60;j+=i)
		{
			p[j].push_back(i);
			x=j;
			while(x%i==0)
			{
				cs[j][i]++;
				x/=i;
			}
		}
	}
	set<pair<int,int> >::iterator temp,it;
	int lcms[100]={0};
	float lcs=0;
	int prev=-1,aclcm=1,c;
	for(int i=n;i>=1;i--)
	{
		if(posis[a[i]])
		s.erase(s.find(make_pair(posis[a[i]],a[i])));
		posis[a[i]]=i;
		s.insert(make_pair(i,a[i]));
		for(int j=0;j<=60;j++)
		lcms[j]=0;
		lcs=0;
		prev=-1,aclcm=1;
		for(it=s.begin();it!=s.end();it++)
		{
			temp=it;
			x=it->second;
			for(int j=0;j<p[it->second].size();j++)
			{
				c=cs[it->second][p[it->second][j]];
				if(lcms[p[it->second][j]]<c)
				{
					lcs+=(1.0*(c-lcms[p[it->second][j]])*logger[p[it->second][j]]);
					aclcm=(aclcm*1LL*pows[p[it->second][j]][c-lcms[p[it->second][j]]])%mod;
					lcms[p[it->second][j]]=c;
				}
			}
			temp++;
			if(temp!=s.end())
			{
				rs[it->first-i+1].push_back(make_pair(1,make_pair(lcs,aclcm)));
				rs[temp->first-i].push_back(make_pair(-1,make_pair(lcs,aclcm)));
			}
			else
			{
				rs[it->first-i+1].push_back(make_pair(1,make_pair(lcs,aclcm)));
				rs[n-i+1].push_back(make_pair(-1,make_pair(lcs,aclcm)));
			}
		}
	}
	multiset<pair<float,int> >ms;
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<rs[i].size();j++)
		if(rs[i][j].first==1){
			ms.insert(rs[i][j].second);
		}
		sols[i]=(*ms.begin()).second;
		for(int j=0;j<rs[i].size();j++)
		if(rs[i][j].first==-1){
			ms.erase(ms.find(rs[i][j].second));
		}
	}
	while(m--)
	{
		scanf("%d",&x);
		printf("%d\n",sols[x]);
	}
}