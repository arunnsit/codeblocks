#include<stdio.h>
#include<unordered_map>
using namespace std;
unordered_map<int,int>mapy;
int arr[200009],arr2[200009];
int main()
{
	int n,m,tmp,x=0,y=0;
	long long int sum=0,sum2=0;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		mapy[arr[i]]++;
	}
	scanf("%d",&m);
	for(int i=0;i<m;i++)
	{
		scanf("%d",&arr2[i]);
	}
	for(int i=0;i<m;i++)
	{
		scanf("%d",&tmp);
		if(mapy[arr2[i]]>sum||(mapy[arr2[i]]==sum&&sum2<mapy[tmp]+mapy[arr2[i]]))
        {
        	sum=mapy[arr2[i]];
        	sum2=mapy[tmp]+mapy[arr2[i]];
            x=i;
        }
	}
	printf("%d\n",x+1);

}