#include<iostream>
#include<map>
#include<vector>
#include<algorithm>
#define N 200009
using namespace std;
long long int mod=1000000007;
long long int pow_bhaji(long long int x,long long int y)
{
	long long int w;
	if(y==0)
		return 1;
	if(y&1)
		{
			w=pow_bhaji(x,(y-1)/2)%mod;
			return (((x*w)%mod)*w)%mod;
		}
	else 
		{
			w=pow_bhaji(x,(y)/2)%mod;
			return (w*w)%mod;
		}
}
map<long long int,long long int>ma;
long long int nk[N];
int main()
{
	long long int n,k,x,y,c=0;
	long long int sol=0;
	cin>>n>>k;
	nk[k]=1;
	for(int i=k+1;i<=n;i++)
	{
		nk[i]=(((nk[i-1]*(i))%mod)*pow_bhaji(i-k,mod-2))%mod;
	}
	for(int i=0;i<n;i++)
	{
		cin>>x>>y;
		ma[x]++;
		ma[y+1]--;
	}
	for(map<long long int,long long int>::iterator prev,it=ma.begin();it!=ma.end();it++)
	{
		//cout<<it->first<<" "<<c<<endl;
		if(it!=ma.begin())
		{
			if(c>=k)
			{
				sol=(sol+1LL*(it->first-prev->first)*nk[c])%mod;
			}
		}
		c+=it->second;
		prev=it;
	}
	cout<<sol<<endl;
}