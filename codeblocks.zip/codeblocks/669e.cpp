#include<iostream>
#include<unordered_map>
#include<vector>
#include<algorithm>
using namespace std;
struct query
{
	int type,time,val;
};
unordered_map<int,int>compress_vals,compress_time[200000];
vector<int>v[200000],tree[200000];
query q[200000];
void  update(int curr,int l,int r,int val,int tre,int point)
{
	if(l==r)
	{
		tree[tre][curr]+=val;
		return ;
	}
	int mid=l+(r-l)/2;
	if(point>mid)
	{
		update(2*curr+2,mid+1,r,val,tre,point);
	}
	else
	{
		update(2*curr+1,l,mid,val,tre,point);
	}
	tree[tre][curr]=tree[tre][2*curr+1]+tree[tre][2*curr+2];
}
int query(int curr,int l,int r,int tre ,int x,int y)
{
	if(x<=l&&r<=y)
		return tree[tre][curr];
	if(r<x||y<l)
		return 0;
	int mid=l+(r-l)/2;
	return query(2*curr+1,l,mid,tre,x,y)+query(2*curr+2,mid+1,r,tre,x,y);
}
int main()
{
	int n,diff_vals=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>q[i].type>>q[i].time>>q[i].val;
		if(!compress_vals[q[i].val])
			compress_vals[q[i].val]=++diff_vals;

		v[compress_vals[q[i].val]].push_back(q[i].time);
	}
	for(int i=1;i<=diff_vals;i++)
		sort(v[i].begin(),v[i].end());
	for(int i=1;i<=diff_vals;i++)
	{
		for(int j=0;j<v[i].size();j++)
		compress_time[i][v[i][j]]=j+1;
	    for(int j=0;j<=v[i].size()*10;j++)
	    	tree[i].push_back(0);
	}
	for(int i=0;i<n;i++)
	{
		//cout<<"compress_vals:"<<compress_vals[q[i].val]<<" compress_time:"<<compress_time[compress_vals[q[i].val]][q[i].time]<<endl;
		if(q[i].type==1)
		{
			update(0,0,v[compress_vals[q[i].val]].size()-1,1,compress_vals[q[i].val],compress_time[compress_vals[q[i].val]][q[i].time]-1);
		}
		else if(q[i].type==2)
		{
			update(0,0,v[compress_vals[q[i].val]].size()-1,-1,compress_vals[q[i].val],compress_time[compress_vals[q[i].val]][q[i].time]-1);
		}
		else
		{
			cout<<query(0,0,v[compress_vals[q[i].val]].size()-1,compress_vals[q[i].val],0,compress_time[compress_vals[q[i].val]][q[i].time]-1)<<endl;
		}
	}
}