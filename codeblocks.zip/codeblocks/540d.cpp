#include<iostream>
#include<iomanip>
using namespace std;
long double dp[102][102][102],dp2[102][102][102],dp3[102][102][102];
long double solve_rock(int r,int s,int p)
{
	if(r<=0||s<0||p<0)
	return 0;
	if(r&&s==0&&p==0)
	{
		return 1.0;
	}
	if(dp[r][s][p])
		return dp[r][s][p];
	long double so=0,d=0,a=r,b=s,c=p;
	if(r&&s)
		so+=solve_rock(r,s-1,p)*(a*b/(a*b+b*c+c*a));
	if(p&&s)
		so+=solve_rock(r,s,p-1)*(b*c/(a*b+b*c+c*a));	
	if(p&&r)
		so+=solve_rock(r-1,s,p)*(a*c/(a*b+b*c+c*a));		
	return dp[r][s][p]=so;			
}
long double solve_s(int r,int s,int p)
{
	if(r<0||s<=0||p<0)
	return 0;
	if(r==0&&s&&p==0)
	{
		return 1.0;
	}
	if(dp2[r][s][p])
		return dp2[r][s][p];
	double so=0,a=r,b=s,c=p;
	if(r&&s)
		so+=solve_s(r,s-1,p)*(a*b/(a*b+b*c+c*a));
	if(p&&s)
		so+=solve_s(r,s,p-1)*(b*c/(a*b+b*c+c*a));	
	if(p&&r)
		so+=solve_s(r-1,s,p)*(a*c/(a*b+b*c+c*a));		
	return dp2[r][s][p]=so;			
}
long double solve_p(int r,int s,int p)
{
	if(r<0||s<0||p<=0)
	return 0;
	if(r==0&&s==0&&p)
	{
		return 1.0;
	}
	if(dp3[r][s][p])
		return dp3[r][s][p];
	long double so=0,a=r,b=s,c=p;
	if(r&&s)
		so+=solve_p(r,s-1,p)*(a*b/(a*b+b*c+c*a));
	if(p&&s)
		so+=solve_p(r,s,p-1)*(b*c/(a*b+b*c+c*a));	
	if(p&&r)
		so+=solve_p(r-1,s,p)*(a*c/(a*b+b*c+c*a));		
	return dp3[r][s][p]=so;			
}
int main()
{
cout<<fixed;
	int r,s,p;
	cin>>r>>s>>p;
	cout<<setprecision(10)<<solve_rock(r,s,p)<<" "<<solve_s(r,s,p)<<" "<<solve_p(r,s,p)<<endl;
}