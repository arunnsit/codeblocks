#include<iostream>
using namespace std;
long long int gcd(long long int a,long long int b)
{
	if(b==0)return a;
	else return gcd(b,a%b);
}
int main()
{
	long long int n,a,b,p,q;
	cin>>n>>a>>b>>p>>q;
	cout<<(n/a-n/((a*b)/gcd(a,b)))*p+(n/b-n/((a*b)/gcd(a,b)))*q+(max(p,q)*(n/((a*b)/gcd(a,b))))<<endl;
}