#include<iostream>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<string>
#define N 400009
using namespace std;
set<int>d[2];
vector<int>adj[N];
vector<pair<int,int> >eds;
int maxn=400000,deg[N],xo[N];
map<pair<int,int>,int>deleted,mp;
void deledge(int u,int v)
{
	deleted[make_pair(u,v)]=true;
	deleted[make_pair(v,u)]=true;
	
	d[deg[u]].erase(u);
	deg[u]=!deg[u];
	d[deg[u]].insert(u);

	u=v;
	d[deg[u]].erase(u);
	deg[u]=!deg[u];
	d[deg[u]].insert(u);
}
vector<int>eu;
void euler(int v)
{
	while(!adj[v].empty())
	{
		int u=adj[v].back();
		adj[v].pop_back();
		if(!deleted[make_pair(v,u)])
		{
			deleted[make_pair(v,u)]=deleted[make_pair(u,v)]=true;
			euler(u);
		}
	}
	eu.push_back(v);
}
void solve()
{
	if(d[1].empty())
	{
		for(int i=0;i<=maxn;i++)
		{
			eu.clear();
			euler(i);
			for(int j=1;j<eu.size();j++)
			{
				mp[make_pair(eu[j],eu[j-1])]=mp[make_pair(eu[j-1],eu[j])]=j%2;
			}
		}
	}
	else
	{
		int v=*d[1].begin();
		while(!adj[v].empty()&&deleted[make_pair(v,adj[v].back())])
		{
			adj[v].pop_back();
		}
		int u=adj[v].back();
		deledge(u,v);
		solve();
		int c=0;
		if(xo[u]>0)
		{
			c=1;
		}
		if(c==1)
		{
			xo[u]--;
			xo[v]--;
		}
		else
		{
			xo[u]++;
			xo[v]++;
		}
		mp[make_pair(u,v)]=mp[make_pair(v,u)]=c;
	}
}
int main()
{
	int n,x,y;
	string a="rb";
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>x>>y;
		x--;
		y--;
		adj[2*x].push_back(2*y+1);
		adj[2*y+1].push_back(2*x);
		eds.push_back(make_pair(2*x,2*y+1));
	}
	for(int i=0;i<=maxn;i++)
	{
		d[adj[i].size()%2].insert(i);
		deg[i]=adj[i].size()%2;
	}
	solve();
	for(int i=0;i<eds.size();i++)
		cout<<a[mp[make_pair(eds[i].first,eds[i].second)]];
}