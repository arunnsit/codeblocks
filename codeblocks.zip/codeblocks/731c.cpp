#include<iostream>
#include<string>
#include<algorithm>
#include<set>
#include<map>
#include<vector>
#include<stdio.h>
#define N 200009
using namespace std;
vector<int>adj[N],v;
int col[N],vis[N],fcol[N],maf=0,tot=0;
void dfs(int u,int p)
{
	v.push_back(u);
	vis[u]=1;
	fcol[col[u]]++;
	maf=max(fcol[col[u]],maf);
	tot++;
	for(int i=0;i<adj[u].size();i++)
	if(!vis[adj[u][i]]&&adj[u][i]!=p){
		dfs(adj[u][i],p);
	}
}
int main()
{
	int n,x,y,k,m;
	scanf("%d %d %d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&col[i]);
	}
	while(m--)
	{
		scanf("%d %d",&x,&y);
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	int sol=0;
	for(int i=1;i<=n;i++)
	{
		if(!vis[i])
		{
			maf=0;
			tot=0;
			v.clear();
			dfs(i,i);
			for(int j=0;j<v.size();j++)
				fcol[col[v[j]]]=0;
			sol+=tot-maf;
		}
	}
	printf("%d\n",sol);
}