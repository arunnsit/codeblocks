#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int a,b,n;
	cin>>n>>a>>b;
	if(b<=0)
	{
		while(b++)
		{
			a--;
			if(a==0)
			{
				a=n;
			}
		}
		cout<<a<<endl;
	}
	else
	{
		while(b--)
		{
			a++;
			if(a==n+1)
			{
				a=1;
			}
		}
		cout<<a<<endl;
	}
}