#include<iostream>
#include<algorithm>
#include<vector>
#define N 300009
using namespace std;
vector<int>adj[N];
int P[N],subt[N];
int centroid[N];
int dfs(int u,int p)
{
	int c=1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		c+=dfs(adj[u][i],u);
	}
	//cout<<u<<" "<<c<<endl;
	return subt[u]=c;
}
int moveitup(int x,int size,int pos)
{
	int prev=x;
	while(P[x]!=0)
	{
		prev=x;
		if(subt[pos]-subt[x]>subt[pos]/2)
		{
			x=P[x];
		}
		else break;
	}
	return prev;
}
void centfind(int u,int p)
{
	int totalsize=subt[u],point=u,tmp,ch=0,ms=0,mside=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		centfind(adj[u][i],u);
		ch=1;
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		if(ms<subt[adj[u][i]])
		{
			ms=subt[adj[u][i]];
			mside=adj[u][i];
		}
	}
	if(ms>(totalsize)/2)
	{
		centroid[u]=moveitup(centroid[mside],(totalsize)/2,u);
	}
	else
	{
		centroid[u]=u;
	}
	if(!ch)
	{
		centroid[u]=u;
	}
}
int main()
{
	int n,q,x;
	cin>>n>>q;
	for(int i=2;i<=n;i++)
	{
		cin>>P[i];
		adj[P[i]].push_back(i);
		adj[i].push_back(P[i]);
	}
	dfs(1,0);
	centfind(1,0);
	while(q--)
	{
		cin>>x;
		cout<<centroid[x]<<endl;
	}
}