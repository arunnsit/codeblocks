#include<iostream>
#include<vector>
#include<set>
#include<algorithm>
#define N 200009
using namespace std;
vector<int>adj[N];
int a[N];
long long int w[N];
multiset<long long int>s;
long long  dfs(int u,int p)
{
	w[u]=a[u];
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		w[u]+=dfs(adj[u][i],u);
	}
	s.insert(w[u]);
	return w[u];
}
long long int sol=-(1e17),ch=0;

void solve(int u,int p)
{
	s.erase(s.find(w[u]));
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		solve(adj[u][i],u);
	}
	if(s.size())
	{
		ch=1;
		sol=max(w[u]+(*s.rbegin()),sol);
	}
}
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<n-1;i++)
	{
		int x,y;
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	dfs(1,1);
	solve(1,1);
	if(ch)
	{
		cout<<sol<<endl;
	}
	else cout<<"Impossible\n";
}