#include<iostream>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#define N 10002
using namespace std;
vector<int>adj[N],w[N];
long long int d[N];
set<pair<long long int ,int> >q;
bool doit(int s,int t,int n,int ch,int l)
{
	for(int i=0;i<=n;i++)
		d[i]=100000000000000LL;
	d[s]=0;
	q.insert(make_pair(0,s));
	int u;
	long long int we;
	while(!q.empty())
	{
		we=(*q.begin()).first;
		u=(*q.begin()).second;
		q.erase(q.begin());
		//cout<<"ch:"<<ch<<" "<<u<<" "<<we<<endl; 
		if(d[u]==we)
		{
			for(int i=0;i<adj[u].size();i++)
			{
				//cout<<"u:"<<u<<" "<<"c:"<<adj[u][i]<<endl;
				if(d[adj[u][i]]>we+((w[u][i]==0)?((ch==0)?0:1):w[u][i])&&(ch==1||(ch==0&&w[u][i]!=0)))
				{
					d[adj[u][i]]=we+((w[u][i]==0)?((ch==0)?0:1):w[u][i]);
					q.insert(make_pair(d[adj[u][i]],adj[u][i]));
				}
			}
		}
	}
	//cout<<ch<<" "<<d[t]<<endl;
	if((ch&&d[t]<=l)||((!ch)&&d[t]>=l))
		return 1;
	return 0;
}
void doit2(int s,int t,int n,int l)
{
	for(int i=0;i<=n;i++)
		d[i]=100000000000000LL;
	d[s]=0;
	q.insert(make_pair(0,s));
	int u;
	long long int we;
	while(!q.empty())
	{
		u=(*q.begin()).second;
		we=(*q.begin()).first;
		q.erase(q.begin());
		if(d[u]==we)
		{
			for(int i=0;i<adj[u].size();i++)
			{
				if(d[adj[u][i]]>we+w[u][i])
				{
					d[adj[u][i]]=we+w[u][i];
					q.insert(make_pair(d[adj[u][i]],adj[u][i]));
				}
			}
		}
	}
}
vector<pair<int,int> >f;
vector<pair<pair<int,int> ,int> >v;
int sol[N];
int main()
{
	int n,m,l,s,t,x,y,z;
	scanf("%d %d %d %d %d",&n,&m,&l,&s,&t);
	for(int i=0;i<m;i++)
	{
		scanf("%d %d %d",&x,&y,&z);
		adj[x].push_back(y);
		adj[y].push_back(x);
		w[x].push_back(z);
		w[y].push_back(z);
		if(!z)f.push_back(make_pair(x,y));
		v.push_back(make_pair(make_pair(x,y),z));
	}
	if(doit(s,t,n,0,l)==0||doit(s,t,n,1,l)==0)
	{
		printf("NO\n");
	}
	else if(doit(s,t,n,1,l)&&d[t]==l)
	{
		printf("YES\n");
		for(int i=0;i<v.size();i++)
		{
			if(!v[i].second)
				printf("%d %d %d\n",v[i].first.first,v[i].first.second,1);
			else printf("%d %d %d\n",v[i].first.first,v[i].first.second,v[i].second);
		}
	}
	else
	{
		printf("YES\n");
		for(int i=0;i<v.size();i++)
		{
			if(v[i].second)
				printf("%d %d %d\n",v[i].first.first,v[i].first.second,v[i].second);
		}
		for(int j=0;j<f.size();j++)
		{
			x=f[j].first;
			y=f[j].second;
			for(int i=0;i<adj[x].size();i++)
			if(adj[x][i]==y){
				w[x][i]=1;
			}
			for(int i=0;i<adj[y].size();i++)
			if(adj[y][i]==x){
				w[y][i]=1;
			}
			doit(s,t,n,1,l);
			sol[j]=1;
			if(d[t]>l)
			{
			}
			else
			{
				for(int i=0;i<adj[x].size();i++)
				if(adj[x][i]==y){
					w[x][i]=l-d[t]+1;
				}
				for(int i=0;i<adj[y].size();i++)
				if(adj[y][i]==x){
					w[y][i]=l-d[t]+1;
				}
				sol[j]=l-d[t]+1;
			}
			printf("%d %d %d\n",x,y,sol[j]);
		}
	}
}