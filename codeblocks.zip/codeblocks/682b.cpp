#include<iostream>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<vector>
using namespace std;
vector<int>v;
int main()
{
	int n,x;
	int sol;
	cin>>n;
	sol=n+1;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		v.push_back(x);
	}
	sort(v.begin(),v.end());
	int c=1;
	for(int i=0;i<v.size();i++)
	{
		if(v[i]>=c)
		{
			c++;
		}
	}
	cout<<c<<endl;

}