#include<algorithm>
#include<stdio.h>
#include<iostream>
#include<vector>
#include<set>
using namespace std;
vector<int> adj[100009],w[100009];
int d[100009];
vector<pair<pair<int,int> ,int> >vp;
int main()
{
	int n,m,s,x,y,z,l;
	cin>>n>>m>>s;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y>>z;
		adj[x].push_back(y);
		adj[y].push_back(x);
		w[x].push_back(z);
		w[y].push_back(z);
		vp.push_back(make_pair(make_pair(x,y),z));
	}
	for(int i=0;i<=n;i++)
	{
		d[i]=1000000000;
	}
	cin>>l;
	d[s]=0;
	set<pair<int,int > >se;
	se.insert(make_pair(0,s));
	int curnode,curw;
	while(!se.empty())
	{
		curnode=(*se.begin()).second;
		curw=(*se.begin()).first;
		se.erase(se.begin());
		if(d[curnode]==curw)
		{
			for(int i=0;i<adj[curnode].size();i++)
			{
				if(d[adj[curnode][i]]>d[curnode]+w[curnode][i])
				{
					d[adj[curnode][i]]=d[curnode]+w[curnode][i];
					se.insert(make_pair(d[adj[curnode][i]],adj[curnode][i]));
				}
			}
		}
	}
	int coun=0,a,b,mi,dist,ma;
	float mid=0;
	for(int i=1;i<=n;i++)
		{
			if(d[i]==l)
			coun++;
		//cout<<"i:"<<i<<" d:"<<d[i]<<endl;
	}
	for(int i=0;i<m;i++)
	{
		z=vp[i].second;
		x=l-d[vp[i].first.first];
		y=l-d[vp[i].first.second];
		dist=0;
		if(l<z-x+d[vp[i].first.second]&&x>0&&x<z)
		{
			coun++;
		}
		if(l<z-y+d[vp[i].first.first]&&y>0&&y<z)
		{
			coun++;
		}
		if(l==z-x+d[vp[i].first.second]&&x>0&&x<z)
		{
			coun++;
		}

		//cout<<i<<" c:"<<coun<<endl;
	}
	cout<<coun<<endl;	
}