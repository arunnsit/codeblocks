#include<iostream>
#include<algorithm>
using namespace std;
long long int a[30];
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	sort(a,a+n);
	long long int sol=a[n-1],prev=a[n-1];
	for(int i=n-2;i>=0;i--)
	{
		if(a[i]>=prev)
		{
			if(prev!=1)
			{
			sol+=prev-1;
			prev-=1;
		}
		}
		else 
		{
			sol+=a[i];
			prev=a[i];
		}
	}
	cout<<sol<<endl;

}