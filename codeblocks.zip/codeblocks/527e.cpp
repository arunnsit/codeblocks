#include<iostream>
#include<vector>
#include<stack>
#include<set>
using namespace std;
multiset<int>adj[100009];
vector<pair<int,int> >v;
vector<int>e;
stack<int>s;
int degree[100009];
int main()
{
	int n,m,x,y;
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		degree[x]++;
		degree[y]++;
		adj[x].insert(y);
		adj[y].insert(x);
	}
	for(int i=1;i<=n;i++)
	{
		if(degree[i]&1)
		{
			v.push_back(make_pair(degree[i],i));
		}
	}
	for(int i=0;i<v.size();i+=2)
	{
		x=v[i].second;
		y=v[i+1].second;
		degree[x]++;
		degree[y]++;
		adj[x].insert(y);
		adj[y].insert(x);
	}
	if(v.size()&1)
	{
		x=v[v.size()-1].second;
		y=v[v.size()-1].second;
		degree[x]++;
		degree[y]++;
		adj[x].insert(y);
		adj[y].insert(x);
	}
	s.push(1);
	while(!s.empty())
	{
		if(adj[s.top()].size()==0)
		{
			e.push_back(s.top());
			s.pop();
		}
		else
		{
			x=*adj[s.top()].begin();
			adj[s.top()].erase(adj[s.top()].find(x));
			adj[x].erase(adj[x].find(s.top()));
			s.push(x);
		}
	}
	if((e.size()-1)&1)
	{
		e.push_back(1);
	}
	cout<<e.size()-1<<endl;
	for(int i=0;i<e.size()-1;i++)
	if(i&1)
	{
		cout<<e[i]<<" "<<e[i+1]<<endl;
	}
	else cout<<e[i+1]<<" "<<e[i]<<endl;

}