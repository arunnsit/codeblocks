#include<iostream>
using namespace std;
int main()
{
	int a[1002]={0},n,tmp,sol=0;
	cin>>n;
	while(n--)
	{
		cin>>tmp;
		a[tmp]++;
	}
	int ch=1,coun=0;
	while(ch)
	{
		coun=0;
	for(int i=0;i<=1000;i++)
	{
		if(a[i])
		{
			a[i]--;
			if(coun)
				sol++;
			coun=1;
		}
	}
	if(!coun)ch=0;
}
cout<<sol<<endl;
}