#include<iostream>
#include<map>
#include<string>
#include<set>
#include<vector>
#include<unordered_map>
using namespace std;
int ma[10][10][300]={0};
int wei[300]={0};
set<pair<int,pair<pair<int,int>,int> > >s;
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int p;
pair<pair<int,int>,int> dp[10][10][300];
vector<pair<int,int> >v;
int timer=0;
unordered_map<string,int>um;
vector<string>rehash(200);
int hasher(string a)
{
	if(!um[a])
	{
		um[a]=++timer;
		rehash[timer]=a;
	}
	return um[a];
}
int move(int iner,int mov)
{
	string in=rehash[iner];
	char tmp;
	if(mov==0)
	{
		tmp=in[0];
		in[0]=in[3];
		in[3]=in[5];
		in[5]=in[1];
		in[1]=tmp;
	}
	if(mov==1)
	{
		tmp=in[0];
		in[0]=in[2];
		in[2]=in[5];
		in[5]=in[4];
		in[4]=tmp;
	}
	if(mov==2)
	{
		tmp=in[0];
		in[0]=in[1];
		in[1]=in[5];
		in[5]=in[3];
		in[3]=tmp;
	}
	if(mov==3)
	{
		tmp=in[0];
		in[0]=in[4];
		in[4]=in[5];
		in[5]=in[2];
		in[2]=tmp;
	}
	//cout<<in<<endl;
	return hasher(in);
}
int main()
{
	string a,b;
	cin>>a;
	cin>>b;
	int near, far, top, right, bottom ,left ;
	cin>>near>>far>>top>>right>>bottom>>left;
	wei['n']=near;
	wei['f']=far;
	wei['t']=top;
	wei['r']=right;
	wei['b']=bottom;
	wei['l']=left;
	string in="blfrnt";
	int x=a[0]-'a',y=a[1]-'1';
	int X=b[0]-'a',Y=b[1]-'1';
	int fx=x,fy=y;
	int cx,cy,dx,dy,ch=hasher(in);
	int cw,inc;
	inc=ch;
	for(int i=0;i<=9;i++)
		for(int j=0;j<=9;j++)
			for(int k=0;k<300;k++)
				ma[i][j][k]=888888888;
	s.insert(make_pair(wei['b'],make_pair(make_pair(x,y),ch)));
	ma[x][y][ch]=wei['b'];
	int sol=888888888,dest=ch;
	int mp=0;

	while(!s.empty())
	{

		ch=(*s.begin()).second.second;
		cx=(*s.begin()).second.first.first;
		cy=(*s.begin()).second.first.second;
		cw=(*s.begin()).first;
		s.erase(s.begin());
		if(cx==X&&cy==Y)
		{
			if(sol>cw)
			{
				sol=cw;
				dest=ch;
				//cout<<dp[cx][cy][ch].first.first<<" "<<dp[cx][cy][ch].first.second<<endl;
				//cout<<sol<<endl;
			}
		}
		//cout<<"size:"<<s.size()<<endl;
		if(ma[cx][cy][ch]==cw)
		{
			for(int i=0;i<4;i++)
			{
				dx=cx+dir[i][0];
				dy=cy+dir[i][1];
				if(dx>=0&&dx<=7&&dy>=0&&dy<=7)
				{
					p=move(ch,i);
					mp=max(mp,p);
					//cout<<dx<<" "<<dy<<" "<<p<<" "<<ma[dx][dy][p]<<" "<<cw+wei[rehash[p][0]]<<endl;
					if(ma[dx][dy][p]>cw+wei[rehash[p][0]])
				{
					//cout<<"hi\n";
					ma[dx][dy][p]=cw+wei[rehash[p][0]];
					s.insert(make_pair(cw+wei[rehash[p][0]],make_pair(make_pair(dx,dy),p)));
					dp[dx][dy][p]=make_pair(make_pair(cx,cy),ch);
				}
			}
			}
		}
	}
	x=X;
	y=Y;
	int up=dest;
	cout<<sol<<" ";
	while(1)
	{
		v.push_back(make_pair(x,y));
		dx=dp[x][y][up].first.first;
		dy=dp[x][y][up].first.second;
		up=dp[x][y][up].second;
		//cout<<dx<<" ... "<<dy<<endl;
		if(dx==fx&&fy==dy&&up==inc)
		{
			v.push_back(make_pair(dx,dy));
			break;
		}
		x=dx;
		y=dy;
	}
	for(int i=v.size()-1;i>=0;i--)
		cout<<(char)(v[i].first+'a')<<v[i].second+1<<" ";

}