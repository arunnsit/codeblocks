#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
#define N 100009
long long int dp[N],tup=0,sol=0,last[N];
int main()
{
	string a;
	int n,m,mod=1000000007;
	cin>>n>>m>>a;
	int f[30]={0};
	for(int i=0;i<a.size();i++)
	{
		f[a[i]-'a']++;
		tup=0;
		for(int j=0;j<m;j++)
		{
			tup=(tup+dp[j])%mod;
		}
		dp[a[i]-'a']=tup+1;
		last[a[i]-'a']=i+1;
	}
	int timer=n;
	for(int i=0;i<m;i++)
	{
		if(!f[i]&&timer)
		{
			timer--;
			f[i]++;
			tup=0;
			for(int j=0;j<m;j++)
			{
				tup=(tup+dp[j])%mod;
			}
			a.push_back(i+'a');
			dp[i]=tup+1;
			last[i]=a.size();
		}
	}
	while(timer--)
	{
		int mi=100000000,pos=0;
		for(int i=0;i<m;i++)
		{
			if(last[i]<mi)
			{
				mi=last[i];
				pos=i;
			}
		}
		    tup=0;
			for(int j=0;j<m;j++)
			{
				tup=(tup+dp[j])%mod;
			}
			a.push_back(pos+'a');
			dp[pos]=tup+1;
			last[pos]=a.size();

	}
	tup=0;
			for(int j=0;j<m;j++)
			{
				tup=(tup+dp[j])%mod;
			}
	cout<<tup+1<<endl;		
}