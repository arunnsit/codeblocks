#include<iostream>
#include<stdio.h>
#include<math.h>
#include<iomanip>
#include<vector>
using namespace std;
vector<double>v;
int main()
{
	double a;
	cout<<fixed<<endl;
	while(scanf("%lf",&a)!=EOF)
	{
		v.push_back(sqrt(a));
	}
	for(int i=v.size()-1;i>=0;i--)
		cout<<setprecision(5)<<v[i]<<endl;
} 