#include<iostream>
#include<vector>
using namespace std;
int f[1000009];
vector<int>v[500009];
int main()
{
		ios_base::sync_with_stdio(false);cin.tie(0);

	int n,c;
	cin>>n>>c;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		for(int j=0;j<x;j++)
		{
			int y;
			cin>>y;
			v[i].push_back(y);
		}
	}
	int ch=0;
	for(int i=1;i<n;i++)
	{
		int u=min(v[i].size(),v[i-1].size()),j;
		for(j=0;j<u;j++)
		{
			if(v[i][j]!=v[i-1][j])
			{
				break;
			}
		}
		if(j==u)
		{
			if(u<v[i-1].size())ch=1;
			continue;
		}
		if(v[i][j]>v[i-1][j])
		{
			int d=c-v[i][j]+1;
			int u=c-v[i-1][j];
			
			//cout<<"1 "<<d<<" "<<u<<endl;
			f[d]+=1;
			f[u+1]-=1;
			
		}
		else if(v[i][j]<v[i-1][j])
		{
			int d=c-v[i-1][j]+1;
			int u=c-v[i][j];
			//cout<<"0 "<<d<<" "<<u<<endl;
			f[0]+=1;
			f[d]-=1;
			f[u+1]+=1;
			f[1000001]-=1;
		}
	}
	for(int i=0;i<=c-1;i++)
	{
		f[i]+=f[i-1];
		//cout<<f[i]<<" ";
	}
	//cout<<endl;
	for(int i=0;i<=c-1;i++)
	{
		if(!f[i]&&ch==0)
			{
				cout<<i<<"\n";
				return 0;
			}
		//cout<<f[i]<<" ";	
	}
	cout<<-1<<"\n";
}
