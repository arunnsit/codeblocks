#include<iostream>
#include<set>
#include<algorithm>
#include<vector>
#include<string>
#include<math.h>
#include<string.h>
#define N 300009
using namespace std;
vector<int>apps[N];
int timer=0;
int quers[N]={0};
int main()
{
	int n,q,x,y,totals=0;
	cin>>n>>q;
	for(int i=0;i<q;i++)
	{
		cin>>x>>y;
		if(x==1)
		{
			apps[y].push_back(++timer);
			quers[timer]=1;
			totals++;
		}
		else if(x==2)
		{
			while(apps[y].size())
			{
				if(quers[apps[y].back()]==1)
				{
					totals--;
					quers[apps[y].back()]=0;
				}
				apps[y].pop_back();
			}
		}
		else
		{
			for(int i=y;i>=1;i--)
			if(quers[i]==2){
				break;
			}
			else 
			{
				if(quers[i]==1)
				{
					totals--;
				}
				quers[i]=2;
			}
		}
		cout<<totals<<endl;
	}
}