#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#define N 100009
using namespace std;
vector<int>adj[N];
double sol[N];
int subtree[N];
void dfs(int u,int p)
{
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		dfs(adj[u][i],u);
		subtree[u]+=subtree[adj[u][i]];
	}
	subtree[u]+=1;
	//cout<<u<<".."<<subtree[u]<<endl;
}
void solve(int u,int p)
{
	double cons=0,s=0,temp=1;

	double n=0,coun=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		s+=subtree[adj[u][i]];
		n++;
	}
	if(n<1)
		return ;
	//cout<<u<<".."<<coun<<" "<<s<<" "<<n<<endl;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		sol[adj[u][i]]=sol[u]+0.5*((1.0*s)-subtree[adj[u][i]])+1;
		//cout<<adj[u][i]<<" sol:"<<sol[u]<<" "<<coun*((1.0*s)-subtree[adj[u][i]]+n-1)<<" "<<(1.0/n)<<endl;
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		solve(adj[u][i],u);
	}
}
int main()
{
	int n,x,y;
	cin>>n;
	for(int i=2;i<=n;i++)
	{
		cin>>x;
		adj[x].push_back(i);
		adj[i].push_back(x);
	}
	dfs(1,0);
	sol[1]=1.0;
	solve(1,0);
	for(int i=1;i<=n;i++)
		cout<<sol[i]<<" ";
	cout<<endl;
}