#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;

int main()
{
	cout<<fixed;
	double d,L,v1,v2;
	cin>>d>>L>>v1>>v2;
	cout<<setprecision(8)<<(L-d)/(v1+v2)<<endl;

}