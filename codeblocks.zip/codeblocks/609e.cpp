#include<stdio.h>
#include<vector>
#include<algorithm>
#define N 200100
#define LOGN 22
using namespace std;
vector<int>adj[N],weight[N],number[N];
int P[N],siz[N];
struct node
{
	int x,y,z,no;
};
bool cmp(node a,node b)
{
	return a.z<b.z;
}
node ed[N];
void createset(int x)
{
	if(P[x]!=0)
		return ;
	P[x]=x;
	siz[x]=1;
}
int find_parent(int x)
{
	if(x==P[x])
		return x;
	P[x]=find_parent(P[x]);
	return P[x];
}
void merge(int x,int y)
{
	int u=find_parent(x);
	int v=find_parent(y);
	if(v==u)
		return ;
	if(u>v)
	{
		P[u]=v;
		siz[v]+=siz[u];
		siz[u]=1;
	}
	else
	{
		P[v]=u;
		siz[u]+=siz[v];
		siz[v]=1;
	}
}
int inmst[N];
int n,subtree[N],chainhead[N],nodeinchain[N],chaincount=0,posinbase[N],base[N],tree[6*N],ptr=0,dp[LOGN+3][N],level[N],parentnode[N],nodeplace[N],otherend[N];
int dfs1(int start,int p)
{
	int s=0;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=p){
		s+=dfs1(adj[start][i],start);
		parentnode[adj[start][i]]=start;
		otherend[number[start][i]]=adj[start][i];
	}
	subtree[start]=s+1;
	return s+1;
}
void decompose(int start,int p,int edgw)
{
	int max_child=-1,max_sub=0,max_weight=0;
	nodeinchain[start]=chaincount;
	base[ptr]=edgw;
	posinbase[start]=ptr;
	nodeplace[start]=ptr;
	ptr++;
	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=p){
		if(max_sub<=subtree[adj[start][i]])
		{
			max_sub=subtree[adj[start][i]];
			max_weight=weight[start][i];
			max_child=adj[start][i];
		}
	}
    if(max_child!=-1)
	decompose(max_child,start,max_weight);

	for(int i=0;i<adj[start].size();i++)
	if(adj[start][i]!=p&&adj[start][i]!=max_child){
	    chaincount++;
		chainhead[chaincount]=adj[start][i];
		decompose(adj[start][i],start,weight[start][i]);
	}
}
void check_decompose()
{
	//for(int i=0;i<n;i++)
	//	cout<<"node:"<<i<<" subtree:"<<subtree[i]<<" chain:"<<nodeinchain[i]<<" head:"<<chainhead[i]<<endl;
}
void make_tree(int curr,int l,int r)
{
	if(l==r)
	{
		tree[curr]=base[l];
		return;
	}
	int mid=l+(r-l)/2;
	make_tree(2*curr+1,l,mid);
	make_tree(2*curr+2,mid+1,r);
	tree[curr]=max(tree[2*curr+1],tree[2*curr+2]);
}
int query(int curr,int l,int r,int x,int y)
{
	if(l>y||r<x)
		return 0;
	if(x<=l&&r<=y)
		return tree[curr];
	int mid=l+(r-l)/2;
	int c=max(query(2*curr+1,l,mid,x,y),query(2*curr+2,mid+1,r,x,y));
	//cout<<l<<" "<<r<<" "<<c<<endl;
	return c;
}
void update(int curr,int l,int r,int point,int val)
{
	if(point>r||point<l)
		return ;
	if(l==r)
		{
			tree[curr]=val;
			base[l]=val;
			return;
		}
	int mid=l+(r-l)/2;
	update(2*curr+1,l,mid,point,val);
	update(2*curr+2,mid+1,r,point,val);
	tree[curr]=max(tree[2*curr+1],tree[2*curr+2]);

}
void dfs0(int curr,int p)
{
	for(vector<int>::iterator it=adj[curr].begin();it!=adj[curr].end();it++)
	if(*it!=p)
	{   
		dp[0][*it]=curr;
		level[*it]=level[curr]+1;
		dfs0(*it,curr);
	}
}
void preprocess()
{
	level[0]=0;
	dp[0][0]=0;
	dfs0(0,0);
	for(int i=1;i<LOGN;i++)
		for(int j=0;j<n;j++)
			dp[i][j] = dp[i-1][dp[i-1][j]];
}
int lca(int a,int b)
{
	if(level[a]>level[b])swap(a,b);
	int d = level[b]-level[a];
	for(int i=0;i<LOGN;i++)
		if(d&(1<<i))
			b=dp[i][b];
	if(a==b)return a;
	for(int i=LOGN-1;i>=0;i--)
		if(dp[i][a]!=dp[i][b])
			a=dp[i][a],b=dp[i][b];
	return dp[0][a];
}
int query_up(int u,int v)
{
	if(u==v)
		return 0;
	int uchain,vchain=nodeinchain[v];
	int ans=0;
	while(1)
	{
		uchain=nodeinchain[u];
		if(uchain == vchain)
		{
			if(u==v) break;
			//cout<<"hey"<<posinbase[v]+1<<" "<<posinbase[u]+1<<" "<<query(0,0,ptr,posinbase[v]+1,posinbase[u])<<endl;
			ans=max(ans,query(0,0,ptr,posinbase[v]+1,posinbase[u]));
			break;
		}
		ans=max(ans,query(0,0,ptr,posinbase[chainhead[uchain]],posinbase[u]));
		u=chainhead[uchain];
		u=dp[0][u];
	}
	return ans;
}
int mainq(int u,int v)
{
	int x=lca(u,v);
//	cout<<"lcs asked for "<<u<<" "<<v<<" : "<<x<<endl;
	return max(query_up(u,x),query_up(v,x));
}
long long int soluton[N]={0};
int main()
{
	int m;
	scanf("%d %d",&n,&m);
	long long int mst=0;
	for(int i=0;i<m;i++)
	{
	    scanf("%d %d %d",&ed[i].x,&ed[i].y,&ed[i].z);
		ed[i].no=i+1;
	}
	sort(ed,ed+m,cmp);
	for(int i=0;i<m;i++)
	{
		createset(ed[i].x);
		createset(ed[i].y);
		if(find_parent(ed[i].x)!=find_parent(ed[i].y))
		{
			inmst[ed[i].no]++;
			//cout<<"..."<<ed[i].x<<" "<<ed[i].y<<" "<<ed[i].z<<endl;
			adj[ed[i].x-1].push_back(ed[i].y-1);
			adj[ed[i].y-1].push_back(ed[i].x-1);
			weight[ed[i].x-1].push_back(ed[i].z);
			weight[ed[i].y-1].push_back(ed[i].z);
			number[ed[i].x-1].push_back(ed[i].no-1);
		    number[ed[i].y-1].push_back(ed[i].no-1);
			merge(ed[i].x,ed[i].y);
			mst+=ed[i].z;
		}
	}
  //  cout<<" "<<mst<<endl;
    ptr=0;
    chaincount=0;
    dfs1(0,0);
	preprocess();
	chainhead[0]=0;
	decompose(0,0,0);
    make_tree(0,0,ptr);
   // cout<<"yeah: "<<mainq(6,4)<<endl;
    for(int i=0;i<m;i++)
    {
    	if(inmst[ed[i].no])
    	{
    		soluton[ed[i].no]=(long long int)mst;
    	}
    	else soluton[ed[i].no]=mst-(long long int)mainq(ed[i].x-1,ed[i].y-1)+(long long int)ed[i].z;
    }
    for(int i=1;i<=m;i++)
    	printf("%I64d\n",soluton[i]);
}