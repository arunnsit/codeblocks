#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	int n,nc;
	cin>>n;
	nc=n;
	if(n<=5)
    {
    	cout<<0<<" ";
    }
    else
    {
    	int c=0;

    	while(n>0)
    	{
    		n-=5;
    		if(n<=2&&n>=0)
    		{
    			c+=n;
    			n=0;
    		}
    		else if(n>2)
    		{
    			c+=2;
    			n-=2;
    		}
    	}
    	cout<<c<<" ";
    }
	if(nc>=2)
	{
		int c=2;
		nc-=2;

    	while(nc>0)
    	{
    		nc-=5;
    		if(nc<=2&&nc>=0)
    		{
    			c+=nc;
    			nc=0;
    		}
    		else if(nc>2)
    		{
    			c+=2;
    			nc-=2;
    		}
    	}
    	cout<<c<<endl;
	}
    else 
    cout<<nc<<endl;

}