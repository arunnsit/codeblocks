#include<iostream>
#include<string>
#define N 100009
using namespace std;
struct node
{
	int a[62];
};
node tree[5*N];
int a[N];
node merge(node a,node b)
{
	node c;
	int x;
	for(int i=0;i<=59;i++)
	{
		x=i;
		x+=a.a[i];
		x+=b.a[x%60];
		c.a[i]=x-i;
	}
	return c;
}
void make_tree(int cur,int l,int r)
{
	if(l==r)
	{
		for(int i=0;i<=59;i++)
		{
			if(i%a[l]==0)
			tree[cur].a[i]=2;
			else tree[cur].a[i]=1;
		}
		return ;
	}
	int mid=l+(r-l)/2;
	make_tree(2*cur+1,l,mid);
	make_tree(2*cur+2,mid+1,r);
	tree[cur]=merge(tree[2*cur+1],tree[2*cur+2]);
}
node query(int cur,int l,int r,int x,int y)
{
	if(x>r||y<l)
	{
		node c;
		for(int i=0;i<=59;i++)
			c.a[i]=0;
		return c;
	}
	if(x<=l&&r<=y)
		return tree[cur];
	int mid=l+(r-l)/2;
		node a,b;
		a=query(2*cur+1,l,mid,x,y);
		b=query(2*cur+2,mid+1,r,x,y);
		return merge(a,b);
}
void update(int cur,int l,int r,int x,int v)
{

	if(l==r)
	{
		a[l]=v;
		for(int i=0;i<=59;i++)
		{
			if(i%a[l]==0)
			tree[cur].a[i]=2;
			else tree[cur].a[i]=1;
		}
		return ;
	}
	int mid=l+(r-l)/2;
	if(mid>=x)
	{
		update(2*cur+1,l,mid,x,v);
	}
	else update(2*cur+2,mid+1,r,x,v);
	tree[cur]=merge(tree[2*cur+1],tree[2*cur+2]);
}
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	make_tree(0,1,n);
	int q;
	cin>>q;
	while(q--)
	{
		string o;
		int x,y;
		cin>>o;
		if(o[0]=='A')
		{
			cin>>x>>y;
			y--;
			cout<<query(0,1,n,x,y).a[0]<<endl;
		}
		else
		{
			cin>>x>>y;
			update(0,1,n,x,y);
		}
	}
}