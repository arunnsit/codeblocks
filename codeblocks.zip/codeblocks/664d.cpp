#include<iostream>
#include<algorithm>
#include<math.h>
#include<set>
#include<vector>
#define N 100009
using namespace std;
vector<int>eds[N],cs[N],verts[5],majord[5];
int color[N][5],checker[5];
void dfs(int u,int c,int p,int q)
{
    if(color[u][q])
    {
        if(color[u][q]==c)
        {
            return ;
        }
        else
        {
            checker[q]=1;
            return;
        }
    }
   // cout<<"at:"<<u<<" "<<c<<" "<<q<<endl;
    color[u][q]=c;
    verts[c].push_back(u);
    for(int i=0;i<eds[u].size();i++)
    if(eds[u][i]!=p)
    {
        if(cs[u][i]==q)
        {
            dfs(eds[u][i],c,u,q);
        }
        else
        {
            dfs(eds[u][i],c^1,u,q);
        }
    }
}
int main()
{
    int n,m,x,y;
    string a;
    cin>>n>>m;
    for(int i=0;i<m;i++)
    {
        cin>>x>>y>>a;
        eds[x].push_back(y);
        eds[y].push_back(x);
        if(a[0]=='R')
        {   
            cs[x].push_back(2); 
            cs[y].push_back(2); 
        }
        else 
        {
            cs[x].push_back(3); 
            cs[y].push_back(3); 
        }
    }
    for(int i=2;i<=3;i++)
    {
        for(int j=1;j<=n;j++)
        if(!color[j][i]){
            dfs(j,2,0,i);
            if(verts[2].size()>verts[3].size())
            {
                for(int l=0;l<verts[3].size();l++)
                {
                    majord[i].push_back(verts[3][l]);
                }
                verts[3].clear();
                verts[2].clear();
            }
            else
            {
                for(int l=0;l<verts[2].size();l++)
                {
                    majord[i].push_back(verts[2][l]);
                }
                verts[3].clear();
                verts[2].clear();
            }
        }
    }
    //cout<<majord[2].size()<<" "<<majord[3].size();
    int boss=-1;
    if(!checker[2]&&!checker[3])
    {
        if(majord[2].size()>majord[3].size())
            boss=3;
        else boss=2;
    }
    else if(!checker[2])
    {
        boss=2;
    }
    else if(!checker[3])
    {
        boss=3;
    }
    if(boss>0)
    {
        cout<<majord[boss].size()<<endl;
        for(int i=0;i<majord[boss].size();i++)
            cout<<majord[boss][i]<<" ";
    }
    else cout<<boss<<endl;


}