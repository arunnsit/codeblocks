#include<iostream>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<vector>
using namespace std;
int dp[1002][1002][12][2]={0};
char a[1003],b[1003];
int solve(int x,int y,int l,int cp)
{
	if(l==0)
		return 0;
	if(x<0||y<0)
		return -1000000;
	if(dp[x][y][l][cp]!=-1)
		return dp[x][y][l][cp];
	int sol=-1000000;
	if(a[x]==b[y])
	{
		sol=max(sol,max(solve(x-1,y-1,l,1)+1,solve(x-1,y-1,l-1,0)+1));
	}
	if(cp==0)
	sol=max(sol,max(solve(x-1,y,l,0),solve(x,y-1,l,0)));
    else sol=max(sol,max(solve(x-1,y,l-1,0),solve(x,y-1,l-1,0)));
	return dp[x][y][l][cp]=sol;
}
int main()
{
	memset(dp,-1,sizeof(dp));
	int n,m,k;
	scanf("%d %d %d",&n,&m,&k);
	scanf("%s %s",a,b);
	printf("%d\n",solve(n-1,m-1,k,0));
}