#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
vector<int> adj[100009],w[100009];
long long int sub[100009];

long long int fsol=0,sum;
long long int solution(int start,int p)
{
	long long int mweight=0;
	for(int i=0;i<adj[start].size();i++)
		if(p!=adj[start][i])
		{
			mweight=max(mweight,w[start][i]+solution(adj[start][i],start));
		}
		return mweight;
}
int main()
{
	int n;
	cin>>n;
	int x,y,z;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y>>z;
		adj[x].push_back(y);
		adj[y].push_back(x);
		w[x].push_back(z);
		w[y].push_back(z);
		sum+=2*z;
	}
	cout<<sum-solution(1,1);
}