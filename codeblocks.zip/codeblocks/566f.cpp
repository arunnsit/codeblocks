#include<iostream>
#include<string.h>
#include<stdio.h>
using namespace std;
int a[1000001],m[1000009];
int main()
{
	int n,tmp,x=0;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		{
			scanf("%d",&tmp);
			a[tmp]++;
			m[tmp]=1;
		}
	for(int i=1;i<=1000000;i++)
	if(a[i])
	{
		for(int j=2*i;j<=1000000;j+=i)
			if(a[j])
			m[j]=max(m[j],m[i]+1);
	}
	for(int i=1;i<=1000000;i++)	
		if(a[i])
		x=max(x,m[i]);
	printf("%d",x);
}