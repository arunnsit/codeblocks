#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int n,m,x,y;
struct node
{
	int x,y,pos;
};
vector<int>adj[1000],inw;
node a[10000];
int dp[103][103][103];
bool cmp(node a,node b)
{
	if(a.x==b.x)
		return a.y>b.y;
	return a.x<b.x;
}
int solve(int curr,int obound,int ibound)
{
	if(curr==m)
		return 1;
	if(dp[curr][obound][ibound])
		return dp[curr][obound][ibound];
	int sol=0;
	for(int i=0;i<adj[curr].size();i++)
	{
		
	}
	
}
char sap[10000];
void fill(int curr,int obound,int ibound)
{

}
int main()
{
	cin>>n>>m;
	sap[m]='\0';
	for(int i=0;i<m;i++)
	{
		cin>>x>>y;
		a[i].x=min(x,y);
		a[i].y=max(x,y);
		a[i].pos=i;
	}
	sort(a,a+m,cmp);
	for(int i=1;i<=n;i++)
	{
		if(adj[i].size())
			imw.push_back(i);
	}
	for(int i=0;i<m;i++)
	if(solve(0,n+1,n+1)==1)
	{
		fill(0,n+1,n+1);
		cout<<sap<<endl;
	}
	else cout<<"Impossible\n";
}