#include<iostream>
#include<stdio.h>
#include<vector>
#include<set>
#include<algorithm>
#define N 10009
using namespace std;
vector<int>adj[N];
int level[N]={0},maxd=0,hea=0;
void depth(int u,int p)
{
	int x=0;
	level[u]=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		depth(adj[u][i],u);
		x=max(level[adj[u][i]],x);
	}
	vector<int>v;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		v.push_back(level[adj[u][i]]);
	}
	sort(v.begin(),v.end());
	if(v.size()>=1)
	{
		level[u]+=x+1;
		if(maxd<v[v.size()-1]+1)
		{
			hea=u;
			maxd=v[v.size()-1]+1;
		}
		if(v.size()>1)
		{
			if(maxd<v[v.size()-1]+2+v[v.size()-2])
			{
				hea=u;
				maxd=v[v.size()-1]+2+v[v.size()-2];
			}
		}
	}
}
int c1,c2;
void findcenter(int u,int p)
{
	int x=0,v=0;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p){
		if(x<=level[adj[u][i]])
		{
			x=level[adj[u][i]];
			v=adj[u][i];
		}
	}
	if(x==maxd/2)
	{
		if(maxd%2==0)
		{
			c1=v;
		}
		else
		{
			c1=u;
			c2=v;
		}
	}
	else if(level[u]==maxd/2)
	{
		c1=u;
	}
	else findcenter(v,u);
}
int main()
{
	int n,x,y;
	cin>>n;
	for(int i=2;i<=n;i++)
	{
		cin>>x;
		adj[x].push_back(i);
		adj[i].push_back(x);
	} 
	depth(1,0);
	//cout<<hea<<" "<<maxd<<endl;
	depth(hea,0);
	findcenter(hea,0);
	if(maxd%2==0)
	{
		cout<<c1<<endl;
	}
	else cout<<c1<<" "<<c2<<endl; 
}