#include<iostream>
#include<string>
using namespace std;
int mark[200000]={0},j[200000];
int main()
{
	int n,p;
	cin>>n;
	string a;
	cin>>a;
	for(int i=0;i<n;i++)
	{
		cin>>j[i];
	}
	int curr=1;
	while(curr>=1&&curr<=n&&(mark[curr]==0))
	{
		mark[curr]=1;
		if(a[curr-1]=='>')
		{
			p=j[curr-1];
		}
		else
		{
			p=-j[curr-1];
		}
		curr+=p;
	}
	if(curr<=0||curr>n)
		cout<<"FINITE\n";
	else cout<<"INFINITE\n";

}