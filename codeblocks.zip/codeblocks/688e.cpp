#include<iostream>
#include<algorithm>
#include<string.h>
#include<vector>
using namespace std;
bool dp[501][501][501]={0};
int a[502],K,co=0;
vector<int>v;
int main()
{
	int n,k,c;
	scanf("%d %d",&n,&K);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	dp[0][0][0]=true;
	for(int i=1;i<=n;i++)
	{
		for(int p=0;p<=K;p++)
		{
			for(int j=0;j<=p;j++)
			{
				if(p-a[i]>=0&&j-a[i]>=0)
				{
					dp[i][p][j]|=dp[i-1][p-a[i]][j-a[i]];
				}
				if(p-a[i]>=0)
				{
					dp[i][p][j]|=dp[i-1][p-a[i]][j];
				}
				dp[i][p][j]|=dp[i-1][p][j];
			}
		}
	}
	//cout<<"moves:"<<co<<endl;
	for(int i=0;i<=500;i++)
	{
			if(dp[n][K][i])
			v.push_back(i);
	}
	printf("%lu\n",v.size());
	for(int i=0;i<v.size();i++)
		printf("%d ",v[i]);

}