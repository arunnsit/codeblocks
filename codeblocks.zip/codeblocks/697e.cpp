#include<iostream>
#include<math.h>
using namespace std;
long long int mod=1000000007;
long long int pow_bhaji(long long int x,long long int y)
{
	long long int w;
	if(y==0)
		return 1;
	if(y&1)
		{
			w=pow_bhaji(x,(y-1)/2)%mod;
			return (((x*w)%mod)*w)%mod;
		}
	else 
		{
			w=pow_bhaji(x,(y)/2)%mod;
			return (w*w)%mod;
		}
}
long long int in[100008];
int main()
{
	long long num=0,den=0,inv,left=1,right=1;
	inv=pow_bhaji(6,mod-2);
	long long int k;
	cin>>k;
	for(int i=0;i<k;i++)
	{
		cin>>in[i];
		right=(right*in[i])%2;
		in[i]%=(mod-1);
		left=(left*in[i])%(mod-1);
		//cout<<(pow(2,in[i])+pow(-1,in[i])*2)/3<<endl;
	}
	left=pow_bhaji(2,left);
	right=(right==0)?1:-1;
	//cout<<(left+right*2)<<endl;  
	cout<<(((left+right*2+mod)%mod)*inv)%mod<<"/"<<(left*pow_bhaji(2,mod-2))%mod<<endl;
}