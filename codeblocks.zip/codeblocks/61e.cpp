#include<iostream>
#include<algorithm>
using namespace std;
struct node
{
	int v,pos,comp;
};
node in[1000009];
int a[1000009];
bool cmp1(node a,node b)
{
	return a.v<b.v;
}
bool cmp2(node a,node b)
{
	return a.pos<b.pos;
}
int bit[1000009][2]={0};

void update(int pos,int add,int n,int no)
{
	int ind=pos+1;
	while(ind<=n)
	{
		bit[ind][no]+=add;
			ind=ind+(ind&(-ind));
	}
}
int query(int pos,int no)
{
	int ind=pos+1;
	int sum=0;
	while(ind!=0)
	{
		sum+=bit[ind][no];
		ind=ind-(ind&(-ind));
	}
	return sum;
}
long long int l[1000009],r[1000009];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>in[i].v;
		in[i].pos=i;
	}
	sort(in+1,in+n+1,cmp1);
	for(int i=1;i<=n;i++)
	{
		in[i].comp=i;
	}
	sort(in+1,in+n+1,cmp2);
	for(int i=1;i<=n;i++)
	{
		a[i-1]=in[i].comp;
	}
	for(int i=0;i<n;i++)
	{
		update(a[i]-1,1,n,0);
		l[i]=query(n-1,0)-query(a[i]-1,0);
		//cout<<l[i]<<" ";
	}
	long long int sol=0;
	for(int i=n-1;i>=0;i--)
	{
		sol+=query(a[i]-1,1)*l[i];
		update(a[i]-1,1,n,1);
	}
	cout<<sol<<endl;
}