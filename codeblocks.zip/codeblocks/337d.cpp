#include<iostream>
#include<algorithm>
#include<vector>
#define N 100009
using namespace std;
vector<int>adj[N];
int n,m,d,x,h[N],y; 
int dp1[N],dpup[N];
void dfs(int u ,int p)
{
	if(h[u])
		dp1[u]=0;
	else dp1[u]=-10*N;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		dfs(adj[u][i],u);
		dp1[u]=max(dp1[adj[u][i]]+1,dp1[u]);
	}
	///cout<<"u:"<<u<<" "<<dp1[u]<<endl;
}
void dfs2(int u,int p,int a1,int a2)
{
	dpup[u]=max(a1+1,a2+2);
	if(p!=-1&&h[p])
		dpup[u]=max(dpup[u],1);
	int m2=-10*N,m1=-10*N;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		if(dp1[adj[u][i]]>=m2)
		{
			m1=m2;
			m2=dp1[adj[u][i]];
		}
		else if(dp1[adj[u][i]]>=m1)
		{
			m1=dp1[adj[u][i]];
		}
	}
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		if(dp1[adj[u][i]]==m2)
		{
			dfs2(adj[u][i],u,dpup[u],m1);
		}
		else dfs2(adj[u][i],u,dpup[u],m2);
	}
	//cout<<"u:"<<u<<" "<<dpup[u]<<" "<<a1<<" "<<a2<<endl;
}
int main()
{
	cin>>n>>m>>d;
	for(int i=1;i<=m;i++)
	{
		cin>>x;
		h[x]++;
	}
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	dfs(1,1);
	dfs2(1,-1,-10*N,-10*N);
	int c=0;
	for(int i=1;i<=n;i++)
		if(dpup[i]<=d&&dp1[i]<=d)
			c++;
	cout<<c<<endl;	
}