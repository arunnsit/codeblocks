#include<iostream>
using namespace std;
int main()
{
	long long int n,k;
	cin>>n>>k;
	cout<<((n+k)/k)*k<<endl;
}