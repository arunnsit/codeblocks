#include<iostream>
#include<algorithm>
#include<string.h>
#include<string>
#include<set>
#include<vector>
using namespace std;
int a[1008];
int main ()
{
	int n,t,x,y,z,h,c=0;
	cin>>n>>h;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		if(a[i]>h)
			c++;
	}
	cout<<c+n<<endl;
}