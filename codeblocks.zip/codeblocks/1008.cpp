#include<iostream>
#include<queue>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
char a[100];
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
string mo="RTLB";
bool cmp(pair<int,int> a,pair<int,int> b)
{
	if(a.first==b.first)
		return a.second<b.second;
	return a.first<b.first;
}
vector<pair<int,int> > v;
int main()
{
	cin.getline(a,100);
	int x=0,y=0,i,ch=0,X,Y,p,q;

	for(i=0;a[i]!='\0';i++)
	if(a[i]>='0'&&a[i]<='9'){
		x=x*10+(a[i]-'0');
	}
	else break;
	i++;
	//cout<<"i:"<<i<<" "<<a.length()<<endl;

	for(;a[i]!='\0';i++)
	if(a[i]>='0'&&a[i]<='9'){
		y=y*10+(a[i]-'0');
		ch=1;
	}
	else break;

	if(ch==1)
	{
	//	cout<<"yeah";
		int m[20][20]={0},dx,dy;
		queue<pair<int,int> >q;
		q.push(make_pair(x,y));
		v.push_back(make_pair(x,y));
		string tmp;
		cin>>tmp;
		while(tmp[0]!='.')
		{
			x=q.front().first;
			y=q.front().second;
			q.pop();
			for(int i=0;i<tmp.length()-1;i++)
			{
				if(tmp[i]=='R')
				{
					dx=x+1;
					dy=y;
				}
				if(tmp[i]=='T')
				{
					dx=x;
					dy=y+1;
				}
				if(tmp[i]=='L')
				{
					dx=x-1;
					dy=y;
				}
				if(tmp[i]=='B')
				{
					dx=x;
					dy=y-1;
				}
				v.push_back(make_pair(dx,dy));
				q.push(make_pair(dx,dy));
			}
			cin>>tmp;
		}
		sort(v.begin(),v.end(),cmp);
		cout<<v.size()<<endl;
		for(int i=0;i<v.size();i++)
			cout<<v[i].first<<" "<<v[i].second<<endl;
	}
	else
	{
		int m[20][20]={0},dx,dy;
		cin>>X>>Y;
		for(int i=0;i<x-1;i++)
		{
			cin>>p>>q;
			m[p][q]++;
		}
		m[X][Y]=-1;
		queue<pair<int,int> >q;
		q.push(make_pair(X,Y));
		cout<<X<<" "<<Y<<endl;
		string sol;
		while(!q.empty())
		{
			x=q.front().first;
			y=q.front().second;
			q.pop();
			for(int i=0;i<4;i++)
			{
				dx=x+dir[i][0];
				dy=y+dir[i][1];

				if(dx>=0&&dy<=10&&dy>=0&&dy<=10&&m[dx][dy]==1)
				{
					m[dx][dy]=-1;
					sol.push_back(mo[i]);
					q.push(make_pair(dx,dy));
				}
			}
			sol.push_back(',');
			sol.push_back('\n');
		}
		if(sol.size())
		sol[sol.size()-2]='.';
	    else
	    {
	    	sol.push_back('.');
			sol.push_back('\n');
	    }
		cout<<sol;
	}
}