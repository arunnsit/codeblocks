#include<iostream>
#include<string>
#include<string.h>
#include<set>
#include<vector>
using namespace std;
vector<string>v;
int main()
{
	string a;
	long long int n,p;
	cin>>n>>p;
	while(n--)
	{
		cin>>a;
		v.push_back(a);
	}
	long long int apps=0,sol=0;
	for(int i=v.size()-1;i>=0;i--)
	{
		if(v[i]=="halfplus")
		{
			apps+=1;
			sol+=p/2;
		}
		sol+=1LL*(apps/2)*p;
		apps*=2LL;
	}
	cout<<sol<<endl;
}