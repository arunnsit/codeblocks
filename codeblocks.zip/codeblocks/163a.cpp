#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<string>
#include<string.h>
#include<math.h>
#include<algorithm>
using namespace std;
int dp[5005][5005]={0};
string s,t;
int mod=1000000007;
long long int sol=0;
int solve(int x,int y)
{
	if(y==-1||x==-1)
		return 0;
	if(dp[x][y])
		return dp[x][y];
	if(s[x]==t[y])
	{
		return dp[x][y]=(solve(x-1,y-1)+solve(x,y-1)+1)%mod;
	}
	else return dp[x][y]=(solve(x,y-1))%mod;
}
int main()
{
	cin>>s>>t;
	for(int i=s.size()-1;i>=0;i--)
	{
		sol=(sol+solve(i,t.size()-1))%mod;
	}
	cout<<sol<<endl;
}