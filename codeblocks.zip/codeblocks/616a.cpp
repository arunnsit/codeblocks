#include<stdio.h>
#include<string.h>
#include<iostream>
using namespace std;
char a[1000009],b[1000009];
int main()
{
    scanf("%s",a);
    scanf("%s",b);
    int l1=0,l2=0,x,y;

    for(l1=0;a[l1]=='0';l1++)
    {

    }
    for(l2=0;b[l2]=='0';l2++)
    {

    }
    x=l1;
    y=l2;
    while(a[l1]!='\0'&&b[l2]!='\0')
    {
        if(a[l1]!=b[l2])
        {
            break;
        }

        l1++;
        l2++;
    }
    if(strlen(a)-x<strlen(b)-y||((strlen(a)-x==strlen(b)-y)&&a[l1]-b[l2]<0))
        printf("<");
    else if((strlen(a)-x==strlen(b)-y)&&a[l1]-b[l2]==0)
        printf("=");
    else printf(">");
}