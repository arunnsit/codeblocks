#include<iostream>
using namespace std;
int marks[1000][1000]={0};
int main()
{
	int n;
	cin>>n;
	int sol=0;
	for(int i=1;i<n;i++)
	{
		marks[i][i+1]=1;
		marks[i+1][i]=1;
		sol++;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		if(!marks[i][j]){
			int c=0;
			for(int k=1;k<=n;k++)
			if(marks[i][k]&&marks[k][j]&&k!=i&&k!=j)
			{
				c++;
			}
			if(!c)
			{
				marks[i][j]=1;
				marks[j][i]=1;
				sol++;
			}
		}
	}
	cout<<sol<<endl;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		if(marks[i][j])	
		cout<<i<<" "<<j<<endl;
	}	

}