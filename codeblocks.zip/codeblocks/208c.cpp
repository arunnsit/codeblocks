#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<math.h>
#include<vector>
using namesapce std;
vector<int>adj[300],num[300];
int main()
{
	int n,m,t,x,y;
	cin>>n>>m;
    for(int i=0;i<m;i++)
    {
    	cin>>x>>y;
    	adj[x].push_back(y);
    	adj[y].push_back(x);
    	num[x].push_back(i+1);
    	num[y].push_back(i+1);
    }
    

}
