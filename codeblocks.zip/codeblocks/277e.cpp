//taken from : http://codeforces.com/contest/237/submission/18168252
#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<math.h>
#include<iomanip>
#include<queue>
const int inf = 1e9 + 7;
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define FOR(i,j,k) for(int i = j; i < (int)(k); i++)
#define For(i, a, b)  for(int (i) = (a); (i) < (b); ++ (i))
using namespace std;
template <class T>  inline void smin(T &x, T y){x = min(x, y);}

typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ld,ld> pdd;
typedef pair<pii,int> ppi;
typedef pair<pll,ll> ppl;
typedef pair<int,pii> pip;
typedef pair<ll,pll> plp;
typedef pair<pii,pii> ppp;
const ll infos = (ll) 1e17;

struct mincost{
    const static int maxn = 1000, maxm = 1000000;
    const static long long  diso = infos;
    int n, m;
    int from[maxm * 2], to[maxm * 2], hed[maxn], prv[maxm * 2], cap[maxm * 2];
    ld cost[maxm * 2];
    ld dis[maxn];
    int par[maxn];
    inline void init(int N){
  n = N, m = 0;
  memset(hed, -1, sizeof hed);
    }
    inline int add_single_edge(int v, int u, ll c, ld w){
  from[m] = v, to[m] = u, cap[m] = c, cost[m] = w, prv[m] = hed[v], hed[v] = m;
  return m ++;
    }
    inline int add_edge(int v, int u, ll c, ld w){
  int ans = add_single_edge(v, u, c, w);
  add_single_edge(u, v, 0, -w);
  return ans;
    }
    inline void spfa(int source){
  fill(dis, dis + n, diso);
  fill(par, par + n, -1);
  queue<int> q;
  static bool onq[maxn];
  fill(onq, onq + n, false);
  dis[source] = 0;
  q.push(source);
  onq[source] = true;
  while(!q.empty()){
      int v = q.front();
      q.pop();
      onq[v] = false;
      for(int e = hed[v]; ~e; e = prv[e])if(cap[e] > 0){
    int u = to[e];
    ld w = cost[e];
    if(dis[u] > dis[v] + w + 1e-9){
        dis[u] = dis[v] + w;
        par[u] = e;
        if(!onq[u])
      q.push(u);// par[u] = e;
        onq[u] = true;
    }
      }
  }
    }
    inline pair<ll, ld> mincostmaxflow(int source, int sink){
  ll flow = 0;
  ld money = 0;
  while(true){
      spfa(source);
      if(dis[sink] == diso) break ;
      vi edges;
      int cur = inf;
      int v = sink;
      while(v - source){
  //  cout << v << endl;
    int e = par[v];
    edges.pb(e);
    v = from[e];
    smin(cur, cap[e]);
      }
      flow += cur;
      //assert(cur);
      if(!cur)break;
      For(i, 0, edges.size()){
    int e = edges[i];
    cap[e] -= cur;
    cap[e^1] += cur;
    money += 1.0 * cur * cost[e];
      }
      //cout << flow << " " << money << endl;
  }
  return make_pair(flow, money);
    }
}mf;
int main()
{
  vector<pair<int,int> >v;
  int n;
  cin>>n;
  for(int i=0;i<n;i++)
  {
    int x,y;
    cin>>x>>y;
    v.push_back(make_pair(y,x));
  }
  sort(v.begin(),v.end());
  mincost G;
  G.init(2*n+2);
  for(int i=0;i<n;i++)
  {
    G.add_edge(0,i+1,2,0);
    G.add_edge(n+i+1,2*n+1,1,0);
  }
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<i;j++)
    {
      if(v[j].first<v[i].first)
      {
        G.add_edge(i+1,n+1+j,1,sqrt((v[i].first-v[j].first)*(v[i].first-v[j].first)+(v[i].second-v[j].second)*(v[i].second-v[j].second)));
      }
    }
  }
  pair<long long ,double>pp=G.mincostmaxflow(0,2*n+1);
  //cout<<pp.first<<endl;
  cout<<fixed;
  if(pp.first==n-1)
  {
    cout<<setprecision(10)<<pp.second<<endl;
  }
  else cout<<-1<<endl;
}