#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
#include<string.h>
#define N 100009
using namespace std;
int in[N],lf[N],rf[N];
int main()
{
	string a;
	int n,k;
	cin>>n>>k;
	cin>>a;
	for(int i=0;i<a.size();i++)
	{
		in[i+1]=in[i]+((a[i]-'0')^1);
	}
	for(int i=0;i<a.size()+2;i++)
	{
		rf[i]=-a.size();
		lf[i]=a.size();
	}
	for(int i=0;i<a.size();i++)
	{
		if(a[i]=='0')
			rf[i+1]=i+1;
		else rf[i+1]=rf[i];
	}
	for(int i=a.size()-1;i>=0;i--)
	{
		if(a[i]=='0')
			lf[i+1]=i+1;
		else lf[i+1]=lf[i+2];
	}
	int sol=a.size(),l,r,mid;
	for(int i=1;i<=a.size();i++)
	{
		if(a[i-1]=='0')
		{
			l=i;
			r=lower_bound(in+1,in+a.size()+1,in[i]+k)-in;
			if(in[r]-in[l]!=k)continue;
			//cout<<l<<" "<<r<<endl;
			mid=(l+r)/2;
			sol=min(sol,min(max(r-rf[mid],rf[mid]-l),max(r-lf[mid],lf[mid]-l)));
		}
	}
	cout<<sol<<endl;
}