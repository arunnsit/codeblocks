#include<iostream>
using namespace std;
int main()
{
	int x,y,sol=0;
	cin>>x>>y;
	while(1)
	{
		if(x<y)
		{
			x+=1;
			y-=2;
		}
		else
		{
			y+=1;
			x-=2;

		}
		sol++;
		//cout<<x<<" "<<y<<endl;
		if((x==1&&y==1))
		{
			break;
		}
		if(x<0||y<0)
		{
			sol-=1;
			break;
		}
		if(x==0||y==0)
		{
			break;
		}
	}
	cout<<sol<<endl;

}