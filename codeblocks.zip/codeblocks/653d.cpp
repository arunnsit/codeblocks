#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<algorithm>
#include<string.h>
#include<iomanip>
using namespace std;
double maj;
struct flow_graph{
    int MAX_V,E,s,t,head,tail;
    long long int *cap,*to,*next,*last,*dist,*q,*now;
    
    flow_graph(){}
    
    flow_graph(int V, int MAX_E){
        MAX_V = V; E = 0;
        cap = new long long int[2*MAX_E], to = new long long int[2*MAX_E], next = new long long int[2*MAX_E];
        last = new long long int[MAX_V], q = new long long int[MAX_V], dist = new long long int[MAX_V], now = new long long int[MAX_V];
        fill(last,last+MAX_V,-1);
    }
    
    void clear(){
        fill(last,last+MAX_V,-1);
        E = 0;
    }
    
    void add_edge(int u, int v, int uv, int vu = 0){
        to[E] = v, cap[E] = uv, next[E] = last[u]; last[u] = E++;
        to[E] = u, cap[E] = vu, next[E] = last[v]; last[v] = E++;
    }
	
	bool bfs(){
		fill(dist,dist+MAX_V,-1);
		head = tail = 0;
		
		q[tail] = t; ++tail;
		dist[t] = 0;
		
		while(head<tail){
			int v = q[head]; ++head;
			
			for(int e = last[v];e!=-1;e = next[e]){
				if(cap[e^1]>0 && dist[to[e]]==-1){
					q[tail] = to[e]; ++tail;
					dist[to[e]] = dist[v]+1;
				}
			}
		}
		return dist[s]!=-1;
	}
	
	long long int dfs(int v, long long int f){
		if(v==t) return f;
		
		for(long long int &e = now[v];e!=-1;e = next[e]){
			if(cap[e]>0 && dist[to[e]]==dist[v]-1){
				long long int ret = dfs(to[e],min(f,cap[e]));
				
				if(ret>0){
					cap[e] -= ret;
					cap[e^1] += ret;
					return ret;
				}
			}
		}
		
		return 0;
	}
	
	long long max_flow(int source, int sink){
		s = source; t = sink;
		long long f = 0;
		long long int x;
		
		while(bfs()){
			//cout<<"inside\n"<<endl;
			for(int i = 0;i<MAX_V;++i) now[i] = last[i];
			
			while(true){
				x = dfs(s,1e17);

				if(x==0) break;
				f += x;
			}
		}
		
		return f;
	}
};
int n,m,Y;
vector<pair<pair<int,int>,double> >v;
int main()
{
	cin>>n>>m>>Y;
	for(int i=0;i<m;i++)
	{
		int a,b,c,d;
		cin>>a>>b>>c;
		v.push_back(make_pair(make_pair(a,b),c));
	}
	flow_graph G(n+10,m+20);
	long double l=0,r=1000000,mid,sol=0;
	int loop=350;
	cout<<fixed;
	while(l<=r&&loop--)
	{
		mid=(l+r)*0.5;
		G.clear();
		for(int i=0;i<m;i++)
		{
			if((v[i].second)>=1000000*mid)
			G.add_edge(v[i].first.first,v[i].first.second,1000000);
			else G.add_edge(v[i].first.first,v[i].first.second,(long long int)(v[i].second/mid));
		}
		long long int fo=G.max_flow(1,n);
		if(fo>=Y)
		{
			sol=max(sol,mid*Y);
			l=mid;
		}
		else r=mid;
	}
	
	cout<<setprecision(10)<<sol<<endl;
}