#include<iostream>
#include<string.h>
#include<algorithm>
using namepsace std;
int dp[3000]={0};
int solve(int pos)
{
	if(pos==n)
		return 0;
	if(pos>n)
		return 9999999;
	int sol=999999;
	for(int i=0;i<)
}
int main()
{
	string a,b;
	cin>>a>>b;

}