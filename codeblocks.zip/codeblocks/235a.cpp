#include<iostream>
using namespace std;
long long int gcd(long long int a,long long int b)
{
	if(b==0)
		return a;
	else return gcd(b,a%b);
}
int main()
{
	long long int s,sol=0;
	cin>>s;
	for(int i=s;i>=s-500;i--)
		for(int j=i-1;j>=s-500;j--)
			if(j>=0)
			for(int k=j-1;k>=s-500;k--)
				if(k>=0)
				sol=max(sol,(k*((i*j)/gcd(i,j)))/gcd(k,((i*j)/gcd(i,j)))*1LL);
	cout<<max(sol,s)<<endl;

}