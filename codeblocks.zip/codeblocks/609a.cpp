#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<int>v;
int main()
{
	int n,x,m,i;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		v.push_back(x);
	}
	sort(v.begin(),v.end());
	for(i=n-1;i>=0;i--)
	{
		m-=v[i];
		if(m<=0)
			break;
	}
	cout<<n-i<<endl;
}