#include"bits/stdc++.h"
#define LL long long
#define PII pair<int,int>
#define PPI pair<PII,int>
#define PIP pair<int,PII>
#define PPP pair<PII,PII>
#define X first
#define Y second
#define INF 1000000000
#define FOR(a,b,c) for(int a=b;a<=c;a++)
#define FO_(a,b,c) for(int a=b;a>=c;a--)
#define REP(i,u,v) for(int i=H[u],v=to[i];i;i=nxt[i],v=to[i])
using namespace std;
const int P = 1000000007;

LL sum(LL l,LL r) {
	return ((l+r)%P) * ((r-l+1)%P) %P * ((P+1)/2) %P;
}
LL n,m,ans;
int main() {
	//freopen("std.in","r",stdin);
	cin>>n>>m;
	ans = (n%P)*(m%P)%P;
	for(LL i=1,last; i<=m; i=last+1) {
		if(i <= n)
			last = min(m,n/(n/i));
		else last = m;
		ans -= (n/i) %P * sum(i,last) %P;
	}
	ans = (ans %P + P) %P;
	cout<<ans<<endl;
	return 0;
}