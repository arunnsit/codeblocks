#include<iostream>
#include<algorithm>
#include<iomanip>
#include<string.h>
using namespace std;
 double dp[1<<19][19];
 double p[20][20],no;
int n;
 double solve(int mask,int curr)
{
	//cout<<mask<<" "<<curr<<endl;
	if(((mask+1)==(1<<n))&&curr==0)
	{
		return 1.0;
	}
	if(dp[mask][curr]>=0)
		return dp[mask][curr];
	 double sol=0.0,total=0.0;
	for(int i=0;i<n;i++)
	if(((mask>>i)&1)==0)total++;
	for(int i=0;i<n;i++)
	if(((mask>>i)&1)==0){
		sol=max(sol,(p[curr][i]*solve(mask|(1<<i),curr)+p[i][curr]*solve(mask|(1<<i),i)));
	}
	return dp[mask][curr]=sol;
}
int main()
{
	std::ios::sync_with_stdio(false); 
	memset(dp,-1.0,sizeof(dp));
	cout<<fixed<<setprecision(10);
	 double sol=0;
	cin>>n;
	no=n;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			cin>>p[i][j];
	for(int i=0;i<n;i++)
	{
		sol=max(sol,(solve((1<<i),i)));
	}	
	cout<<sol<<endl;
}