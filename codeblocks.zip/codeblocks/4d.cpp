#include <iostream>
#include <algorithm>
#include <vector>
#define max(a,b) a>b?a:b
using namespace std;
vector<int>sol;
struct node
{
	int w,h,c;
};
int cmp(node a,node b)
{
	return a.w<b.w;
}
vector<node> a;
int dp[5001]={0};
int W,H;
int solve(int prev)
{
	if(dp[prev])
		return dp[prev];
	int x=0;
	for(int i=prev-1;i>=0;i--)
		if(a[i].w<a[prev].w&&a[i].h<a[prev].h&&a[i].h>H&&a[i].w>W)
		{
			x=max(solve(i)+1,x);
		}

	return dp[prev]=x;
}
void fill(int prev)
{
	int x=0,v=-1;
	for(int i=prev-1;i>=0;i--)
		if(a[i].w<a[prev].w&&a[i].h<a[prev].h&&a[i].h>H&&a[i].w>W)
		{
			if(x<solve(i)+1)
			{
				x=solve(i)+1;
				v=i;
			}
		}
		if(v!=-1)
			{
				sol.push_back(a[v].c);
				fill(v);
			}
}
int main()
{
	int n;
	node tmp;
	cin>>n>>W>>H;
	for(int i=0;i<n;i++)
		{
			cin>>tmp.w>>tmp.h;
			tmp.c=i+1;
			a.push_back(tmp);
		}
	sort(a.begin(),a.end(),cmp);
	a[n].w=10000000;
	a[n].h=10000000;
	cout<<solve(n)<<endl;
	fill(n);
	for(int i=sol.size()-1;i>=0;i--)
		cout<<sol[i]<<" ";
}