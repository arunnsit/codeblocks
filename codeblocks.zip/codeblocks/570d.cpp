#include<iostream>
#include<vector>
#include<map>
#include<set>
#include<algorithm>
#include<string>
#include<stdio.h>
#define N 500009
using namespace std;
vector<int>adj[N];
vector<pair<int,int > >q[N];
char a[N];
long long int sub[N],maxx,can;
long long int sol[N];
void sub_solve(int u,int p)
{
	sub[u]=1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p)
	{
		sub_solve(adj[u][i],u);
		sub[u]+=sub[adj[u][i]];
	}
}
int big[N],col[26][N];
void add(int u,int p,int x,int h)
{
	//cout<<"add:"<<u<<" "<<x<<endl;
	col[a[u-1]-'a'][h]+=x;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&big[adj[u][i]]==0)
	{
		add(adj[u][i],u,x,h+1);
	}
}
void dfs(int u,int p,int keep,int h)
{
	int bigsiz=-1,bigboy=-1;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigsiz<sub[adj[u][i]])
	{
		bigsiz=sub[adj[u][i]];
		bigboy=adj[u][i];
	}
	//cout<<"dfs:"<<u<<" "<<bigboy<<" "<<keep<<endl;
	for(int i=0;i<adj[u].size();i++)
	if(adj[u][i]!=p&&bigboy!=adj[u][i])
	{
		dfs(adj[u][i],u,0,h+1);
	}
	if(bigboy!=-1)
	{
		dfs(bigboy,u,1,h+1);
		big[bigboy]=1;
	}
	add(u,p,1,h);
	//cout<<"u:"<<u<<" "<<temp<<endl;
	for(int i=0;i<q[u].size();i++)
	{
		int c=0;
		for(int j=0;j<26;j++)
		{
			if(col[j][q[u][i].second]%2)
				c++;
		}
		//cout<<q[u][i].first<<".."<<c<<endl;
		if(c<2)
		sol[q[u][i].first]=1;
	}
	if(bigboy!=-1)
	{
		big[bigboy]=0;
		//cout<<"removed:"<<bigboy<<endl;
	}
	if(keep==0)
	{
		add(u,p,-1,h);
		maxx=0;
		can=0;
	}
}
int main()
{
	int n,m,x,y;
	scanf("%d %d",&n,&m);
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&x);
		adj[x].push_back(i);
		adj[i].push_back(x);
	}
	scanf("%s",a);
	for(int i=0;i<m;i++)
	{
		scanf("%d %d",&x,&y);
		q[x].push_back(make_pair(i+1,y));
	}
	sub_solve(1,1);
	dfs(1,1,0,1);
	for(int i=1;i<=m;i++)
		{
			if(sol[i])printf("Yes\n");
			else printf("No\n");
		}
}