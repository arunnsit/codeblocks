#include<iostream>
#include<algorithm>
#include<math.h>
#include<string.h>
#include<vector>
using namespace std;
vector<int>adj[100008];
vector<long long int> facs;
int check(string a)
{
	for(int i=0;i<a.length();i++)
		if(!(a[i]=='4'||a[i]=='7'))return 0;
	return 1;
}
int vis[100008]={0};
int dfs(int start,int p)
{
	int x=0;
	vis[start]=1;
	for(int i=0;i<adj[start].size();i++)
		if(adj[start][i]!=p)
		{
			x+=dfs(adj[start][i],start);
		}
	return x+1;	
}

int main()
{
	int n,t,x,y;
    string a;
	cin>>n;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y>>a;
		if(!check(a))
		{
		adj[x].push_back(y);
		adj[y].push_back(x);
	}
	}
	long long int sum=0,curr;
	for(int i=1;i<=n;i++)
		if(!vis[i])
		{
			curr=dfs(i,0);
			facs.push_back(curr);
			sum+=curr;
		}
		long long int sol=0;
	for(int i=0;i<facs.size();i++)
	{
		sol+=facs[i]*(sum-facs[i])*(sum-facs[i]-1);
	}
	cout<<sol<<endl;
}