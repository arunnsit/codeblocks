#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
vector<int>adj[300];
vector<pair<int,int> >v;
int lsol,rsol;
int dfs(int start,int p,int &sap)
{
	int ma=0,mchild=0,x;
	for(int i=0;i<adj[start].size();i++)
		if(adj[start][i]!=p)
		{
			x=dfs(adj[start][i],start,sap)+1;
			if(ma<x)
			{
				ma=x;
				mchild=adj[start][i];
			}
		}
		sap=max(sap,ma);
	for(int i=0;i<adj[start].size();i++)
		if(adj[start][i]!=p&&mchild!=adj[start][i])
		{
			sap=max(sap,ma+dfs(adj[start][i],start,sap)+1);
		}
		//cout<<ma<<" yo\n";
	return ma;	
}
int main()
{
	int n,x,y,sol=0;
	cin>>n;
	for(int i=0;i<n-1;i++)
	{
		cin>>x>>y;
		adj[x].push_back(y);
		adj[y].push_back(x);
		v.push_back(make_pair(x,y));
	}
	for(int i=0;i<n-1;i++)
	{
		rsol=0;
		lsol=0;
		dfs(v[i].first,v[i].second,rsol);
		dfs(v[i].second,v[i].first,lsol);
		//cout<<rsol<<" "<<lsol<<endl;
		sol=max(sol,rsol*lsol);
	}
	cout<<sol<<endl;

}